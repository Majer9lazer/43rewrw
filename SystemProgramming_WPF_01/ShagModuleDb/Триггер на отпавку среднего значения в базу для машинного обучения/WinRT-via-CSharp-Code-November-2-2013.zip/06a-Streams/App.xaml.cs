﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Streams {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
      }

      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         Frame rootFrame = Window.Current.Content as Frame;

         // Don't repeat app initialization when Window already has content, just activate window
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When navigation stack isn't restored, navigate to 1st page
            if (!rootFrame.Navigate(typeof(StreamsPage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure current window is active
         Window.Current.Activate();
      }
   }
}
