﻿/******************************************************************************
Module:  StreamPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;  // For WindowsRuntimeBufferExtensions
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Networking;
using Windows.Networking.BackgroundTransfer;
using Windows.Security.Credentials;
using Windows.Security.Cryptography;
using Windows.Security.Cryptography.DataProtection;
using Windows.Storage;
using Windows.Storage.Compression;
using Windows.Storage.FileProperties;
using Windows.Storage.Search;
using Windows.Storage.Streams;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace Streams {
   public sealed partial class StreamsPage : Page {
      public StreamsPage() {
         this.InitializeComponent();
      }

      private const String c_filename = "StreamDemo.txt";

      private async void EasyFileIO(object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile file = await CreateFileAsync(c_filename);

         String[] output = new[] { "Line 1", "Line 2", "Line 3" };
         await FileIO.WriteLinesAsync(file, output);

         IList<String> input = await FileIO.ReadLinesAsync(file);
         foreach (String line in input)
            Debug.WriteLine(line);
         await file.DeleteAsync();  // Cleanup demo
      }

      private async void StreamInterop(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile file = await Package.Current.InstalledLocation.GetFileAsync("AppxManifest.xml");
         using (Stream netStream = await file.OpenStreamForReadAsync()) {
            XDocument xml = XDocument.Load(netStream);
         }
      }

      private async void SimpleWriteAndRead(object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile file = await CreateFileAsync(c_filename);
         using (IRandomAccessStream raStream = await file.OpenAsync(FileAccessMode.ReadWrite)) {
            Byte[] bytes = new Byte[] { 1, 2, 3, 4, 5 };
            UInt32 bytesWritten = await raStream.WriteAsync(bytes.AsBuffer());   // Byte[] -> IBuffer

            using (var ms = new MemoryStream())
            using (var sw = new StreamWriter(ms)) {
               sw.Write("A string in a stream");
               sw.Flush();
               bytesWritten = await raStream.WriteAsync(ms.GetWindowsRuntimeBuffer()); // Stream -> IBuffer
            }
         }  // Close the stream

         using (IRandomAccessStream raStream = await file.OpenAsync(FileAccessMode.Read)) {
            // NOTE: This is the most efficient way to allocate, populate, & access data:
            Byte[] data = new Byte[5]; // Allocate the Byte[]
            IBuffer buffer = data.AsBuffer();      // Embed it in an object that implements IBuffer
            await raStream.ReadAsync(buffer, buffer.Capacity, InputStreamOptions.None);
            // Now, access the bytes in the original Byte[] directly

            data = new Byte[raStream.Size - 5]; // Allocate Byte[] for remainder
            buffer = data.AsBuffer();      // Embed it in an object that implements IBuffer
            await raStream.ReadAsync(buffer, buffer.Capacity, InputStreamOptions.None);

            using (var sr = new StreamReader(buffer.AsStream())) {
               String str = sr.ReadToEnd();
            }
         }  // Close the stream
         await file.DeleteAsync();  // Cleanup demo
      }

      private async void DataWriterAndReader(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile file = await CreateFileAsync(c_filename);
         using (var dw = new DataWriter(await file.OpenAsync(FileAccessMode.ReadWrite))) {
            dw.WriteBytes(new Byte[] { 1, 2, 3, 4, 5 });
            const String text = "Some text";
            UInt32 encodedStringLength = dw.MeasureString(text);
            dw.WriteUInt32(encodedStringLength);
            dw.WriteString(text);
            UInt32 bytesStored = await dw.StoreAsync();  // Commit buffer to stream
         }  // Close DataWriter & underlying stream

         using (var dr = new DataReader(await file.OpenAsync(FileAccessMode.Read))) {
            Byte[] bytes = new Byte[5];
            UInt32 bytesRead = await dr.LoadAsync((UInt32)bytes.Length);
            dr.ReadBytes(bytes);

            // Get length of string & read the rest of it in:
            bytesRead = await dr.LoadAsync(sizeof(UInt32));
            var encodedStringLength = dr.ReadUInt32();
            await dr.LoadAsync(encodedStringLength);
            String text = dr.ReadString(encodedStringLength);
            UInt32 remainder = dr.UnconsumedBufferLength; // 0
         }  // Close DataReader & underlying stream

         await file.DeleteAsync();  // Cleanup demo
      }

      private async void PoliteReader(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Create a file & populate it with some data
         StorageFile file = await CreateFileAsync(c_filename);
         await FileIO.WriteTextAsync(file, "Here is some data I wrote to the file");

         Int32 injectWriteForTesting = 0; // Demos polite reader recovery
         while (true) {
            injectWriteForTesting++;
            try {
               // Open the file for read access
               using (IRandomAccessStream readOnly = await file.OpenAsync(FileAccessMode.Read)) {

                  if (injectWriteForTesting == 1) {
                     // NOTE: another app can write to the file while this app has the file open for reading:
                     await FileIO.WriteTextAsync(file, "Write NEW data to the file");
                  }

                  // This app tries to read from the file it already opened:
                  Byte[] bytes = new Byte[readOnly.Size];   // NOTE: Size returns 0 if file got written to
                  IBuffer buffer = bytes.AsBuffer();

                  if (injectWriteForTesting == 2) {
                     // NOTE: another app can write to the file while this app has the file open for reading:
                     await FileIO.WriteTextAsync(file, "Write NEWER data to the file");
                  }

                  // NOTE: If Size is 0, this throws IndexOutOfRangeException; otherwise this throws 
                  // Exception (HResult=0x80070323) if file written to; else no exception
                  await readOnly.ReadAsync(buffer, buffer.Capacity, InputStreamOptions.ReadAhead);
                  // TODO: Process the data read here...
               }
               break;   // Success, don't retry
            }
            catch (IndexOutOfRangeException) {
               // NOTE: Thrown from ReadAsync if Size is 0
               // If we get here, we'll loop around and retry the read operation
            }
            catch (Exception ex) {
               const Int32 ERROR_OPLOCK_HANDLE_CLOSED = unchecked((Int32)0x80070323);
               if (ex.HResult != ERROR_OPLOCK_HANDLE_CLOSED) throw;
               String msg = ex.Message;
               // If we get here, we'll loop around and retry the read operation
            }
         }
         await file.DeleteAsync();
      }

      private async void TransactedWriter(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Create a file & populate it with some original data
         StorageFile file = await CreateFileAsync(c_filename);
         const String header = "Data: ";
         using (var dw = new DataWriter(await file.OpenAsync(FileAccessMode.ReadWrite))) {
            dw.WriteString(header + "The original data.");
            await dw.StoreAsync();
         }

         for (Int32 commit = 0; commit <= 1; commit++) {
            // Perform transacted write without & with commit
            using (StorageStreamTransaction txStream = await file.OpenTransactedWriteAsync())
            using (var dw = new DataWriter(txStream.Stream.GetOutputStreamAt((UInt32)header.Length))) {
               dw.WriteString("The new & improved data.");
               await dw.StoreAsync();
               if (commit == 1) await txStream.CommitAsync();
            }
            String text = await FileIO.ReadTextAsync(file);
         }
         await file.DeleteAsync();
      }

      private async Task CompressFileAsync(IStorageFile originalFile, IStorageFile compressedFile) {
         using (var input = await originalFile.OpenAsync(FileAccessMode.Read))
         using (var output = await compressedFile.OpenAsync(FileAccessMode.ReadWrite))
         using (var compressor = new Compressor(output, CompressAlgorithm.Mszip, 0)) {
            // NOTE: Compressor implements IOutputStream
            await RandomAccessStream.CopyAsync(input, compressor);
            await compressor.FinishAsync();
         }
      }

      private async Task DecompressFileAsync(IStorageFile compressedFile, IStorageFile decompressedFile) {
         using (var decompressor = new Decompressor(await compressedFile.OpenAsync(FileAccessMode.Read)))
         using (var output = await decompressedFile.OpenAsync(FileAccessMode.ReadWrite)) {
            // NOTE: Decompressor implements IInputStream
            await RandomAccessStream.CopyAsync(decompressor, output);
         }
      }

      private async void Compression(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // NOTE: IInputStream & IOutputStream share IRandomAccessStream's Position
         // So, we get separate streams via GetOutput/InputStreamAt (or we could seek to 0 before reading)

         using (IRandomAccessStream raStream = new InMemoryRandomAccessStream()) {
            // Compressor implements IOutputStream
            using (var compressor = new Compressor(raStream.GetOutputStreamAt(0), CompressAlgorithm.Mszip, 0))
            using (var dw = new DataWriter(compressor)) {
               String text = "This is some uncompressed data.";
               // We must store the string length first followed by the string so we can read it back later 
               UInt32 length = dw.MeasureString(text);
               dw.WriteUInt32(length);
               dw.WriteString(text);
               await dw.StoreAsync();  // Commits temp data to file (Overwrites original file data)
               await compressor.FinishAsync();
            }

            // Show compressed data:
            Byte[] data = new Byte[(Int32)raStream.Size];
            await raStream.ReadAsync(data.AsBuffer(), (UInt32)data.Length, InputStreamOptions.None);

            // Read & decompress the data (Decompressor implements IInputStream)
            // CompressAlgorithm is embedded in the stream
            using (var decompressor = new Decompressor(raStream.GetInputStreamAt(0)))
            using (var dr = new DataReader(decompressor)) {
               UInt32 bytesRead = await dr.LoadAsync((UInt32)raStream.Size);
               UInt32 length = dr.ReadUInt32();
               String text = dr.ReadString(length);
            }
         }
      }

#if false
Encrypt for logged-in user: LOCAL=user
Encrypt for logon session only: LOCAL=logon
Encrypt for any user on the machine: LOCAL=machine
Encrypt for holder of X.509 certificate private key: CERTIFICATE=thumbprint or serial number
Encrypt for any member of Active Directory group: SID=sid or SDDL=sddl
Encrypt for a particular application: KEY=myAppKey
Encrypt for web credential: WEBCREDENTIALS=Username,Password
The web credential option basically encrypts data to a password credential stored by the app.
Note: Some of the above require EnterpriseAuthentication capability in manifest
#endif
      private async void DataProtection(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile clearText = await CreateFileAsync("ClearText.txt");
         await FileIO.WriteTextAsync(clearText, "This is clear text");

         StorageFile cipherText = await CreateFileAsync("CipherText.txt");
         // http://msdn.microsoft.com/en-us/library/windows/apps/windows.security.cryptography.dataprotection.dataprotectionprovider
         // http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh465034.aspx
         await EncryptFileAsync("LOCAL=user", clearText, cipherText);   // Encrypts for local user

         StorageFile clearText2 = await CreateFileAsync("ClearText2.txt");
         await EncryptFileAsync(null, cipherText, clearText2);

         // Delete the 3 files:
         await Task.WhenAll(clearText.DeleteAsync().AsTask(),
            cipherText.DeleteAsync().AsTask(), clearText2.DeleteAsync().AsTask());
      }

      private static async Task EncryptFileAsync(String protectionDesciption, StorageFile source, StorageFile destination) {
         using (IRandomAccessStream input = await source.OpenAsync(FileAccessMode.Read))
         using (IRandomAccessStream output = await destination.OpenAsync(FileAccessMode.ReadWrite)) {
            if (protectionDesciption != null) {
               // Pass constructor argument when encrypting
               var dpp = new DataProtectionProvider(protectionDesciption);
               await dpp.ProtectStreamAsync(input, output);
            } else {
               // Do not pass constructor argument when decrypting
               var dpp = new DataProtectionProvider();
               await dpp.UnprotectStreamAsync(input, output);
            }
         }
      }

      private async void DataProtectForWeb(Object sender, RoutedEventArgs e) {
         // http://msdn.microsoft.com/en-us/library/windows/apps/windows.security.credentials.aspx
         // Protect data for "user"/"pswd" related to "website.com":

         // Create a web credential (resource/username/password tuple) & add it to the password vault
         String webSite = "Wintellect.com", username = "Jeffrey", password = "P@ssw0rd";
         var pc = new PasswordCredential(new HostName(webSite).CanonicalName, username, password);
         new PasswordVault().Add(pc);

         // Encrypt data using the web credential:
         pc = new PasswordVault().Retrieve(new HostName(webSite).CanonicalName, username);
         String protectionDescriptor = "WEBCREDENTIALS=" + pc.UserName + "," + pc.Resource;
         var provider = new DataProtectionProvider(protectionDescriptor);
         String clearText = "This is some clear text data";
         IBuffer clearBuffer = CryptographicBuffer.ConvertStringToBinary(clearText, BinaryStringEncoding.Utf8);
         IBuffer cipherBuffer = await provider.ProtectAsync(clearBuffer);

         // Decrypt data using the web credential:
         provider = new DataProtectionProvider();
         IBuffer clearBuffer2 = await provider.UnprotectAsync(cipherBuffer);
         String clearText2 = CryptographicBuffer.ConvertBinaryToString(BinaryStringEncoding.Utf8, clearBuffer2);
         Boolean same = String.Equals(clearText, clearText2);

         // Remove credential from vault:
         new PasswordVault().Remove(pc);
      }

      private async void StreamOnDemand(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Get a generic thumbnail image for JPG files
         StorageItemThumbnail thumbnail = await GetTypeThumbnailAsync(".jpg", ThumbnailMode.SingleItem);
         RandomAccessStreamReference thumbnailSource = RandomAccessStreamReference.CreateFromStream(thumbnail);

         // Create a StorageFile object whose stream will be populated by OnDataRequested
         Uri uri = new Uri("http://www.free-picture.net/albums/nature/sundown/beautiful-sunny-sunset.jpg");
         StorageFile file = await StorageFile.CreateStreamedFileAsync("Sunset.jpg", outputStream => OnDataRequested(outputStream, uri), thumbnailSource);

         // Simpler way of downloading data from the Internet (no callback needed):
         // StorageFile file = await StorageFile.CreateStreamedFileFromUriAsync("Sunset.jpg", uri, thumbnailSource);

         // Show it works by passing the StorageFile to another app
         var noWarning = Launcher.LaunchFileAsync(file, new LauncherOptions { DisplayApplicationPicker = true });
      }

      private async void OnDataRequested(StreamedFileDataRequest outputStream, Uri uri) {
         Debugger.Break();
         // Have the background downloader transfer the image
         DownloadOperation download = new BackgroundDownloader().CreateDownload(uri, null);
         var noWarning = download.StartAsync();

         // Copy the downloaded image's bytes to the storage stream
         // NOTE: The consuming app can read the stream's contents while it is downloading;
         //       it does not have to wait until the download is complete
         using (IInputStream inputStream = download.GetResultStreamAt(0)) {
            // NOTE: StreamedFileDataRequest implements IOutputStream
            await RandomAccessStream.CopyAndCloseAsync(inputStream, outputStream);
         }
      }
      // http://blogs.msdn.com/b/windowsappdev/archive/2012/09/12/integrating-your-cloud-service-with-the-file-picker-contracts.aspx

      private async static Task<StorageItemThumbnail> GetTypeThumbnailAsync(String fileType, ThumbnailMode mode) {
         // Gets a thumbnail for a specific file type
         StorageFile file = await ApplicationData.Current.TemporaryFolder.CreateFileAsync("~" + fileType, CreationCollisionOption.GenerateUniqueName);
         StorageItemThumbnail sitn = await file.GetScaledImageAsThumbnailAsync(mode);
         await file.DeleteAsync();
         return sitn;
      }

      private static IAsyncOperation<StorageFile> CreateFileAsync(String desiredName) {
         return DownloadsFolder.CreateFileAsync(desiredName, CreationCollisionOption.GenerateUniqueName);
      }


      internal sealed class Recipe {
         private readonly List<String> m_ingredients = new List<String>();
         public String Title { get; set; }   // Maps to Stream content
         public List<String> Ingredients { get { return m_ingredients; } }   // Maps to System.Keywords property
         public UInt64 MinutesToCreate { get; set; } // Maps to SystemProperties.Media.Duration property
      }

      private static readonly Recipe[] s_recipes = new Recipe[] { 
         new Recipe { Title = "Chicken Parmesan", MinutesToCreate = 45, Ingredients = { "chicken", "cheese", "tomatoes" } },
         new Recipe { Title = "Chicken Teriyaki", MinutesToCreate = 30, Ingredients = { "chicken", "teriyaki", "sauce", "rice" } },
         new Recipe { Title = "Macaroni and Cheese", MinutesToCreate = 20, Ingredients = { "Macaroni", "pasta", "cheese" } },
         new Recipe { Title = "Chicken Alfredo", MinutesToCreate = 45, Ingredients = { "chicken", "Pasta", "alfredo", "sauce" } }            
      };

      private async Task PopulateRecipeContentIndexAsync() {
         // Create or get a reference to a "Recipes" content index:
         ContentIndexer indexer = ContentIndexer.GetIndexer("Recipes");
         await indexer.DeleteAllAsync();  // Clear contents to start fresh

         // If watch this variable in the debugger, you'll see it increment with each operation 
         UInt64 revision = indexer.Revision;

         // Add all the recipes to the index:
         String language = "en-us"; // Use String.Empty if you don't know the language of the stream or properties
         for (Int32 r = 0; r < s_recipes.Length; r++) {
            IndexableContent content = new IndexableContent {
               Id = r.ToString(),      // ID = index into s_recipes array

               // The recipe's title contains the words we want indexed
               StreamContentType = "text/plain",
               Stream = CryptographicBuffer.ConvertStringToBinary(
                  s_recipes[r].Title, BinaryStringEncoding.Utf8).AsStream().AsRandomAccessStream(),

               // For each recipe, the duration is how long it takes to cook & Keywords is the ingredient list
               Properties = { // http://msdn.microsoft.com/en-us/library/dd561977(VS.85).aspx
                  { SystemProperties.Media.Duration, s_recipes[r].MinutesToCreate }, // If you don't know the language
                  { SystemProperties.Keywords, // Keywords are ;-delimited & here I demo how to use a language
                     new ValueAndLanguage { Language = language, Value = String.Join(";", s_recipes[r].Ingredients) } }, 
               }
            };
            await indexer.AddAsync(content);
         }
      }

      private async void Indexer(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         await PopulateRecipeContentIndexAsync();

         // Search for all recipes that have "Chicken" in their title, sauce as an ingredient and that 
         // take 30 minutes or less to make. The results come back sorted in duration order with the duration property.
         // Query for all the items & their properties (AQS: http://msdn.microsoft.com/en-us/library/windows/desktop/bb266512(v=vs.85).aspx)
         ContentIndexer indexer = ContentIndexer.GetIndexer("Recipes");
         ContentIndexerQuery query = indexer.CreateQuery("chicken System.Keywords:\"sauce\" System.Media.Duration:<=30",
            new[] { SystemProperties.Media.Duration },
            new[] { new SortEntry { PropertyName = SystemProperties.Media.Duration, AscendingOrder = true } });

         UInt32 resultCount = await query.GetCountAsync();        // 1
         IReadOnlyList<IIndexableContent> resultItems = await query.GetAsync();
         foreach (var r in resultItems) {
            Int32 recipeIndex = Int32.Parse(r.Id);                // 1
            String recipeTitle = s_recipes[recipeIndex].Title;   // "Chicken Teriyaki"
         }

         // Here's how to update an item's properties (make "Chicken Alfredo" take 20 minutes to cook):
         IndexableContent contentItem = new IndexableContent {
            Id = 3.ToString(),
            Properties = { { SystemProperties.Media.Duration, 20 } } // Use 'null' to delete a property
         };
         await indexer.UpdateAsync(contentItem);

         query = indexer.CreateQuery("chicken System.Keywords:\"sauce\" System.Media.Duration:<=30",
            new[] { SystemProperties.Media.Duration },
            new[] { new SortEntry { PropertyName = SystemProperties.Media.Duration, AscendingOrder = true } });
         resultCount = await query.GetCountAsync();               // 2
         resultItems = await query.GetAsync();
         foreach (var r in resultItems) {
            Int32 recipeIndex = Int32.Parse(r.Id);                // 3, 1
            String recipeTitle = s_recipes[recipeIndex].Title;   // "Chicken Alfredo", "Chicken teriyaki"
         }

         // Get all recipes sorted by duration:
         query = indexer.CreateQuery("*", new[] { SystemProperties.Media.Duration },
            new[] { new SortEntry { PropertyName = SystemProperties.Media.Duration, AscendingOrder = true } });
         resultItems = await query.GetAsync();
         foreach (var r in resultItems) {
            Int32 recipeIndex = Int32.Parse(r.Id);                // 2, 3, 1, 0
            String recipeTitle = s_recipes[recipeIndex].Title;   // Mac & Cheese, Alfredo, Teriyaki, Parmesan
         }

         // Here's how to get all the properties for a query's items:
         IReadOnlyList<IReadOnlyDictionary<String, Object>> itemsProperties = await query.GetPropertiesAsync();
         foreach (IReadOnlyDictionary<String, Object> item in itemsProperties) {
            foreach (var prop in item) {
               var propertyNameAndValue = String.Format("Property: Name={0}, Value={1}", prop.Key, prop.Value);
            }
         }
      }
   }
}
