﻿using Windows.UI.Xaml.Controls;

namespace PackageManifest {
   public sealed partial class MainPage : Page {
      public MainPage() {
         this.InitializeComponent();
      }
   }
}
