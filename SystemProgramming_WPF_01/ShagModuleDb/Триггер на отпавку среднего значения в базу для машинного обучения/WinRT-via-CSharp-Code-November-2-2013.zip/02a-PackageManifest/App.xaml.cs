﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Application template is documented at http://go.microsoft.com/fwlink/?LinkId=234227

namespace PackageManifest {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
      }
      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         // Do not repeat app initialization when already running, just ensure that
         // the window is active
         if (args.PreviousExecutionState == ApplicationExecutionState.Running) {
            Window.Current.Activate();
            return;
         }

         if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
            //TODO: Load state from previously suspended application
         }

         // Create a Frame to act navigation context and navigate to the first page
         var rootFrame = new Frame();
         if (!rootFrame.Navigate(typeof(MainPage))) {
            throw new Exception("Failed to create initial page");
         }

         // Place the frame in the current Window and ensure that it is active
         Window.Current.Content = rootFrame;
         Window.Current.Activate();
      }
   }
}
