﻿/******************************************************************************
Module:  BkgndTransferPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel.Resources.Core;
using Windows.Networking.BackgroundTransfer;
using Windows.Security.Authentication.Web;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.System;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Web;
using Wintellect;
using Wintellect.WinRT.DemoSpecific;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.WebAuthentication;

namespace BackgroundTransfer {
   public sealed partial class BkgndTransferPage : Page {
      private CancellationTokenSource m_cts = new CancellationTokenSource();
      private readonly Progress<DownloadOperation> m_downloadProgress;
      private readonly Progress<UploadOperation> m_uploadProgress;
      private readonly Dictionary<Guid, DownloadOperation> m_downloads = new Dictionary<Guid, DownloadOperation>();
      private readonly Dictionary<Guid, UploadOperation> m_uploads = new Dictionary<Guid, UploadOperation>();

      public BkgndTransferPage() {
         this.InitializeComponent();
         m_downloadProgress = new Progress<DownloadOperation>(DownloadProgress);
         m_uploadProgress = new Progress<UploadOperation>(UploadProgress);
         m_txtUri.Text = "http://video.ch9.ms/build/2011/key01/BUILD2011KeynoteDay1_2MB_ch9.wmv";
         m_txtFileName.Text = Path.GetFileName(m_txtUri.Text);
      }

      private async void AttachToBackgroundTransfers(CancellationToken ct,
         Progress<DownloadOperation> downloadProgress, Action<Task<DownloadOperation>> downloadComplete,
         Progress<UploadOperation> uploadProgress, Action<Task<UploadOperation>> uploadComplete) {

         foreach (DownloadOperation dop in await BackgroundDownloader.GetCurrentDownloadsAsync()) {
            UpdateTransferInfo(dop, null);
            var noWarning = dop.AttachAsync().AsTask(ct, downloadProgress).ContinueWith(downloadComplete);
         }
         foreach (UploadOperation uop in await BackgroundUploader.GetCurrentUploadsAsync()) {
            UpdateTransferInfo(null, uop);
            var noWarning = uop.AttachAsync().AsTask(ct, uploadProgress).ContinueWith(uploadComplete);
         }
      }

      protected async override void OnNavigatedTo(NavigationEventArgs e) {
         Debugger.Break();
         foreach (DownloadOperation dop in await BackgroundDownloader.GetCurrentDownloadsAsync()) {
            UpdateTransferInfo(dop, null);
            dop.AttachAsync().AsTask(m_cts.Token, m_downloadProgress).ContinueWith(t => DownloadComplete(t, dop)).Forget();
         }
         foreach (UploadOperation uop in await BackgroundUploader.GetCurrentUploadsAsync()) {
            UpdateTransferInfo(null, uop);
            uop.AttachAsync().AsTask(m_cts.Token, m_uploadProgress).ContinueWith(UploadComplete).Forget();
         }
      }

      private async void StartDownload(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile sf = await DownloadsFolder.CreateFileAsync(m_txtFileName.Text, CreationCollisionOption.GenerateUniqueName);
         BackgroundDownloader bd = new BackgroundDownloader() { CostPolicy = BackgroundTransferCostPolicy.Default };
         DownloadOperation dop = bd.CreateDownload(new Uri(m_txtUri.Text), sf);
         var r = await BackgroundDownloader.RequestUnconstrainedDownloadsAsync(new[] { dop });
         UpdateTransferInfo(dop, null);
         dop.StartAsync().AsTask(m_cts.Token, m_downloadProgress).ContinueWith(t => DownloadComplete(t, dop)).Forget();
      }
      // For FTP, make URI: "ftp://username:password@server.com/FolderName/FileName.ext"

      private async void DownloadComplete(Task<DownloadOperation> task, DownloadOperation dopIfCanceled) {
         // Called via any thread:
         DownloadOperation dop = null;
         try {
            dop = await task;   // Guaranteed to return immediately
            // LaunchFileAsync MUST run on the GUI thread
            this.RunOnGui(async () => {
               Boolean ok = await Launcher.LaunchFileAsync(dop.ResultFile,
                  new LauncherOptions { DisplayApplicationPicker = true });
            });
         }
         catch (Exception ex) {
            dopIfCanceled.ResultFile.DeleteAsync().Forget();
            if (ex is TaskCanceledException) {
               dop = dopIfCanceled;
               this.RunOnGui(() => {
                  new MessageDialog("Transfer canceled").ShowAsync().Forget();
               });
            }
            WebErrorStatus webErrorStatus = BackgroundTransferError.GetStatus(ex.HResult);
         }
         UpdateTransferInfo(dop, null); // Removes completed, canceled, or failed operation from UI
      }

      private void DownloadProgress(DownloadOperation dop) {
         // Called via GUI thread:
         UpdateTransferInfo(dop, null);
      }

      private async void UploadComplete(Task<UploadOperation> task) {
         // Called via any thread:
         UploadOperation uop = await task;
         UpdateTransferInfo(null, uop);
         // LaunchUriAsync MUST be called via the GUI thread.
         this.RunOnGui(async () => {
            Boolean ok = await Launcher.LaunchUriAsync(new Uri("http://SkyDrive.com/"));
         });
      }

      private void UploadProgress(UploadOperation uop) {
         // Called via GUI thread:
         UpdateTransferInfo(null, uop);
      }

      private void UpdateTransferInfo(DownloadOperation dop, UploadOperation uop) {
         // Make sure this code runs on the GUI thread
         if (this.DispatchToGui(() => UpdateTransferInfo(dop, uop))) return;

         // Update download or upload information
         if (dop != null) m_downloads[dop.Guid] = dop;
         if (uop != null) m_uploads[uop.Guid] = uop;

         // Name, Size or Total, Status, Pause/Resume button
         IEnumerable<String> downloadData = from v in m_downloads.Values
                                            orderby v.Progress.Status, v.ResultFile.Name
                                            let p = v.Progress
                                            select String.Format("Download    {0,-25} {1:N0} / {2:N0} KB    {3}",
                                            p.Status.ToString().PascalCasingToWords(),
                                            p.BytesReceived / 1024, p.TotalBytesToReceive / 1024,
                                            v.ResultFile.Name);

         IEnumerable<String> uploadData = from v in m_uploads.Values
                                          orderby v.Progress.Status, v.SourceFile.Name
                                          let p = v.Progress
                                          select String.Format("Upload      {0,-25} {1:N0} / {2:N0} KB    {3}",
                                          p.Status.ToString().PascalCasingToWords(),
                                          p.BytesSent / 1024, p.TotalBytesToSend / 1024,
                                          v.SourceFile.Name);
         IEnumerable<String> data = downloadData.Concat(uploadData);
         String[] debugData = data.ToArray();
         m_lv.ItemsSource = data;
      }

      private void CancelAll(object sender, RoutedEventArgs e) {
         m_cts.Cancel();
         m_cts = new CancellationTokenSource();
      }

      private async void StartLiveUpload(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Login with the user's LiveID 
         // Configured this Package at http://manage.dev.live.com to get the right clientId
         // User can manage app consent at https://consent.live.com/
         Uri redirectUri = WebAuthenticationBroker.GetCurrentApplicationCallbackUri();
         String clientId = redirectUri.AbsoluteUri;
         String loginUri = WindowsLive.BuildLogInUri(false, clientId, redirectUri, "wl.signin", "wl.skydrive_update");
         WebAuthenticationResult result = await WebAuthenticationBroker.AuthenticateAsync(
            WebAuthenticationOptions.None, new Uri(loginUri), redirectUri);
         if (result.ResponseStatus != WebAuthenticationStatus.Success) return;   // Returns success even if user forbids access
         IDictionary<String, String> claims = result.ResultToClaims();
         if (claims.Keys.Any(k => String.Equals(k, "error", StringComparison.CurrentCultureIgnoreCase))) {
            // If an "error" claim exists, then no access allowed.
            return;
         }

         // Have user select a file to upload
         StorageFile file = await new FileOpenPicker {
            FileTypeFilter = { ".txt", ".png", ".jpg", ".docx", ".pptx", ".xlsx", ".wma", ".mp3" },
            SuggestedStartLocation = PickerLocationId.Desktop,
            CommitButtonText = "Upload"
         }.PickSingleFileAsync();
         if (file == null) return;

         // Start the file upload
         Uri upload = new Uri("https://apis.live.net/v5.0/me/skydrive/files/" + file.Name + "?access_token=" + claims["access_token"]);
         BackgroundUploader bu = new BackgroundUploader { Method = "PUT" };
         UploadOperation uop = bu.CreateUpload(upload, file);
         UpdateTransferInfo(null, uop);
         uop.StartAsync().AsTask(m_cts.Token, m_uploadProgress).ContinueWith(UploadComplete).Forget();
      }

      private static async Task MultipartUploadAsync(IStorageFile photoFile) {
         Uri uri = new Uri("http://flickr.com/services/upload/");
         BackgroundTransferContentPart apiKey = new BackgroundTransferContentPart("api_key");
         apiKey.SetText("3632623532453245");
         BackgroundTransferContentPart authToken = new BackgroundTransferContentPart("auth_token");
         authToken.SetText("436436545");
         BackgroundTransferContentPart apiSig = new BackgroundTransferContentPart("api_sig");
         apiSig.SetText("43732850932746573245");
         BackgroundTransferContentPart dataContent = new BackgroundTransferContentPart("photo", "test.jpg");
         dataContent.SetHeader("Content-Type", "image/jpeg");
         dataContent.SetFile(photoFile);
         BackgroundUploader uploader = new BackgroundUploader();
         UploadOperation uop = await uploader.CreateUploadAsync(uri, new[] { apiKey, authToken, apiSig, dataContent });
         await uop.StartAsync();
#if false
The above will result in the following request being sent to the server:

POST /services/upload/ HTTP/1.1
Content-Type: multipart/form-data; boundary="80a493a8-12dc-4bb9-84b6-632b2e03d2e3"
Host: api.flickr.com
Content-Length: 35261
 
--80a493a8-12dc-4bb9-84b6-632b2e03d2e3
Content-Disposition: form-data; name="api_key"
 
3632623532453245
--80a493a8-12dc-4bb9-84b6-632b2e03d2e3
Content-Disposition: form-data; name="auth_token"
 
436436545
--80a493a8-12dc-4bb9-84b6-632b2e03d2e3
Content-Disposition: form-data; name="api_sig"
 
43732850932746573245
--80a493a8-12dc-4bb9-84b6-632b2e03d2e3
Content-Disposition: form-data; name="photo"; filename="test.jpg"
Content-Type: image/jpeg
 
{RAW JFIF DATA}
--80a493a8-12dc-4bb9-84b6-632b2e03d2e3--

#endif
      }
#if false
         try {
            // User may be signed into LiveId via Windows-associated account
            // If user not signed in, prompt them to signin
            OnlineIdAuthenticator auth = new OnlineIdAuthenticator();
            UserIdentity ui = await auth.AuthenticateUserAsync(new[] { 
               new OnlineIdServiceTicketRequest("jwt.oauth.live.net", "JWT") 
               }, CredentialPromptType.PromptIfNeeded);
         }
         catch (TaskCanceledException) {
            return;  // User decided not to sign in
         }
         catch (COMException ex) {
            Boolean userNotFound = (UInt32)ex.HResult == 0x80070525u;
         }
#endif

      private static class WindowsLive {
         public const String DefaultRedirectUri = "https://oauth.live.com/desktop";
         public const String DefaultLoginUri = "https://oauth.live.com";
         private static readonly Char[] ScopeSeparators = new Char[] { ' ', ',' };
         private const String AuthorizeTemplate = "{0}/authorize?client_id={1}&redirect_uri={2}&scope={3}&response_type={4}&locale={5}&display={6}&theme={7}";
         private const String RefreshTokenPostBodyTemplate = "client_id={0}&refresh_token={1}&scope={2}&grant_type=refresh_token";
         private const String AuthCodePostBodyTemplate = "client_id={0}&code={1}&redirect_uri={2}&grant_type=authorization_code";
         private const String DefaultRedirectPath = "/desktop";
         private const String AuthorizeEndpoint = "/authorize";
         private const String TokenEndpoint = "/token";
         private const String LogoutUrl = "https://login.live.com/logout.srf";

         public static String BuildLogInUri(Boolean silent, String clientId, Uri redirectUri, params String[] scopes) {
            redirectUri = redirectUri ?? new Uri(DefaultLoginUri + DefaultRedirectPath);
            return String.Format(AuthorizeTemplate,
               DefaultLoginUri,
               WebUtility.UrlEncode(clientId),
               WebUtility.UrlEncode(redirectUri.AbsoluteUri),
               WebUtility.UrlEncode(BuildScopeString(scopes)),
               WebUtility.UrlEncode("Token".ToLowerInvariant()),  // or "Code"
               WebUtility.UrlEncode(ResourceContext.GetForCurrentView().Languages[0]),
               (silent ? "none" : WebUtility.UrlEncode("Page".ToLowerInvariant())), // Popup, Tailored, Touch, Page, None
               WebUtility.UrlEncode("Dark".ToLowerInvariant()));  // Dark, Light, Default
         }

         internal static String BuildScopeString(IEnumerable<String> scopes) {
            StringBuilder builder = new StringBuilder();
            if (scopes != null) {
               foreach (String str in scopes) {
                  if (builder.Length > 0) builder.Append(ScopeSeparators[0]);
                  builder.Append(str);
               }
            }
            return builder.ToString();
         }
      }
#if ForSlides
      async void AppInitialize() {
         IReadOnlyList<DownloadOperation> dops = await BackgroundDownloader.GetCurrentDownloadsAsync();
         foreach (DownloadOperation dop in dops) {
            await dop.AttachAsync().AsTask(m_cts.Token, m_progress).ContinueWith(DownloadComplete);
         }
      }

      private async void StartDownload(Uri uri, IStorageFile file, CancellationToken ct) {
         var bd = new BackgroundDownloader { /* Group, CostPolicy, Method (ex: "GET"), ProxyCredential, ServerCredential */ };
         bd.SetRequestHeader("heaader", "value");  // Optional
         bd.SetRequestBodyStreamAsync((IInputStream)null);
         bd.SetRequestBodyFile((IStorageFile)null);
         DownloadOperation dop = bd.CreateDownload(uri, file);
         var p = new Progress<DownloadOperation>(DownloadProgress); 
         await dop.StartAsync().AsTask(ct, new Progress<DownloadOperation>(DownloadProgress)).ContinueWith(DownloadDone);
         /*
               public IAsyncOperationWithProgress<DownloadOperation, DownloadOperation> AttachAsync();
               public ResponseInformation GetResponseInformation();
               public IInputStream GetResultStreamAt(ulong position);
               public void Pause();
               public void Resume();
               public IAsyncOperationWithProgress<DownloadOperation, DownloadOperation> StartAsync();
                  */
      }
      private void DownloadProgress(DownloadOperation dop) {
         // DownloadOperation's known properties: Group, CostPolicy, Method, RequestedUri, ResultFile
         // Additional properties: Guid, Progress
         // Progress' properties: Status, TotalBytesToReceive, BytesReceived, HasResponseChanged, HasRestarted
         // Status: Idle, Running, PausedByApplication/CostedNetwork/NoNetwork, Completed/Canceled/Error
      }
      private void DownloadDone(Task<DownloadOperation> dop) {
      }
#endif
   }
}
