﻿/******************************************************************************
Module:  WebAuthBroker.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Security.Authentication.Web;
using Windows.Security.Cryptography;
using Windows.Security.Cryptography.Core;
using Windows.Storage.Streams;

#if CallExamples
         var result = await WebAuthBroker.FacebookAuthenticateAsync("appIdGoesHere");
         var claims = result.ResultToClaims();

         String serviceNamespace = "wintellect-sts", realm = "https://127.0.0.1:44300";
         var s = await WebAuthBroker.GetAzureAcsIdentityProvidersAsync(serviceNamespace, realm);
         result = await WebAuthBroker.AzureAcsAuthenticateAsync(serviceNamespace, realm, realm);
#endif
namespace Wintellect.WinRT.WebAuthentication {
   public static class WebAuthBroker {
      #region Azure ACS
      public async static Task<AzureAcsIdentityProvider[]> GetAzureAcsIdentityProvidersAsync(String serviceNamespace, String realm, String replyTo = null, String context = null) {
         // http://acs.codeplex.com/wikipage?title=Login%20Pages
         String idpsJsonEndpoint = String.Format(
            "https://{0}.accesscontrol.windows.net/v2/metadata/IdentityProviders.js" +
            "?protocol=wsfederation&realm={1}&reply_to={2}&context={3}&version=1.0",
            serviceNamespace, realm, replyTo, context);
         using (var s = await new HttpClient().GetStreamAsync(idpsJsonEndpoint)) {
            var i = (AzureAcsIdentityProvider[])new DataContractJsonSerializer(typeof(AzureAcsIdentityProvider[])).ReadObject(s);
            return i;
         }
      }

      public static IAsyncOperation<WebAuthenticationResult> AzureAcsAuthenticateAsync(String serviceNamespace, String realm, String callbackUri) {
         String wsFederationEndpoint = String.Format(
            "https://{0}.accesscontrol.windows.net/v2/wsfederation?wa=wsignin1.0&wtrealm={1}&redirect=true",
            serviceNamespace, realm);
         Uri cbUri = WebAuthenticationBroker.GetCurrentApplicationCallbackUri();
         return AuthenticateAsync(wsFederationEndpoint, callbackUri);
      }
      public static IDictionary<String, String> ParseAzureAcsResult(this WebAuthenticationResult result) {
         var claims = new Dictionary<String, String>();
         foreach (var t in result.ResponseData.Split('&')) {
            var parts = t.Split('=');
            claims.Add(WebUtility.UrlDecode(parts[0]), WebUtility.UrlDecode(parts[1]));
         }
         return claims;
      }
      #endregion

      #region Facebook
      public static IAsyncOperation<WebAuthenticationResult> FacebookAuthenticateAsync(String appId) {
         const String redirectUri = "https://www.facebook.com/connect/login_success.html";
         var requestUri = String.Format("https://www.facebook.com/dialog/oauth?client_id={0}&redirect_uri={1}&response_type=token",
            appId, redirectUri);
         //var pattern = String.Format("{0}#access_token={1}&expires_in={2}", redirectUri, "(?.+)", "(?.+)");

         return AuthenticateAsync(requestUri, redirectUri);
      }

      public static IDictionary<String, String> ResultToClaims(this WebAuthenticationResult result) {
         String[] claimNamesAndValues = result.ResponseData.Substring(result.ResponseData.IndexOf('#') + 1).Split('=', '&');
         var claims = new Dictionary<String, String>();
         for (Int32 claim = 0; claim < claimNamesAndValues.Length; claim += 2) {
            claims.Add(claimNamesAndValues[claim], claimNamesAndValues[claim + 1]);
         }
         return claims;
      }
      #endregion

      #region Windows Live
      public static IAsyncOperation<WebAuthenticationResult> WindowsLiveAuthenticateAsync(String clientId, String callbackUri) {
         String requestUri = String.Format("https://beta.oauth.live.com/authorize?client_id={0}&redirect_uri={1}&display=popup&response_type=token&scope=wl.basic",
            clientId, Uri.EscapeUriString(callbackUri));
         return AuthenticateAsync(requestUri, callbackUri);
      }
      #endregion

      #region Google
      public static IAsyncOperation<WebAuthenticationResult> GoogleAuthenticateAsync(String clientId, String callbackUri) {
         String requestUri = String.Format("https://accounts.google.com/o/oauth2/auth?client_id={0}&redirect_uri={1}&response_type=code&scope=http://picasaweb.google.com/data",
            clientId, Uri.EscapeUriString(callbackUri));
         return AuthenticateAsync(requestUri, "https://accounts.google.com/o/oauth2/approval?");
      }
      #endregion

      #region Flickr
#if false
      public static IAsyncOperation<WebAuthenticationResult> FlickrAuthenticateAsync(String clientId, String secret, String callbackUri) {
         // Acquiring a request token 
         TimeSpan SinceEpoch = (DateTimeOffset.Now - new DateTimeOffset(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());   // JMR: Fix
         Random Rand = new Random();
         String FlickrUrl = "https://secure.flickr.com/services/oauth/request_token";
         Int32 Nonce = Rand.Next(1000000000);

         // Compute base signature string and sign it. 
         //    This is a common operation that is required for all requests even after the token is obtained. 
         //    Parameters need to be sorted in alphabetical order 
         //    Keys and values should be URL Encoded. 
         String SigBaseStringParams = "oauth_callback=" + WebUtility.UrlEncode(callbackUri);
         SigBaseStringParams += "&" + "oauth_consumer_key=" + clientId;
         SigBaseStringParams += "&" + "oauth_nonce=" + Nonce.ToString();
         SigBaseStringParams += "&" + "oauth_signature_method=HMAC-SHA1";
         SigBaseStringParams += "&" + "oauth_timestamp=" + Math.Round(SinceEpoch.TotalSeconds);
         SigBaseStringParams += "&" + "oauth_version=1.0";
         String SigBaseString = "GET&";
         SigBaseString += WebUtility.UrlEncode(FlickrUrl) + "&" + WebUtility.UrlEncode(SigBaseStringParams);

         IBuffer KeyMaterial = CryptographicBuffer.ConvertStringToBinary(secret + "&", BinaryStringEncoding.Utf8);
         MacAlgorithmProvider HmacSha1Provider = MacAlgorithmProvider.OpenAlgorithm("HMAC_SHA1");
         CryptographicKey MacKey = HmacSha1Provider.CreateKey(KeyMaterial);
         IBuffer DataToBeSigned = CryptographicBuffer.ConvertStringToBinary(SigBaseString, BinaryStringEncoding.Utf8);
         IBuffer SignatureBuffer = CryptographicEngine.Sign(MacKey, DataToBeSigned);
         String Signature = CryptographicBuffer.EncodeToBase64String(SignatureBuffer);

         FlickrUrl += "?" + SigBaseStringParams + "&oauth_signature=" + WebUtility.UrlEncode(Signature);
         var response = FlickrSendData(FlickrUrl);

         if (response == null) return null;
         String oauth_token = null;
         String oauth_token_secret = null;
         String[] keyValPairs = response.Split('&');

         for (int i = 0; i < keyValPairs.Length; i++) {
            String[] splits = keyValPairs[i].Split('=');
            switch (splits[0]) {
               case "oauth_token": oauth_token = splits[1]; break;
               case "oauth_token_secret": oauth_token_secret = splits[1]; break;
            }
         }
         if (oauth_token == null) return null;
         FlickrUrl = "https://secure.flickr.com/services/oauth/authorize?oauth_token=" + oauth_token + "&perms=read";
         return AuthenticateAsync(FlickrUrl, callbackUri);
      }

      private static String FlickrSendData(String Url) {
         try {
            HttpWebRequest Request = (HttpWebRequest)WebRequest.Create(Url);
            Request.Method = "GET";
            HttpWebResponse Response = (HttpWebResponse)await Request.GetResponseAsync();
            StreamReader ResponseDataStream = new StreamReader(Response.GetResponseStream());
            return ResponseDataStream.ReadToEnd();
         }
         catch (Exception ex) { }
      }
#endif
      #endregion

      #region Twitter (TODO)
      #endregion

      private static IAsyncOperation<WebAuthenticationResult> AuthenticateAsync(String requestUri, String callbackUri) {
         return WebAuthenticationBroker.AuthenticateAsync(WebAuthenticationOptions.None, new Uri(requestUri), new Uri(callbackUri));
      }

      public static String ParseQueryString(this String query, String param) {
         var result = new Dictionary<String, Object>();
         String decoded = query;
         Int32 decodedLength = decoded.Length;
         Int32 namePos = 0;
         Boolean first = true;

         while (namePos <= decodedLength) {
            int valuePos = -1, valueEnd = -1;
            for (int q = namePos; q < decodedLength; q++) {
               if (valuePos == -1 && decoded[q] == '=') {
                  valuePos = q + 1;
               } else if (decoded[q] == '&' || decoded[q] == '#') {
                  valueEnd = q;
                  break;
               }
            }

            if (first) {
               first = false;
               if (decoded[namePos] == '#') {
                  namePos++;
               }
            }

            String name, value;
            if (valuePos == -1) {
               name = null;
               valuePos = namePos;
            } else {
               //name = UrlDecode(decoded.Substring(namePos, valuePos - namePos - 1));
               name = decoded.Substring(namePos, valuePos - namePos - 1);
            }

            if (valueEnd < 0) {
               namePos = -1;
               valueEnd = decoded.Length;
            } else {
               namePos = valueEnd + 1;
            }

            //value = UrlDecode(decoded.Substring(valuePos, valueEnd - valuePos));
            value = decoded.Substring(valuePos, valueEnd - valuePos);

            if (!string.IsNullOrEmpty(name)) {
               result[name] = value;
            }

            if (namePos == -1) {
               break;
            }
         }
         return result[param].ToString();
      }
   }

#if false
   public struct FacebookAuth {
      public String AcessToken;
      public Int32 ExpiresIn;
   }
#endif

   [DataContract]
   public struct AzureAcsIdentityProvider {
      [DataMember]
      public String Name;
      [DataMember]
      public String LoginUrl;
      [DataMember]
      public String LogoutUrl;
      [DataMember]
      public String ImageUrl;
      [DataMember]
      public String[] EmailAddressSuffixes;
   }
}