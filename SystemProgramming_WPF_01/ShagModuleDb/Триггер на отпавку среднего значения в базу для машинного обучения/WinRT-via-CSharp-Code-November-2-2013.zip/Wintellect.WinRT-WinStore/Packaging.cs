﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
#if WindowsStore
using Windows.UI; // For Color & Colors
using Windows.Storage;
#else
using System.Windows.Media;   // For Color & Colors
#endif
using System.Globalization;
using System.Diagnostics;

internal static class ManifestPackageExtensions {
   private static readonly XNamespace xmlns = "http://schemas.microsoft.com/appx/2010/manifest";
   public static String AttributeValue(this XElement element, String name) {
      XAttribute attr = element.Attribute(xmlns + name); // Try with namespace
      if (attr != null) return attr.Value;

      attr = element.Attribute(name);  // Try without namespace
      return (attr == null) ? null : attr.Value;
   }
   private static IEnumerable<T> NullToEmptyCollection<T>(this IEnumerable<T> source) {
      return (source != null) ? source : Enumerable.Empty<T>();
   }
}

namespace Wintellect.WinRT.Packaging {
   public sealed class PackageManifest {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211453.aspx
      public Identity Identity { get; set; }
      public Properties Properties { get; set; }
      public IEnumerable<Resource> Resources { get; set; }
      public Prerequisites Prerequisites { get; set; }
      public IEnumerable<PackageDependency> Dependencies { get; set; }
      public IEnumerable<Capability> Capabilities { get; set; }
      public IEnumerable<Extension> Extensions { get; set; }
      public IEnumerable<Application> Applications { get; set; }

      #region

      public static PackageManifest FromXml(XElement root) {
         var p = new PackageManifest();
         Go(p, root);
         return p;
      }

      private static void Go(Object o, XElement root) {
         foreach (var v in root.Attributes()) {
            var pi = o.GetType().GetTypeInfo().DeclaredProperties.FirstOrDefault(p => p.Name == v.Name.LocalName);
            if (pi == null) continue;
            pi.SetValue(o, ProcessValue(pi.PropertyType, v.Value));
         }
         foreach (var v in root.Elements()) {
            var pi = o.GetType().GetTypeInfo().DeclaredProperties.FirstOrDefault(p => p.Name == v.Name.LocalName);
            if (pi == null) continue;
            pi.SetValue(o, ProcessValue(pi.PropertyType, v.Value, v));
         }
      }

      private static Object ProcessValue(Type propertyType, String value, XElement element = null) {
         if (propertyType == typeof(Boolean)) return Boolean.Parse(value);
         if (IsPrimitive(propertyType)) return value;
         if (propertyType.GetTypeInfo().IsEnum) return Enum.Parse(propertyType, value, true);
         if (propertyType == typeof(Color)) return ParseColor(value);

         if (propertyType.GetTypeInfo().IsGenericType && propertyType.GetTypeInfo().GetGenericTypeDefinition() == typeof(IEnumerable<>)) {
            Type itemType = propertyType.GetTypeInfo().GenericTypeArguments[0];
            var collection = Activator.CreateInstance(typeof(List<>).MakeGenericType(itemType));
            var addMethod = collection.GetType().GetTypeInfo().DeclaredMethods.First(m => m.Name == "Add");
            foreach (var itemXml in element.Elements()) {
               Object itemObj;
               if (itemType != typeof(Extension)) {
                  itemObj = Activator.CreateInstance(itemType);
                  Go(itemObj, itemXml);
               } else {
                  itemObj = Extension.CreateInstance(itemXml);
                  var children = itemXml.Elements();
                  if (children.Any()) Go(itemObj, children.First());
               }
               addMethod.Invoke(collection, new[] { itemObj });
            }
            return collection;
         }
         var prop = Activator.CreateInstance(propertyType);
         IDeserialize d = prop as IDeserialize;
         if (d != null) d.Deserialize(element);
         else Go(prop, element);
         return prop;
      }

      private static readonly Type[] PrimitiveTypes = new[] { typeof(String), typeof(Boolean), typeof(Int32) };
      private static Boolean IsPrimitive(Type t) {
         return Array.IndexOf(PrimitiveTypes, t) != -1;
      }
      private static Color ParseColor(String color) {
         var pi = typeof(Colors).GetTypeInfo().DeclaredProperties
            .FirstOrDefault(p => String.Equals(p.Name, color, StringComparison.OrdinalIgnoreCase));
         if (pi != null) return (Color)pi.GetValue(null);
         var c = Int32.Parse(color.Substring(1), NumberStyles.AllowHexSpecifier);
         return Color.FromArgb(0xff, (Byte)((c & 0xff0000) >> 16), (Byte)((c & 0xff00) >> 8), (Byte)((c & 0xff) >> 0));
      }
      #endregion

#if WindowsStore
      public static async Task<PackageManifest> LoadAsync() {
         String packageDirectory = Windows.ApplicationModel.Package.Current.InstalledLocation.Path;
         packageDirectory = Path.Combine(packageDirectory, "AppxManifest.xml");
         String xml = await PathIO.ReadTextAsync(packageDirectory);
         xml = xml.Substring(xml.IndexOf('<'));
         return PackageManifest.FromXml(XElement.Parse(xml));// JMR: XDocument???
      }
#else
      public static PackageManifest Load(String packageDirectory) {
         packageDirectory = Path.Combine(packageDirectory, "AppxManifest.xml");
         if (!File.Exists(packageDirectory)) return null;
         String xml = File.ReadAllText(packageDirectory);
         xml = xml.Substring(xml.IndexOf('<'));
         return PackageManifest.FromXml(XDocument.Parse(xml).Root);
      }
#endif
   }

   public sealed class Identity {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211441.aspx
      public String Name { get; set; }
      public String ProcessorArchitecture { get; set; }  // Enum
      public String Publisher { get; set; }
      public String ResourceId { get; set; }
      public String Version { get; set; }
      public override string ToString() { return Name; }
      public String ToPackageName(Boolean full = false) {
         return String.Format(full ? "{0} ({1}) [Ver={2}, CPU={3}, ResourceId={4}]" : "{0} ({1})",
            Name, Publisher, Version, ProcessorArchitecture, ResourceId);
      }
   }

   public sealed class Properties {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211457.aspx
      public String Description { get; set; }
      public String DisplayName { get; set; }
      public String Framework { get; set; }  // Boolean
      public String Logo { get; set; }
      public String PublisherDisplayName { get; set; }
      public override string ToString() { return DisplayName; }
   }

   public sealed class Resource {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211461.aspx
      public String Language { get; set; }
      public override string ToString() { return Language; }
   }

   public sealed class Prerequisites {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211456.aspx
      public String OSMaxVersionTested { get; set; }
      public String OSMinVersion { get; set; }
      public override string ToString() { return OSMaxVersionTested; }

   }

   public sealed class PackageDependency {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211454.aspx
      public String MinVersion { get; set; }
      public String Name { get; set; }
      public String Publisher { get; set; }
      public IEnumerable<PackageDependency> Dependencies { get; set; }
      public override string ToString() { return Name; }
   }

   public sealed class Capability {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211422.aspx
      public String Name { get; set; }
      public override string ToString() { return Name; }
   }

   public sealed class Application {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211415.aspx
      public String EntryPoint { get; set; }
      public String Executable { get; set; }
      public String Id { get; set; }
      public String StartPage { get; set; }
      public IEnumerable<Extension> Extensions { get; set; }
      public IEnumerable<Rule> ApplicationContentUriRules { get; set; }
      public VisualElements VisualElements { get; set; }
      public override string ToString() { return Id; }
   }

   public sealed class Rule {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211463.aspx
      public String Match { get; set; }
      public String Type { get; set; } // Enum: Include, Exclude
   }

   public sealed class VisualElements {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211471.aspx
      public String DisplayName { get; set; }
      public String Square150x150Logo { get; set; }
      public String Square30x30Logo { get; set; }
      public String SmallLogo { get; set; }
      public String Description { get; set; }
      public String ForegroundText { get; set; }
      public Color BackgroundColor { get; set; }
      public String ToastCapable { get; set; }
      public DefaultTile DefaultTile { get; set; }
      public LockScreen LockScreen { get; set; }
      public SplashScreen SplashScreen { get; set; }
      public IEnumerable<Rotation> InitialRotationPreference { get; set; }
      public override String ToString() { return DisplayName; }
   }
   public sealed class DefaultTile {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211427.aspx
      public String Wide310x150Logo { get; set; }
      public String DefaultSize { get; set; } // JMR: Change to enum
      public String Square310x310Logo { get; set; }
      public String Square70x70Logo { get; set; }
      public String ShortName { get; set; }
      public IEnumerable<ShowNameOnTiles> ShowNameOnTiles { get; set; }
      public override string ToString() { return ShortName; }
   }

   public sealed class ShowNameOnTiles {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211422.aspx
      public String Tile { get; set; }
      public override string ToString() { return Tile; }
   }

   public enum RotationPreference { Portrait, Landscape, PortraitFlipped, LandscapeFlipped }
   public sealed class Rotation {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211427.aspx
      public RotationPreference Preference { get; set; }  // Enum: Portait, Landscape, PortraitFlipped, LandscapeFlipped
      public override string ToString() { return Preference.ToString(); }
   }

   public enum LockScreenNotification { Badge, BadgeAndTileText }
   public sealed class LockScreen {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211448.aspx
      public String BadgeLogo { get; set; }
      public LockScreenNotification Notification { get; set; }  // Enum: Bagde, BadgeAndTile
      public override string ToString() { return Notification.ToString(); }
   }

   public sealed class SplashScreen {
      // http://msdn.microsoft.com/en-us/library/windows/apps/br211467.aspx
      public Color BackgroundColor { get; set; }
      public String Image { get; set; }
      public override string ToString() { return Image; }
   }
}


namespace Wintellect.WinRT.Packaging {
   public enum ExtensionCategory {
      Unknown = 0,

      // Package extensions (http://msdn.microsoft.com/en-us/library/windows/apps/br211434.aspx):
      Certificates,
      GameExplorer,
      InProcessServer,
      OutOfProcessServer,
      ProxyStub,

      // App extensions (http://msdn.microsoft.com/en-us/library/windows/apps/br211400.aspx):
      FileTypeAssociation,
      Protocol,
      AutoPlayContent,
      AutoPlayDevice,
      ShareTarget,
      Search,
      FileOpenPicker,
      FileSavePicker,
      CachedFileUpdater,
      ContactPicker,
      BackgroundTasks,
      CameraSettings,
      AccountPictureProvider,
      PrintTaskSettings
   }

   public class Extension {
      public static Extension CreateInstance(XElement element) {
         var category = CategoryFromElement(element);
         Extension extension;
         if (category == ExtensionCategory.Unknown) {
            extension = new Extension();
         } else {
            var fn = typeof(InProcessServerExtension).FullName;
            var prefix = fn.Substring(0, fn.Length - typeof(InProcessServerExtension).Name.Length);
            Type t = Type.GetType(prefix + category.ToString() + "Extension");
            if (t == null) Debugger.Break();
            extension = (Extension)Activator.CreateInstance(t);
         }
         extension.Category = category;
         return extension;
      }

      private static ExtensionCategory CategoryFromElement(XElement element) {
         // Truncate "windows."
         String category = element.Attribute("Category").Value;
         var lastSymbol = category.LastIndexOf('.');
         if (lastSymbol != -1) category = category.Substring(lastSymbol + 1);
         try {
            return (ExtensionCategory)Enum.Parse(typeof(ExtensionCategory), category, true);
         }
         catch (ArgumentException) { return ExtensionCategory.Unknown; }
      }

      public Extension() { }
      public ExtensionCategory Category { get; set; }
      public String EntryPoint { get; set; }
      public String Executable { get; set; }
      public String RuntimeType { get; set; }
      public String StartPage { get; set; }
      public override string ToString() {
         var vals = new List<String>();
         if (Executable != null) vals.Add("Executable=" + Executable);
         if (EntryPoint != null) vals.Add("EntryPoint=" + EntryPoint);
         if (StartPage != null) vals.Add("StartPage=" + StartPage);
         if (RuntimeType != null) vals.Add("RuntimeType=" + RuntimeType);
         return String.Join(", ", vals);
      }
   }

   #region Package Extensions
   public sealed class GameExplorerExtension : Extension {
      public GameExplorerExtension GameExplorer { get; set; }
   }
   public sealed class GameExplorer {
      public String GameDefinitionContainer { get; set; }
   }

   public sealed class CertificatesExtension : Extension {
      public Certificate Certificate { get; set; }
      public SelectionCriteria SelectionCriteria { get; set; }
      public TrustFlags TrustFlags { get; set; }
   }
   public sealed class Certificate {
      public String Content { get; set; }
      public String StoreName { get; set; }
   }
   public sealed class SelectionCriteria {
      public Boolean? HardwareOnly { get; set; }
      public Boolean? AutoSelect { get; set; }
   }
   public sealed class TrustFlags {
      public Boolean ExclusiveTrust { get; set; }
   }

   public sealed class InProcessServerExtension : Extension {
      public String Path { get; set; }
      public ActivatableClass ActivatableClass { get; set; }
#if false
             * <Extension Category="windows.activatableClass.inProcessServer" xmlns="http://schemas.microsoft.com/appx/2010/manifest">
  <InProcessServer>
    <Path>Netflix.Windows.Media.SourcePlugin.dll</Path>
    <ActivatableClass ActivatableClassId="Netflix.Windows.Media.SourcePlugin.SchemeHandler" ThreadingModel="both" />
  </InProcessServer>
</Extension>
#endif
   }

   public sealed class ActivatableClass {
      public String ActivatableClassId { get; set; }
      public String ThreadingModel { get; set; } // Both, Sta, Mta
   }

   public sealed class OutOfProcessServerExtension : Extension {
   }

   public sealed class ProxyStubExtension : Extension {
      public ProxyStubExtension() {
#if false
              <Extension Category="windows.activatableClass.proxyStub" xmlns="http://schemas.microsoft.com/appx/2010/manifest">
     <ProxyStub ClassId="B2596805-D20B-4750-A6AC-0251A1EFA1DE">
       <Path>Microsoft.Media.AdaptiveStreaming.dll</Path>
       <Interface InterfaceId="D733C279-BF63-4eb3-9D7F-6BA5402B621C" Name="ManifestReadyEventHandler" />
       <Interface InterfaceId="B0B48161-0DB5-439B-9FF0-200BED06CC48" Name="AdaptiveSourceStatusUpdatedEventHandler" />
       <Interface InterfaceId="2D30413E-09B4-4A43-8F8B-C592F1E41B5F" Name="AdaptiveSourceFailedEventHandler" />
       <Interface InterfaceId="3D0CDB1E-1E78-4c45-B9CC-04041804AD5A" Name="AdaptiveSourceClosedEventHandler" />
       <Interface InterfaceId="63B289C6-5181-4284-90DC-94D03FBE12F2" Name="AdaptiveSourceOpenedEventHandler" />
     </ProxyStub>
   </Extension>
#endif
      }
   }
   #endregion

   #region App Extensions
   public sealed class FileTypeAssociationExtension : Extension {
      public FileTypeAssociationExtension() { }
      public String Name { get; set; }
      public String DisplayName { get; set; }
      public String Logo { get; set; }
      public String InfoTip { get; set; }
      public EditFlags EditFlags { get; set; }
      public SupportedFileTypes SupportedFileTypes { get; set; }
      public override string ToString() {
         return String.Format("Name={0}, DisplayName={1}, {2}", Name, DisplayName, SupportedFileTypes.ToString());
      }
   }
   public sealed class EditFlags {
      public EditFlags() {
         /*var attr = element.Attribute("OpenIsSafe");
         OpenIsSafe = (attr == null) ? false : Boolean.Parse(attr.Value);

         attr = element.Attribute("AlwaysUnsafe");
         AlwaysUnsafe = (attr == null) ? false : Boolean.Parse(attr.Value);
         //<EditFlags OpenIsSafe="true" AlwaysUnsafe="false" />
          * */
      }
      public Boolean OpenIsSafe { get; set; }
      public Boolean AlwaysUnsafe { get; set; }
   }

   public sealed class ProtocolExtension : Extension {
      public ProtocolExtension() { }
      public String Name { get; set; }
      public String DisplayName { get; set; }
      public String Logo { get; set; }
      public override string ToString() {
         return String.Format("Name={0}", Name);
      }
   }

   #region AutoPlayContent & Device extensions
   public sealed class AutoPlayContentExtension : Extension {
      public AutoPlayContentExtension() {
         /*var ee = FirstChild(element);
         LaunchActions = from la in ee.Elements("LaunchAction") select new LaunchAction(la);*/
      }
      public IEnumerable<LaunchAction> LaunchActions { get; set; }
   }

   public sealed class AutoPlayDeviceExtension : Extension {
      public AutoPlayDeviceExtension() {
         /*var ee = FirstChild(element);
         LaunchActions = from la in ee.Elements("LaunchAction") select new LaunchAction(la);*/
      }
      public IEnumerable<LaunchAction> LaunchActions { get; set; }
   }
   public sealed class LaunchAction {
      public LaunchAction() {
         /*Verb = element.Attribute("Verb").Value;
         ActionDisplayName = element.Attribute("ActionDisplayName").Value;
         ContentEvent = element.Attribute("ContentEvent").Value;*/
      }
      public String Verb { get; set; }
      public String ActionDisplayName { get; set; }
      public String ContentEvent { get; set; }
   }
   #endregion

   public sealed class ShareTargetExtension : Extension {
      public SupportedFileTypes SupportedFileTypes { get; set; }
      public IEnumerable<String> DataFormats { get; set; }
      public override string ToString() {
         var s = "Data formats=" + ((DataFormats == null) ? "(none)" : String.Join(", ", DataFormats));
         if (SupportedFileTypes != null) s += "; " + SupportedFileTypes;
         return s;
      }
   }

   public sealed class SearchExtension : Extension { }

   #region File-related extensions
   public sealed class FileOpenPickerExtension : Extension {
      public SupportedFileTypes SupportedFileTypes { get; set; }
      public override string ToString() { return SupportedFileTypes.ToString(); }
   }

   public sealed class FileSavePickerExtension : Extension {
      public SupportedFileTypes SupportedFileTypes { get; set; }
      public override string ToString() { return SupportedFileTypes.ToString(); }
   }

   public sealed class CachedFileUpdaterExtension : Extension { }
   #endregion

   public sealed class ContactPickerExtension : Extension {
      public ContactPickerExtension() { }
   }

   public sealed class BackgroundTasksExtension : Extension, IDeserialize {
      public BackgroundTasksExtension() { }
      public String ServerName { get; set; }
      public IEnumerable<BackgroundTaskType> Task { get; set; }
      public override String ToString() {
         return String.Format("ServerName={0}, Types={1}", ServerName, String.Join(", ", Task));
      }

      void IDeserialize.Deserialize(XElement element) {
         var taskTypes = new List<BackgroundTaskType>();
         foreach (var child in element.Elements()) {
            var value = element.AttributeValue("Type");
            taskTypes.Add((BackgroundTaskType)Enum.Parse(typeof(BackgroundTaskType), value));
         }
         Task = taskTypes;
      }
   }
   [Flags]
   public enum BackgroundTaskType {
      Audio = 1,
      ControlChannel = 2,
      SystemEvent = 4,
      Timer = 8,
      PushNotification = 16,
      Xxx = 32,
      Yyy = 64,
      Zzz = 128,
      Location = 256
   }


   public sealed class CameraSettingsExtension : Extension { }
   public sealed class AccountPictureProviderExtension : Extension { }
   public sealed class PrintTaskSettingsExtension : Extension { }
   #endregion

   #region SupportedFileTypes used by FileTypeAssociation, ShareTarget, FileOpenPicker, & FileSavePicker
   internal interface IDeserialize {
      void Deserialize(XElement element);
   }

   public sealed class SupportedFileTypes : IDeserialize {
      public IEnumerable<FileType> FileTypes { get; set; }
      public Boolean SupportsAnyFileType { get; set; }
      void IDeserialize.Deserialize(XElement element) {
         var fileTypes = new List<FileType>();
         foreach (var child in element.Elements()) {
            if (child.Name.LocalName == "SupportsAnyFileType") SupportsAnyFileType = true;
            if (child.Name.LocalName == "FileType") fileTypes.Add(new FileType { ContentType = child.AttributeValue("ContentType"), Value = child.Value });
         }
         FileTypes = fileTypes;
      }
      public override string ToString() {
         String s = "File types: ";
         if (SupportsAnyFileType) { s += "Any"; if (FileTypes.Any()) s += ", "; }
         s += String.Join(", ", FileTypes);
         return s;
      }
   }

   public sealed class FileType {
      public String ContentType { get; set; }
      public String Value { get; set; }
      public override String ToString() {
         if (ContentType == null) return Value;
         return ContentType + "=" + Value;
      }
   }
   #endregion
}