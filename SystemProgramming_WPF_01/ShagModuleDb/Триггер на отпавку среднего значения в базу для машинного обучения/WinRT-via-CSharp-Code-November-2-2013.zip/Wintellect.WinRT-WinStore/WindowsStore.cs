﻿/******************************************************************************
Module:  WindowsStore.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel.Store;
using Windows.Storage;

namespace Wintellect.WinRT.WindowsStore.Receipts {
   public abstract class WindowsStoreReceipt {
      public String Version { get; private set; }
      public DateTimeOffset ReceiptDate { get; private set; }
      public String CeritficateId { get; private set; }
      public String ReceiptDeviceId { get; private set; }

      public WindowsStoreReceipt(XElement receiptXml) {
         Version = receiptXml.Attribute("Version").Value;
         ReceiptDate = DateTimeOffset.Parse(receiptXml.Attribute("ReceiptDate").Value);
         CeritficateId = receiptXml.Attribute("CertificateId").Value;
         ReceiptDeviceId = receiptXml.Attribute("ReceiptDeviceId").Value;
      }
   }

   public sealed class WindowsStoreAppReceipt : WindowsStoreReceipt {
      public WindowsStoreAppReceipt(XElement receiptXml)
         : base(receiptXml) {
         var appReceiptXml = receiptXml.Element("AppReceipt");
         Id = appReceiptXml.Attribute("Id").Value;
         AppId = appReceiptXml.Attribute("AppId").Value;
         LicenseType = appReceiptXml.Attribute("LicenseType").Value;
         PurchaseDate = DateTimeOffset.Parse(appReceiptXml.Attribute("PurchaseDate").Value);
         var ed = appReceiptXml.Attribute("ExpirationDate");
         if (ed != null) ExpirationDate = DateTimeOffset.Parse(ed.Value);
      }
      public String Id { get; private set; }
      public String AppId { get; private set; }
      public DateTimeOffset PurchaseDate { get; private set; }
      public DateTimeOffset? ExpirationDate { get; private set; }
      public String LicenseType { get; private set; }
   }

   public sealed class WindowsStoreProductReceipt : WindowsStoreReceipt {
      public WindowsStoreProductReceipt(XElement receiptXml)
         : base(receiptXml) {
         var productReceiptXml = receiptXml.Element("ProductReceipt");
         Id = productReceiptXml.Attribute("Id").Value;
         AppId = productReceiptXml.Attribute("AppId").Value;
         ProductId = productReceiptXml.Attribute("ProductId").Value;
         ProductType = productReceiptXml.Attribute("ProductType").Value;
         var ed = productReceiptXml.Attribute("ExpirationDate");
         if (ed != null) ExpirationDate = DateTimeOffset.Parse(ed.Value);
      }
      public String Id { get; private set; }
      public String AppId { get; private set; }
      public String ProductId { get; private set; }
      public String ProductType { get; private set; }
      public DateTimeOffset? ExpirationDate { get; private set; }
   }
}

namespace Wintellect.WinRT.WindowsStore.Simulator {
   public static class WindowsStoreProxyHelper {
      public static async Task<StorageFolder> GetProxyFolderAsync() {
         // Path.Combine(ApplicationData.Current.LocalFolder.Path, @"Microsoft\Windows Store\ApiData"));
         StorageFolder folder = ApplicationData.Current.LocalFolder;
         folder = await folder.CreateFolderAsync("Microsoft", CreationCollisionOption.OpenIfExists);
         folder = await folder.CreateFolderAsync("Windows Store", CreationCollisionOption.OpenIfExists);
         folder = await folder.CreateFolderAsync("ApiData", CreationCollisionOption.OpenIfExists);
         return folder;
      }

      public static XDocument UpdateProxyXml(this LicenseInformation licenseInformation, XDocument proxyXml, String currentMarket = null) {
         XElement licenseInfoElement = proxyXml.Element("CurrentApp").Element("LicenseInformation");
         XElement appElement = licenseInfoElement.Element("App");
         appElement.Element("IsActive").SetValue(licenseInformation.IsActive);
         appElement.Element("IsTrial").SetValue(licenseInformation.IsTrial);
         //appElement.Element("ExpirationDate").SetValue(li.ExpirationDate);
         if (currentMarket != null) appElement.Element("CurrentMarket").SetValue(currentMarket);

         foreach (var productElement in licenseInfoElement.Elements("Product")) {
            String productId = (String)productElement.Attribute("ProductId");
            productElement.Element("IsActive").SetValue(licenseInformation.ProductLicenses[productId].IsActive);
         }
         return proxyXml;
      }
   }

   public sealed class CurrentAppDefinition : ProxyXmlBase {
      public ListingDefinition ListingInformation { get; set; }   // Can't be null
      public LicenseDefinition LicenseInformation { get; set; }   // Can't be null
      public IEnumerable<ConsumableProductDefinition> ConsumableInformation { get; set; }
      public SimulationDefinition Simulation { get; set; }
      public XDocument ToXml() {
         return new XDocument(
            new XDeclaration("1.0", "utf-16", null),
            ToXElement("CurrentApp",
               ListingInformation.ToXml(),
               LicenseInformation.ToXml(),
               (ConsumableInformation == null) ? null : new XElement("ConsumableInformation", ConsumableInformation.Select(cp => cp.ToXml())),
               (Simulation == null) ? null : Simulation.ToXml()));
      }
   }

   #region ListingDefinition Classes
   public sealed class ListingDefinition {
      public ListingDefinition() { Products = Enumerable.Empty<ProductListingDefinition>(); }
      public AppListingDefinition App { get; set; }
      public IEnumerable<ProductListingDefinition> Products { get; set; }
      public XElement ToXml() {
         return new XElement("ListingInformation",
            App.ToXml(), 
            Products.Select(p => p.ToXml()));
      }
   }
   public sealed class AppListingDefinition {
      public Guid AppId { get; set; }
      public Uri LinkUri { get; set; }
      public String CurrentMarket { get; set; }
      public UInt32 AgeRating { get; set; }
      public MarketSpecificAppData MarketData { get; set; }
      public XElement ToXml() {
         return new XElement("App",
            new XElement("AppId", AppId),
            new XElement("LinkUri", LinkUri),
            new XElement("CurrentMarket", CurrentMarket),
            new XElement("AgeRating", AgeRating),
            MarketData.ToXml());
      }
   }
   public abstract class MarketSpecificData : ProxyXmlBase {
      public static readonly XNamespace LangNamespace = "http://www.w3.org/XML/1998/namespace";
      protected MarketSpecificData(String lang, String name, String description, Double price, String currencySymbol, String currecyCode) {
         Lang = lang;
         Name = name;
         Description = description;
         Price = price;
         CurrencySymbol = currencySymbol;
         CurrencyCode = currecyCode;
      }
      public String Lang { get; set; }
      public String Name { get; set; }
      public String Description { get; set; }   // Optional for products; not for app
      public Double Price { get; set; }
      public String CurrencySymbol { get; set; }
      public String CurrencyCode { get; set; }  // Optional
      public XElement ToXml() {
         return new XElement("MarketData",
            new XAttribute(LangNamespace + "lang", Lang),
            new XElement("Name", Name),
            (Description == null) ? null : new XElement("Description", Description),
            new XElement("Price", Price),
            new XElement("CurrencySymbol", CurrencySymbol),
            (CurrencyCode == null) ? null : new XElement("CurrencyCode", CurrencyCode));
      }
   }
   public sealed class MarketSpecificAppData : MarketSpecificData {
      public MarketSpecificAppData(String lang, String name, String description, Double price, String currencySymbol, String currencyCode = null)
         : base(lang, name, description, price, currencySymbol, currencyCode) {
      }
   }
   public sealed class MarketSpecificProductData : MarketSpecificData {
      public MarketSpecificProductData(String lang, String name, String description, Double price, String currencySymbol, String currencyCode = null,
         String tag = null, Uri imageUri = null, IEnumerable<String> keywords = null)
         : base(lang, name, description, price, currencySymbol, currencyCode) {
         Tag = tag;
         Keywords = keywords;
         ImageUri = imageUri;
      }
      public String Tag { get; set; }  // Optional
      public IEnumerable<String> Keywords { get; set; }   // Optional: 0 to 10 keywords
      public Uri ImageUri { get; set; }   // Optional
      new public XElement ToXml() {
         XElement node = base.ToXml();
         if (Tag != null) node.LastNode.AddAfterSelf(new XElement("Tag", Tag));
         if (ImageUri != null) node.LastNode.AddAfterSelf(new XElement("ImageUri", ImageUri));
         if (Keywords != null) node.LastNode.AddAfterSelf(new XElement("Keywords", Keywords.Select(k=> new XElement("Keyword", k))));
         return node;
      }
   }
   public sealed class ProductListingDefinition : ProxyXmlBase {
      public ProductListingDefinition() { MarketData = Enumerable.Empty<MarketSpecificData>(); }
      public String ProductId { get; set; }  // Max=100 characters, pattern="[^,]*"
      public Int32? LicenseDuration { get; set; }  // Optional
      public ProductType ProductType { get; set; } // Optional
      public IEnumerable<MarketSpecificData> MarketData { get; set; }
      public XElement ToXml() {
         return ToXElement("Product",
            MarketData.Select(md => md.ToXml()),
            new XAttribute("ProductId", ProductId),
            (LicenseDuration == null) ? null : new XAttribute("LicenseDuration", LicenseDuration),
            (ProductType == ProductType.Unknown) ? null : new XAttribute("ProductType", ProductType));
      }
   }
   #endregion

   #region LicenseDefinition Classes
   public sealed class LicenseDefinition {
      public AppLicenseDefinition App { get; set; }
      public IEnumerable<ProductLicenseDefinition> Products { get; set; }
      public XElement ToXml() {
         return new XElement("LicenseInformation", 
            App.ToXml(), 
            (Products == null) ? null : Products.Select(p => p.ToXml()));
      }
   }
   public sealed class AppLicenseDefinition : ProxyXmlBase {
      public Boolean IsActive { get; set; }
      public Boolean IsTrial { get; set; }
      public DateTimeOffset? ExpirationDate { get; set; }
      public XElement ToXml() {
         return ToXElement("App",
            new XElement("IsActive", IsActive),
            new XElement("IsTrial", IsTrial),
            (ExpirationDate == null) ? null : new XElement("ExpirationDate", ExpirationDate));
      }
   }
   public abstract class ProxyXmlBase {
      protected XElement ToXElement(XName name, params Object[] content) {
         return new XElement(name, content.Where(c => c != null).ToArray());
      }
   }
   public sealed class ProductLicenseDefinition : ProxyXmlBase {
      public String ProductId { get; set; }
      public String OfferId { get; set; } // Optional
      public Boolean IsActive { get; set; }
      public DateTimeOffset? ExpirationDate { get; set; }   // Optional
      public XElement ToXml() {
         return ToXElement("Product",
            new XAttribute("ProductId", ProductId),
            (OfferId == null) ? null : new XAttribute("OfferId", OfferId),
            new XElement("IsActive", IsActive),
            (ExpirationDate == null) ? null : new XElement("ExpirationDate", ExpirationDate));
      }
   }
   #endregion

   #region ConsumableProductDefinition Classes
   public enum ConsumableStatus {
      Active, PurchaseReverted, PurchasePending, ServerError
   }
   public sealed class ConsumableProductDefinition {
      public String ProductId { get; set; }  // Max 100 characters
      public String OfferId { get; set; }    // Optional: max 100 characters
      public Guid TransactionId { get; set; }
      public ConsumableStatus Status { get; set; }
      public XElement ToXml() {
         return new XElement("Product",
            new XAttribute("ProductId", ProductId),
            new XAttribute("TransactionId", TransactionId),
            new XAttribute("Status", Status),
            (OfferId == null) ? null : new XAttribute("OfferId", OfferId));
      }
   }
   #endregion

   #region SimulationDefinition Classes
   public sealed class SimulationDefinition {
      public SimulationMode SimulationMode { get; set; } // Optional
      public IEnumerable<DefaultResponseDefinition> DefaultResponses { get; set; } // Optional
      public XElement ToXml() {
         return new XElement("Simulation",
            (SimulationMode == SimulationMode.None) ? null : new XAttribute("SimulationMode", SimulationMode),
            (DefaultResponses == null) ? null : DefaultResponses.Select(dr => dr.ToXml()));
      }
   }
   public sealed class DefaultResponseDefinition {
      public StoreMethodName MethodName { get; set; }
      public ReponseCodes HResult { get; set; } // HResult="E_FAIL"
      public XElement ToXml() {
         return new XElement("DefaultResponse", 
            new XAttribute("MethodName", MethodName), 
            new XAttribute("HResult", HResult));
      }
   }
   public enum SimulationMode { None, Interactive, Automatic }
   public enum StoreMethodName {
      RequestAppPurchaseAsync_GetResult,  // id="RPPA"
      RequestProductPurchaseAsync_GetResult, // id="RFPA"
      LoadListingInformationAsync_GetResult, // id="LLIA"
      ReportConsumableFulfillmentAsync_GetResult, // id="RPFA"
      LoadListingInformationByKeywordsAsync_GetResult, // id="LLIKA"
      LoadListingInformationByProductIdAsync_GetResult, // id="LLIPA"
      GetUnfulfilledConsumablesAsync_GetResult, // id="GUC"
      GetAppReceiptAsync_GetResult, // id="GARA"
   }
   public enum ReponseCodes : uint {
      S_OK = 0x00000000,
      E_INVALIDARG = 0x80070057,
      E_CANCELLED = 0x800704C7,
      E_FAIL = 0x80004005,
      E_OUTOFMEMORY = 0x8007000E,
      ERROR_ALREADY_EXISTS = 0x800700B7
   }
   #endregion
}
