﻿/******************************************************************************
Module:  DemoSpecific.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Search;


namespace Wintellect.WinRT.DemoSpecific {
   public static class Demo {
      /// <summary>
      /// When debugging, the debugger will light-dismiss the UI. 
      /// This method delays displaying the UI until the debugger has settled down.
      /// Alternatively, you could debug in the Simulator.
      /// </summary>
      [DebuggerStepThrough]
      public static IAsyncOperation<TResult> DebuggerDelayAsync<TResult>(Func<IAsyncOperation<TResult>> function) {
#if DEBUG
         Task.Delay(2000).Wait();
#endif
         return function();
      }
#if false
       public static T SetSourceAsyncX<T>(this T bitmapSource, IRandomAccessStream stream) where T : BitmapSource
      {
          bitmapSource.SetSourceAsync(stream).NoWarning();
          return bitmapSource;
      }

      public static async Task<T> SetSourceAsyncX<T>(this T bitmapSource, IRandomAccessStream stream) where T : BitmapSource
      {
          await bitmapSource.SetSourceAsync(stream);
          return bitmapSource;
      }
#endif
   }

   public struct WinRTSecrets {
      // NOTE: Instead of calling GetValue, you can return a specific value
      public static String TileAndToastWnsSecurityId { get { return GetValue(); } }
      public static String TileAndToastWnsSecret { get { return GetValue(); } }

      public static String BackgroundTasksWnsSecurityId { get { return GetValue(); } }
      public static String BackgroundTasksWnsSecret { get { return GetValue(); } }

      private static Dictionary<String, String> s_secrets = null;

      private static String GetValue([CallerMemberName] String valueName = null) {
         StorageFile file = null;
         if (s_secrets == null) {
            s_secrets = new Dictionary<String, String>();
            var qo = new QueryOptions(CommonFileQuery.DefaultQuery, new[] { ".WinRTSecrets" }) { FolderDepth = FolderDepth.Deep, IndexerOption = IndexerOption.UseIndexerWhenAvailable };
            try {
               var query = KnownFolders.DocumentsLibrary.CreateFileQueryWithOptions(qo);
               var files = query.GetFilesAsync().AsTask().Result;
               if (files.Count == 0) {
                  throw new FileNotFoundException("Can't find *.WinRTSecrets file in the Documents Library or missing File Type Association declaration.");
               }
               file = files.FirstOrDefault(sf => sf.DisplayName == "Internal");   // If this exsts, use it
               if (file == null) file = files[0];  // Else use whatever is found
               foreach (var line in FileIO.ReadLinesAsync(file).AsTask().Result) {
                  if (String.IsNullOrWhiteSpace(line)) continue;
                  var index = line.IndexOf('=');
                  if (index < 1) continue;
                  s_secrets.Add(line.Substring(0, index), line.Substring(index + 1));
               }
            }
            catch (UnauthorizedAccessException ex) {
               throw new FileNotFoundException("Project requires Document Library capability & File Type Association for '.WinRTSecrets' files.", ex);
            }
         }

         String value = s_secrets[valueName];
         if (String.IsNullOrWhiteSpace(value)) {
            var msg = String.Format("'{0}' info missing; edit the '{1}' file & re-run this app again.", valueName, file.Path);
            throw new ArgumentException(msg);
         }
         return value;
      }
   }
}
