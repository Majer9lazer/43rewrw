﻿/******************************************************************************
Module:  AppExtension.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.Appointments.AppointmentsProvider;
using Windows.ApplicationModel.Contacts;
using Windows.ApplicationModel.Core;
using Windows.Foundation;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Wintellect.WinRT.AppAids {
   public enum ViewType { None, Main, Hosted, Auxiliary }
   public enum LaunchReason { PrimaryTile, SecondaryTile, Toast, Proximity }

   #region App initialization & Activation members
   public static partial class AppAid {
      private static ApplicationInitializationCallback m_appInitCallback;
      private static Func<Frame, IActivatedEventArgs, Task<Boolean>> s_deserializeFramePageStateAsync;
      private static Func<IActivatedEventArgs, Window, Task> s_showSplashScreenAsync;

      /// <summary>Call this method from Main instead of calling Applcation.Start</summary>
      /// <param name="callback">The callback that constructs the App singleton object.</param>
      /// <param name="deserializeFramePageStateAsync">A callback that restores the user's session state.
      /// Called during 1st main view activation if the app was previously terminated.</param>
      public static void Start(ApplicationInitializationCallback callback, Func<Frame, IActivatedEventArgs, Task<Boolean>> deserializeFramePageStateAsync = null) {
         // Invoked via process' primary thread each time the process initializes
         s_deserializeFramePageStateAsync = deserializeFramePageStateAsync;
         Log();  // Watch Thread.CurrentThread
         m_appInitCallback = callback;
         Application.Start(AppInitialization);
      }

      public static void SetShowSplashScreenAsync(Func<IActivatedEventArgs, Window, Task> showSplashScreenAsync) {
         s_showSplashScreenAsync = showSplashScreenAsync;
      }
      private static void AppInitialization(ApplicationInitializationCallbackParams p) {
         // Invoked via main view thread 
         // But, the main view's CoreWindow & CoreDispatcher do NOT exist yet; 
         // they are created by Application.Start after this method returns         
         Log();
         m_appInitCallback(p);  // Creates a singleton App object that never gets GC'd
         // because the base class (Application) holds a reference to it
         m_appInitCallback = null;   // Allow delegate to be GC'd
      }
      /// <summary>Call this method from inside App's OnWindowCreated method to determine 
      /// what kind of window is being created.</summary>
      /// <param name="args"></param>
      /// <returns>The view type (main or hosted) for this kind of activation.</returns>
      public static ViewType OnWindowCreated(this WindowCreatedEventArgs args) {
         // Invoked once via the main view thread and once for each hosted view or auxiliary thread
         // NOTE: You can't tell what kind of activation (Share, Protocol, etc.) is occurring.
         Log();
         // If Log hasn't been called before, we can call it now: better late than never
         if (Logging) CoreApplication.GetCurrentView().Activated += (s, e) => Log(e, null);
         return ViewType;
      }

      /// <summary>This method returns the kind of view for a given activation kind</summary>
      /// <param name="args">Indicates what kind of activation is occurring.</param>
      /// <returns>The view type (main or hosted) for this kind of activation.</returns>
      public static ViewType GetViewType(this IActivatedEventArgs args) {
         switch (args.Kind) {
            case ActivationKind.AppointmentsProvider:
               String verb = ((IAppointmentsProviderActivatedEventArgs)args).Verb;
               if (verb == AppointmentsProviderLaunchActionVerbs.AddAppointment) return ViewType.Hosted;
               if (verb == AppointmentsProviderLaunchActionVerbs.ReplaceAppointment) return ViewType.Hosted;
               if (verb == AppointmentsProviderLaunchActionVerbs.RemoveAppointment) return ViewType.Hosted;
               if (verb == AppointmentsProviderLaunchActionVerbs.ShowTimeFrame) return ViewType.Main;
               break;
            case ActivationKind.Contact:
               verb = ((IContactsProviderActivatedEventArgs)args).Verb;
               if (verb == ContactLaunchActionVerbs.Call) return ViewType.Main;
               if (verb == ContactLaunchActionVerbs.Map) return ViewType.Main;
               if (verb == ContactLaunchActionVerbs.Message) return ViewType.Main;
               if (verb == ContactLaunchActionVerbs.Post) return ViewType.Main;
               if (verb == ContactLaunchActionVerbs.VideoCall) return ViewType.Main;
               break;

            case ActivationKind.Launch:
            case ActivationKind.Search:
            case ActivationKind.File:
            case ActivationKind.Protocol:
            case ActivationKind.Device:
            case ActivationKind.LockScreenCall:
               return ViewType.Main;

            case ActivationKind.ShareTarget:
            case ActivationKind.FileOpenPicker:
            case ActivationKind.FileSavePicker:
            case ActivationKind.CachedFileUpdater:
            case ActivationKind.ContactPicker:
            case ActivationKind.PrintTaskSettings:
            case ActivationKind.CameraSettings:
               return ViewType.Hosted;
            case ActivationKind.RestrictedLaunch: // I expect a compiler error at RTM and then remove this
               break;
         }
         throw new ArgumentException("Unrecognized activation kind");
      }

      /// <summary>Returns the calling thread's ViewType (None, Main, Hosted, or Auxiliary)</summary>
      public static ViewType ViewType {
         get {
            try {
               CoreApplicationView cav = CoreApplication.GetCurrentView();
               return cav.IsMain ? ViewType.Main : (cav.IsHosted ? ViewType.Hosted : ViewType.Auxiliary);
            }
            catch { return ViewType.None; }
         }
      }

      /// <summary>Whenever you override one of App's virtual activation methods 
      /// (eg: OnLaunched, OnFileActivated, OnShareTargetActivated), call this method.
      /// If called for the 1st Main view activation, displays optional splash screen, sets Window's Frame, 
      /// restores user session state (if app was previously terminated), and activates window.
      /// If called for a Hosted view activation, sets Window's Frame & activates window.
      /// </summary>
      /// <param name="args">The reason for app activation</param>
      /// <param name="memberName">The member that is calling this method (for thread logging).</param>
      /// <returns>True if previous state was restored; false if starting fresh.</returns>
      public static async Task<Boolean> ActivateViewAsync(this IActivatedEventArgs args, [CallerMemberName] String memberName = null) {
         Log(args, memberName);
         Window currentWindow = Window.Current;
         Boolean previousStateRestored = false; // Assume previous state at termination is not being restored
         if (args.GetViewType() == ViewType.Main) {
            if (currentWindow.Content == null) {
               if (s_showSplashScreenAsync != null) {
                  await s_showSplashScreenAsync(args, currentWindow);
                  s_showSplashScreenAsync = null;  // Allow delegate to be GC'd
               }

               // After the extended splash screen processing, make the content be a Frame
               currentWindow.Content = new Frame();
            }

            // The UI is set; this is the 1st main view activation or a secondary activation
            // If not 1st activation, PreviousExecutionState == ApplicationExecutionState.Running
            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated && s_deserializeFramePageStateAsync != null) {
               // Restore user session state since app relaunched after OS termination
               previousStateRestored = await s_deserializeFramePageStateAsync(CurrentFrame, args);
               s_deserializeFramePageStateAsync = null;   // Allow delegate to be GC'd
            }
         } else {
            currentWindow.Content = new Frame();
         }
         currentWindow.Activate();  // Activate the MainView window
         return previousStateRestored;
      }

      /// <summary>Returns the Frame in the calling thread's window.</summary>
      public static Frame CurrentFrame { get { return (Frame)Window.Current.Content; } }
      public static Boolean Navigate(this Application app, IActivatedEventArgs args, Object parameter = null) {
         String typeName = Application.Current.GetType().Namespace + "." + args.Kind + "Page";
         return app.Navigate(Type.GetType(typeName), parameter);
      }
      public static Boolean Navigate(this Application app, Type sourcePageType, Object parameter = null) {
         return CurrentFrame.Navigate(sourcePageType, parameter);
      }
      private const String ProximityLaunchArg = "Windows.Networking.Proximity:StreamSocket";
      public static LaunchReason GetLaunchReason(this LaunchActivatedEventArgs args) {
         if (args.Arguments == ProximityLaunchArg) return LaunchReason.Proximity;
         if (args.TileId == Windows.ApplicationModel.Core.CoreApplication.Id) {
            return (args.Arguments == String.Empty) ? LaunchReason.PrimaryTile : LaunchReason.Toast;
         }
         return LaunchReason.SecondaryTile;
      }
   #if false
      public static void DispatchOnActivated(this IActivatedEventArgs args) {
         String verb;
         switch (args.Kind) {
            // Main view activations:
            case ActivationKind.Protocol: OnProtocolActivated((ProtocolActivatedEventArgs)args); break;
            case ActivationKind.Device: OnDeviceActivated((DeviceActivatedEventArgs)args); break;
            case ActivationKind.PrintTaskSettings: OnPrintTaskSettingsActivated((PrintTaskSettingsActivatedEventArgs)args); break;
            case ActivationKind.AppointmentsProvider:
               verb = ((IAppointmentsProviderActivatedEventArgs)args).Verb;
               if (verb == AppointmentsProviderLaunchActionVerbs.AddAppointment)
                  OnAppointmentsProviderAddAppointmentActivated((AppointmentsProviderAddAppointmentActivatedEventArgs)args);
               if (verb == AppointmentsProviderLaunchActionVerbs.ReplaceAppointment)
                  OnAppointmentsProviderReplaceAppointmentActivated((AppointmentsProviderReplaceAppointmentActivatedEventArgs)args);
               if (verb == AppointmentsProviderLaunchActionVerbs.RemoveAppointment)
                  OnAppointmentsProviderRemoveAppointmentActivated((AppointmentsProviderRemoveAppointmentActivatedEventArgs)args);
               if (verb == AppointmentsProviderLaunchActionVerbs.ShowTimeFrame)
                  OnAppointmentsProviderShowTimeFrameActivated((AppointmentsProviderShowTimeFrameActivatedEventArgs)args);
               break;

            case ActivationKind.Contact:
               verb = ((IContactActivatedEventArgs)args).Verb;
               if (verb == ContactLaunchActionVerbs.Call)
                  OnContactCallActivated((ContactCallActivatedEventArgs)args);
               if (verb == ContactLaunchActionVerbs.Map)
                  OnContactMapActivated((ContactMapActivatedEventArgs)args);
               if (verb == ContactLaunchActionVerbs.Message)
                  OnContactMessageActivated((ContactMessageActivatedEventArgs)args);
               if (verb == ContactLaunchActionVerbs.Post)
                  OnContactPostActivated((ContactPostActivatedEventArgs)args);
               if (verb == ContactLaunchActionVerbs.VideoCall)
                  OnContactVideoCallActivated((ContactVideoCallActivatedEventArgs)args);
               break;
            case ActivationKind.LockScreenCall: OnLockScreenCall((LockScreenCallActivatedEventArgs)args); break;
            case ActivationKind.RestrictedLaunch: OnRestrictedLaunch((RestrictedLaunchActivatedEventArgs)args); break;

            // Hosted view activations:
            case ActivationKind.ContactPicker: OnContactPickerActivated((ContactPickerActivatedEventArgs)args); break;
            case ActivationKind.CameraSettings: OnCameraSettingsActivated((CameraSettingsActivatedEventArgs)args); break;
         }
      }
   #endif
   }
   #endregion

#region Thread logging support
/// <summary>To see the thread name in the debugger you MUST turn on Native Debugging.</summary>
/// <param name="name">The name you want the thread to have in the debugger.</param>
public static partial class AppAid {
   private static Boolean s_logging = Debugger.IsAttached;
   public static Boolean Logging { get { return s_logging; } set { s_logging = value; } }

   public static readonly ConcurrentDictionary<Int32, ThreadInfo> AllThreads = new ConcurrentDictionary<Int32, ThreadInfo>();
   [ThreadStatic]
   private static ThreadInfo s_currentThread;
   public static ThreadInfo CurrentThread { get { return s_currentThread; } }

   [DebuggerStepThrough]
   public static void Log(IActivatedEventArgs args = null, [CallerMemberName] String memberName = null) {
      if (!Logging) return;
      // Look up the thread in our collection
      Int32 id = Environment.CurrentManagedThreadId;
      ThreadInfo ti;

      // If a thread ID gets reused, remove the info about the old thread & start fresh
      if (s_currentThread == null) AllThreads.TryRemove(id, out ti);

      ti = AllThreads.GetOrAdd(id, tid => {
         s_currentThread = new ThreadInfo();
         Win32ThreadName.Set(CurrentThread.ToString());
         return CurrentThread;
      });
      ti.Upgrade(args);
      if (memberName != null) ti.Members.Insert(0, memberName);
   }

   public sealed class ThreadInfo {
      internal ThreadInfo() {
         PreviousExecutionState = "?";
         LastActivationKind = "?";
      }

      internal void Upgrade(IActivatedEventArgs args) {
         if (args == null) return;
         if (PreviousExecutionState == "?") PreviousExecutionState = args.PreviousExecutionState.ToString();
         LastActivationKind = args.Kind.ToString();
      }

      public readonly Int32 Id = Environment.CurrentManagedThreadId;
      public readonly DateTimeOffset Created = DateTimeOffset.Now;
      public String PreviousExecutionState { get; private set; }
      public String LastActivationKind { get; private set; }
      public readonly ViewType View = ViewType;
      public readonly List<String> Members = new List<String>();
      public override String ToString() {
         return String.Format("Id={0}, View={1}, LastActivation={2}, Members={3}",
            Id, View, LastActivationKind, String.Join(",", Members));
      }
   }

   [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
   private sealed class Win32ThreadName {
      public static unsafe void Set(String threadName) {
         try {
            Byte* pb = stackalloc Byte[1000];
            for (Int32 c = 0; c < threadName.Length; c++)
               pb[c] = (Byte)threadName[c];

            var info = new Win32ThreadName((IntPtr)pb);
            const UInt32 MS_VC_EXCEPTION = 0x406D1388;
            RaiseException(MS_VC_EXCEPTION, 0, 4, info);
         }
         catch (Exception) { }
      }

      [DllImport("Kernel32", ExactSpelling = false, SetLastError = true)]
      private static extern void RaiseException(UInt32 dwExceptionCode, UInt32 dwExceptionFlags, UInt32 nNumberOfArguments, Win32ThreadName pArguments);

      private Win32ThreadName(IntPtr threadName) { szName = threadName; }

      private UInt32 dwType = 0x1000;  // Must be 0x1000
      private IntPtr szName;           // Pointer to name (in user addr space).
      private Int32 dwThreadID = -1;   // Thread ID (-1=caller thread).
      private UInt32 dwFlags = 0;      // Reserved for future use, must be zero.
   }
}
#endregion

#region Simple extension methods
public static partial class AppAid {
   [MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static void Forget(this Task task) { }
   [MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static void Forget(this IAsyncInfo asyncInfo) { }

   [MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static void RunOnGui(this DependencyObject dependecyObject, DispatchedHandler agileCallback) {
      if (dependecyObject.Dispatcher.HasThreadAccess) agileCallback();
      else dependecyObject.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, agileCallback).Forget();
   }

   [MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static Boolean DispatchToGui(this DependencyObject dependecyObject, DispatchedHandler agileCallback) {
      if (dependecyObject.Dispatcher.HasThreadAccess) return false;
      dependecyObject.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, agileCallback).Forget();
      return true;
   }

   [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static void Wait(this IAsyncAction asyncOp) { asyncOp.AsTask().GetAwaiter().GetResult(); }

   [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
   public static TResult Wait<TResult>(this IAsyncOperation<TResult> asyncOp) {
      return asyncOp.AsTask().GetAwaiter().GetResult();
   }

   public enum BeepType : uint {
      Simple = 0xffffffff,
      OK = 0x00,
      Error = 0x10,
      Question = 0x20,
      Warning = 0x30,
      Information = 0x40,
   }
#if DEBUG
   [DllImport("user32")]
   private extern static Boolean MessageBeep(BeepType type);
#endif
   [Conditional("DEBUG")]
   public static void Beep(Int32 count = 1, BeepType beepType = BeepType.Simple) {
#if DEBUG
      for (Int32 c = 0; c < count; c++) MessageBeep(beepType);
#endif
   }
}
}
#endregion
