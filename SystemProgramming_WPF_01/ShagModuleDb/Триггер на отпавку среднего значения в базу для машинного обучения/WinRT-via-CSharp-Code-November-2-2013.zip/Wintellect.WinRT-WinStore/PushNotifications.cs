﻿/******************************************************************************
Module:  PushNotifications.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.Web.Http;
using Windows.Web.Http.Headers;

#if WindowsStore
using Windows.Data.Xml.Dom;
using Windows.Networking.PushNotifications;
#endif

// Windows Push Notification Service: http://msdn.microsoft.com/en-us/library/windows/apps/hh465435(v=vs.85).aspx
// NOTE: You must register your application with Windows Live: http://manage.dev.live.com/Build
// You will get back a package name, package security identifier (SID), & client secret
namespace Wintellect.WinRT.PushNotifications {
   public static class WnsExtensions {
#if WindowsStore
      public static Boolean HasExpired(this PushNotificationChannel channel, Int32 daysToSpare = 0) {
         return (channel.ExpirationTime + TimeSpan.FromDays(daysToSpare)) >= DateTimeOffset.Now;  // JMR: Check UTC
      }
#endif

      public static WnsResponseHeaders GetWnsResponseHeaders(this HttpResponseMessage msg) {
         return new WnsResponseHeaders(msg);
      }

      private static IDictionary<HttpStatusCode, String> s_errorCode = null;
      public static String ToWnsResponseMessage(this HttpStatusCode code) {
         if (s_errorCode == null) {
            var codes = new Dictionary<HttpStatusCode, String> {
               { HttpStatusCode.Ok, "The notification was accepted by WNS." },
               { HttpStatusCode.BadRequest, "One or more headers was specified incorrectly or is in conflict with another header." },
               { HttpStatusCode.Unauthorized, "The cloud service did not present a valid authentication ticket. The OAuth ticket may be invalid." },
               { HttpStatusCode.Forbidden, "The cloud service is not authorized to send a notification to this URI even though they are authenticated." },
               { HttpStatusCode.NotFound, "The channel URI is not valid or is not recognized by WNS. Do not send further notifications to this channel." },
               { HttpStatusCode.MethodNotAllowed, "Invalid method (GET, DELETE, CREATE); only POST is allowed." },
               { HttpStatusCode.NotAcceptable, "The cloud service has exceeded its throttle limit. Reduce the rate at which you are sending notifications." },
               { HttpStatusCode.Gone, "The channel has expired. Do not send further notifications to this channel and request a new channel URI." },
               { HttpStatusCode.RequestEntityTooLarge, "The channel has expired. Do not send further notifications to this channel and request a new channel URI.." },
               { HttpStatusCode.InternalServerError, "An internal failure has caused notification delivery to fail.." },
               { HttpStatusCode.ServiceUnavailable, "The server is currently unavailable." }
            };
            Interlocked.CompareExchange(ref s_errorCode, codes, null);
         }
         return s_errorCode[code];
      }
   }

   internal sealed class NameAttribute : Attribute {
      private readonly String m_name;
      public String Name { get { return m_name; } }
      public NameAttribute(String name) { m_name = name; }

      public static NameAttribute Lookup(Object o) {
         return o.GetType().GetTypeInfo().GetDeclaredField(o.ToString()).GetCustomAttribute<NameAttribute>();
         //return (NameAttribute)Attribute.GetCustomAttribute(o.GetType().GetField(o.ToString()), typeof(NameAttribute));
      }

      public static TEnum Lookup<TEnum>(String name) where TEnum : struct {
         foreach (var v in (TEnum[])Enum.GetValues(typeof(TEnum))) {
            if (Lookup(v).Name == name) return v;
         }
         throw new ArgumentException();
      }
   }

   #region Wns Request Headers
   // WNS Request & Response headers: http://msdn.microsoft.com/en-us/library/windows/apps/hh465435(v=vs.85).aspx
   public sealed class WnsRequestHeaders {
      public WnsType WnsType;
      public String Tag;
      public WnsCachePolicy? CachePolicy;
      public Boolean? RequestForStatus;
      public Int32? TtlSeconds;
   }

   public enum WnsType {
      [Name("wns/badge")]
      Badge,
      [Name("wns/tile")]
      Tile,
      [Name("wns/toast")]
      Toast,
      [Name("wns/raw")]
      Raw
   }

   public enum WnsCachePolicy {
      /// <summary>
      /// Default. Tile and badge notifications will be cached if the user is offline.
      /// </summary>
      [Name("cache")]
      Cache,
      /// <summary>
      /// 	The notification will not be cached if the user is offline
      /// </summary>
      [Name("no-cache")]
      NoCache
   }
   #endregion

   #region Wns Response Headers
   public sealed class WnsResponseHeaders {
      /// <summary>
      /// Debugging information that should be logged to help troubleshoot issues when reporting a problem.
      /// </summary>
      public readonly String DebugTrace;

      /// <summary>
      /// The device status, returned only if requested in the notification request through the X-WNS-RequestForStatus header.
      /// </summary>
      public readonly WnsDeviceConnectionStatus DeviceConnectionStatus;

      /// <summary>
      /// A human-readable error string that should be logged to help with debugging.
      /// </summary>
      public readonly String ErrorDescription;

      /// <summary>
      /// A unique identifier for the notification, used for debugging purposes.
      /// </summary>
      public readonly String MsgId;

      /// <summary>
      /// Indicates whether WNS has successfully received and processed the notification.
      /// </summary>
      public readonly WnsNotificationStatus NotificationStatus;
      public readonly String ResponseCodeMsg;
      internal WnsResponseHeaders(HttpResponseMessage msg) {
         ResponseCodeMsg = msg.StatusCode.ToWnsResponseMessage();
         var h = msg.Headers;
         String value;
         if (h.TryGetValue("X-WNS-Debug-Trace", out value)) DebugTrace = value;
         if (h.TryGetValue("X-WNS-Error-Description", out value)) ErrorDescription = value;
         if (h.TryGetValue("X-WNS-Msg-ID", out value)) MsgId = value;
         if (h.TryGetValue("X-WNS-DeviceConnectionStatus", out value))
            DeviceConnectionStatus = NameAttribute.Lookup<WnsDeviceConnectionStatus>(value);
         if (h.TryGetValue("X-WNS-NotificationStatus", out value))
            NotificationStatus = NameAttribute.Lookup<WnsNotificationStatus>(value);
      }
   }

   public enum WnsDeviceConnectionStatus {
      [Name("")]
      None,
      [Name("connected")]
      Connected,
      [Name("disconnected")]
      Disconnected,
      [Name("tempconnected")]
      TempConnected
   }

   public enum WnsNotificationStatus {
      [Name("")]
      None,
      [Name("received")]
      Received,
      [Name("dropped")]
      Dropped,
      [Name("channelthrottled")]
      ChannelThrottled
   }
   #endregion

   public sealed class AppServerWns {
      private readonly String m_packageSid, m_secret;
      public readonly WnsRequestHeaders RequestHeaders = new WnsRequestHeaders();
      private OAuthToken m_token;

      public AppServerWns(String packageSid, String secret) {
         m_packageSid = packageSid.Trim(); m_secret = secret.Trim();
      }

[DataContract]
private sealed class OAuthToken {
   [DataMember(Name = "access_token")]
   public string AccessToken { get; set; }
   [DataMember(Name = "token_type")]
   public string TokenType { get; set; }
}

      // Requests an OAuth2 token from Windows Live that the service can use to communicate with WNS:
      private async Task GetAuthenticationTokenAsync() {
         // POST http://login.live.com/accesstoken.srf HTTP/1.1
         // Content-Type: application/x-www-form-urlencoded
         // Host: login.live.com
         // Content-Length: 221
         // grant_type=client_credentials&client_id=ns-app://S-1-15-2-xxxxx&client_secrent=XXX&scope=notify.windows.com

         // Make HTTPS POST to Windows Live authenticating our package/secret
         var content = new Windows.Web.Http.HttpFormUrlEncodedContent(new Dictionary<String, String> {
            { "grant_type", "client_credentials"},
            { "client_id", m_packageSid },
            { "client_secret", m_secret},
            { "scope", "notify.windows.com"}
         });
         using (var response = await new HttpClient().PostAsync(new Uri("https://login.live.com/accesstoken.srf"), content).AsTask().ConfigureAwait(false)) {
            m_token = DeserializeJson<OAuthToken>((await response.Content.ReadAsInputStreamAsync().AsTask().ConfigureAwait(false)).AsStreamForRead());
         }
      }

      private T DeserializeJson<T>(Stream stream) {
         return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(stream);
      }

#if WindowsStore
      public Task<HttpResponseMessage> PushAsync(XmlDocument xmlDocument, String channelUri) {
         return PushAsync(xmlDocument.GetXml(), channelUri);
      }
#endif

      public Task<HttpResponseMessage> PushAsync(String payload, String channelUri) {
         return PushAsync(Encoding.UTF8.GetBytes(payload), channelUri);
      }

      public async Task<HttpResponseMessage> PushAsync(Byte[] payload, String channelUri) {
         var requestMsg = new HttpRequestMessage(HttpMethod.Post, new Uri(channelUri));
         requestMsg.Content = new HttpBufferContent(payload.AsBuffer());
         SetWnsRequestHeaders(requestMsg, RequestHeaders);

         HttpResponseMessage responseMsg = null;
         for (Int32 retry = 0; retry < 3; retry++) {
            if (m_token == null) await GetAuthenticationTokenAsync().ConfigureAwait(false);
            requestMsg.Headers.Authorization = new HttpCredentialsHeaderValue("Bearer", m_token.AccessToken);
            responseMsg = await new HttpClient().SendRequestAsync(requestMsg).AsTask().ConfigureAwait(false);
            if (responseMsg.StatusCode == HttpStatusCode.Ok) break;   // Successful, don't retry
            if (responseMsg.StatusCode == HttpStatusCode.Unauthorized)
               m_token = null; // Maybe the token expired, get new token & retry               
         }
         return responseMsg;
      }

      public static HttpRequestMessage SetWnsRequestHeaders(HttpRequestMessage msg, WnsRequestHeaders headers) {
         msg.Content.Headers.ContentType = new HttpMediaTypeHeaderValue((headers.WnsType == WnsType.Raw) ? "application/octet-stream" : "text/xml");
         msg.Headers.Add("X-WNS-Type", NameAttribute.Lookup(headers.WnsType).Name);
         if (headers.CachePolicy.HasValue) msg.Headers.Add("X-WNS-Cache-Policy", NameAttribute.Lookup(headers.CachePolicy).Name);

         // Assign a tag label for a notification; used by device to detect dups. Note 16 chars in length
         if (headers.Tag != null)
            msg.Headers.Add("X-WNS-Tag", headers.Tag);

         // Request for Device Status and Notification Status to be returned in the response
         if (headers.RequestForStatus.HasValue)
            msg.Headers.Add("X-WNS-RequestForStatus", headers.RequestForStatus.Value.ToString().ToLowerInvariant());

         if (headers.TtlSeconds.HasValue)
            msg.Headers.Add("X-WNS-TTL", headers.TtlSeconds.Value.ToString());
         return msg;
      }
   }
}
