﻿/******************************************************************************
Module:  Xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Windows.Foundation.Collections;
using Windows.Foundation.Metadata;

namespace Wintellect.WinRT.Xaml {
   [WebHostHidden]
   public abstract class BindableBase : INotifyPropertyChanged {
      /// <summary>
      /// Multicast event for property change notifications.
      /// </summary>
      public event PropertyChangedEventHandler PropertyChanged;

      /// <summary>
      /// Checks if a property already matches a desired value.  Sets the property and
      /// notifies listeners only when necessary.
      /// </summary>
      /// <typeparam name="T">Type of the property.</typeparam>
      /// <param name="storage">Reference to a property with both getter and setter.</param>
      /// <param name="value">Desired value for the property.</param>
      /// <param name="propertyName">Name of the property used to notify listeners.  This
      /// value is optional and can be provided automatically when invoked from compilers that
      /// support CallerMemberName.</param>
      /// <returns>True if the value was changed, false if the existing value matched the
      /// desired value.</returns>
      protected Boolean SetProperty<T>(ref T storage, T value, [CallerMemberName] String propertyName = null) {
         if (Object.Equals(storage, value)) return false;
         storage = value;
         OnPropertyChanged(propertyName);
         return true;
      }

      /// <summary>
      /// Notifies listeners that a property value has changed.
      /// </summary>
      /// <param name="propertyName">Name of the property used to notify listeners.  This
      /// value is optional and can be provided automatically when invoked from compilers
      /// that support <see cref="CallerMemberNameAttribute"/>.</param>
      protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null) {
         var eventHandler = PropertyChanged;
         if (eventHandler != null) {
            eventHandler(this, new PropertyChangedEventArgs(propertyName));
         }
      }
   }

   [WebHostHidden]
   public abstract class ObservableList<T> : IObservableVector<T> {
      private readonly List<T> m_list = new List<T>();

      private sealed class VectorChangedEventArgs : IVectorChangedEventArgs {
         public VectorChangedEventArgs(UInt32 index, CollectionChange change) {
            Index = index;
            CollectionChange = change;
         }
         public CollectionChange CollectionChange { get; private set; }
         public UInt32 Index { get; private set; }
      }

      protected virtual void OnVectorChanged(Int32 index, CollectionChange change) {
         var t = VectorChanged;
         if (t == null) return;
         t(this, new VectorChangedEventArgs((UInt32)index, change));
      }

      #region IList
      public T this[int index] {
         get { return m_list[index]; }
         set { m_list[index] = value; OnVectorChanged(index, CollectionChange.ItemChanged); }
      }
      public int IndexOf(T item) { return m_list.IndexOf(item); }
      public void Insert(int index, T item) { m_list.Insert(index, item); OnVectorChanged(index, CollectionChange.ItemInserted); }
      public void RemoveAt(int index) { m_list.RemoveAt(index); OnVectorChanged(index, CollectionChange.ItemRemoved); }
      #endregion

      #region ICollection
      public Int32 Count { get { return m_list.Count; } }
      public Boolean IsReadOnly { get { return false; } }
      public void Add(T item) { m_list.Insert(Count, item); }
      public void Clear() { m_list.Clear(); OnVectorChanged(0, CollectionChange.Reset); }
      public Boolean Contains(T item) { return m_list.Contains(item); }
      public void CopyTo(T[] array, int arrayIndex) { m_list.CopyTo(array, arrayIndex); }
      public Boolean Remove(T item) {
         Int32 index = m_list.IndexOf(item);
         if (index == -1) return false;
         m_list.RemoveAt(index);
         return true;
      }
      #endregion

      #region IEnumerator
      IEnumerator IEnumerable.GetEnumerator() { return m_list.GetEnumerator(); }
      public IEnumerator<T> GetEnumerator() { return m_list.GetEnumerator(); }
      #endregion

      public event VectorChangedEventHandler<T> VectorChanged;
   }

   [WebHostHidden]
   public abstract class ObservableList : IObservableVector<Object> {
      private readonly List<Object> m_list = new List<Object>();

      private sealed class VectorChangedEventArgs : IVectorChangedEventArgs {
         public VectorChangedEventArgs(UInt32 index, CollectionChange change) {
            Index = index;
            CollectionChange = change;
         }
         public CollectionChange CollectionChange { get; private set; }
         public UInt32 Index { get; private set; }
      }

      protected virtual void OnVectorChanged(Int32 index, CollectionChange change) {
         var t = VectorChanged;
         if (t == null) return;
         t(this, new VectorChangedEventArgs((UInt32)index, change));
      }

      #region IList
      public Object this[int index] {
         get { return m_list[index]; }
         set { m_list[index] = value; OnVectorChanged(index, CollectionChange.ItemChanged); }
      }
      public int IndexOf(Object item) { return m_list.IndexOf(item); }
      public void Insert(int index, Object item) { m_list.Insert(index, item); OnVectorChanged(index, CollectionChange.ItemInserted); }
      public void RemoveAt(int index) { m_list.RemoveAt(index); OnVectorChanged(index, CollectionChange.ItemRemoved); }
      #endregion

      #region ICollection
      public Int32 Count { get { return m_list.Count; } }
      public Boolean IsReadOnly { get { return false; } }
      public void Add(Object item) { Insert(Count, item); }
      public void Clear() { m_list.Clear(); OnVectorChanged(0, CollectionChange.Reset); }
      public Boolean Contains(Object item) { return m_list.Contains(item); }
      public void CopyTo(Object[] array, int arrayIndex) { m_list.CopyTo(array, arrayIndex); }
      public Boolean Remove(Object item) {
         Int32 index = IndexOf(item);
         if (index == -1) return false;
         RemoveAt(index);
         return true;
      }
      #endregion

      #region IEnumerator
      IEnumerator IEnumerable.GetEnumerator() { return m_list.GetEnumerator(); }
      public IEnumerator<Object> GetEnumerator() { return m_list.GetEnumerator(); }
      #endregion

      public event VectorChangedEventHandler<Object> VectorChanged;
   }
}
