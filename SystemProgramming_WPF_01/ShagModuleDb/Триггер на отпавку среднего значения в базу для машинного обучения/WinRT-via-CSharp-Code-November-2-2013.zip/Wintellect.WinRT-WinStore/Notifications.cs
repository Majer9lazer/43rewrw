﻿/******************************************************************************
Module:  Notifications.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

// Tiles:  http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx
// Badges: http://msdn.microsoft.com/en-us/library/windows/apps/hh868205.aspx
// Toasts: http://msdn.microsoft.com/en-us/library/windows/apps/hh868267.aspx
// Audio:  http://msdn.microsoft.com/en-us/library/windows/apps/hh868265.aspx

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel.Activation;
using Windows.Data.Xml.Dom;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.System.Threading;
using Windows.UI.Notifications;
using Windows.UI.Xaml.Media.Imaging;
using Windows.Web.Http;
using Wintellect;
using Wintellect.WinRT.Packaging;

namespace Wintellect.WinRT.Notifications {
   #region Types common to Tiles, Badges, & Toasts
   public static class Extensions {
      public const Int32 NotificationContentVersion = 1;

      internal static String HttpEncode(this String value) {
         return value.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;").Replace("'", "&apos;");
      }

      private static readonly String[] s_validUriPrefixes = new[] { "http://", "https://", "ms-appx:///", "ms-appdata:///local/" };
      private static readonly String[] s_validUriSuffixes = new[] { ".png", ".jpg", ".jpeg", ".gif" };
      internal static String ValidateUri(this String uri, Boolean validatePrefix, Boolean validateSuffix) {
         if (validatePrefix)
            if (!s_validUriPrefixes.Any(p => uri.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
               throw new ArgumentException("The URI must start with " + string.Join(", ", s_validUriPrefixes));

         if (validateSuffix)
            if (!s_validUriSuffixes.Any(s => uri.EndsWith(s, StringComparison.OrdinalIgnoreCase)))
               throw new ArgumentException("The URI must end with " + string.Join(", ", s_validUriSuffixes));
         return uri;
      }
   }

#if WindowsStore
   internal sealed class TemplateElementCounts {
      private static readonly Dictionary<TileTemplateType, TemplateElementCounts> s_tileImageAndTextCounts =
         Helpers.GetEnumValues<TileTemplateType>().ToDictionary(t => t,
            t => Calc(TileUpdateManager.GetTemplateContent(t)));

      private static readonly Dictionary<ToastTemplateType, TemplateElementCounts> s_toastImageAndTextCounts =
         Helpers.GetEnumValues<ToastTemplateType>().ToDictionary(t => t,
            t => Calc(ToastNotificationManager.GetTemplateContent(t)));

      private static TemplateElementCounts Calc(XmlDocument xml) {
         return new TemplateElementCounts(xml.GetElementsByTagName("image").Count, xml.GetElementsByTagName("text").Count);
      }

      public static TemplateElementCounts Lookup(TileTemplateType type) { return s_tileImageAndTextCounts[type]; }
      public static TemplateElementCounts Lookup(ToastTemplateType type) { return s_toastImageAndTextCounts[type]; }
      public TemplateElementCounts(Int32 numImages, Int32 numText) {
         NumImages = numImages; NumText = numText;
      }
      public readonly Int32 NumImages, NumText;
   }
#endif

   public enum Branding { Logo = 0, None, Name } // Logo is the default and must be 0

   public abstract class TemplateBase {
      public static Boolean ValidateTemplates { get; set; }

      protected static void ValidateImages(String visualBaseUri, IEnumerable<BindingImage> images) {
         if (!ValidateTemplates) return;
         // Validation is done in parallel by thread pool threads.
         // Since this method can be asynchronous, deadlock occurs if we block the GUI thread.
         var tasks = new List<Task>();
         foreach (var image in images) {
            tasks.Add(Task.Run(() => ValidateImageAsync(visualBaseUri, image)));
         }
         Task.WaitAll(tasks.ToArray());
      }

      private const Int32 c_maxImageBytes = 200 * 1024, c_maxImageWidth = 1024, c_maxImageHeight = 1024;
      private static async Task ValidateImageAsync(String visualBaseUri, BindingImage image) {
         String uri = image.Src;
         if (!String.IsNullOrWhiteSpace(visualBaseUri)) uri = visualBaseUri + uri;
         else if (!String.IsNullOrWhiteSpace(visualBaseUri)) uri = visualBaseUri + uri;

         if (uri.StartsWith("ms-appx:///") || uri.StartsWith("ms-appdata:///local/")) {
            uri.ValidateUri(false, true); // File must have valid file extension
#if WindowsStore
            StorageFile imageFile = null;
            try {
               imageFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri(uri));
            }
            catch {
               throw new NotSupportedException("Image file not found: " + uri);
            }
            var props = await imageFile.GetBasicPropertiesAsync();
            if (props.Size > c_maxImageBytes)
               throw new NotSupportedException("Image file > 200KB: " + imageFile.Path);
            var imageProps = await imageFile.Properties.GetImagePropertiesAsync();
            if (imageProps.Width > c_maxImageWidth || imageProps.Height > c_maxImageHeight)
               throw new NotSupportedException("Image width or height > 1024: " + imageFile.Path);
#endif
         } else {
            using (var hc = new HttpClient()) {
               try {
                  //hc.MaxResponseContentBufferSize = c_maxImageBytes;
                  using (HttpResponseMessage response = await hc.GetAsync(new Uri(uri))) {
                     if (response.Content.Headers.ContentLength > c_maxImageBytes)
                        throw new NotSupportedException("Image file > 200KB: " + uri);
                     await ValidateImageDimensionsAsync(uri, response.Content);
                  }
               }
               catch {
                  throw new NotSupportedException("Image file not found: " + uri);
               }
            }
         }
      }

      private static async Task ValidateImageDimensionsAsync(String uri, IHttpContent content) {
         using (var stream = new InMemoryRandomAccessStream()) {
            await stream.WriteAsync(await content.ReadAsBufferAsync());
            var bitmap = await BitmapDecoder.CreateAsync(stream);
            if (bitmap.PixelWidth > c_maxImageWidth || bitmap.PixelHeight > c_maxImageHeight)
               throw new NotSupportedException("Image width or height > 1024: " + uri);
         }
      }

      public abstract XElement ToXElement();
      public override String ToString() { return ToXElement().ToString(); }

      public XmlDocument ToXmlDocument() {
         var xmlDocument = new XmlDocument();
         xmlDocument.LoadXml(ToString());
         return xmlDocument;
      }
      public static implicit operator XmlDocument(TemplateBase template) { return template.ToXmlDocument(); }
   }

   public abstract class VisualTemplate : TemplateBase {
      protected VisualTemplate() { }
      public Int32? Version { get; set; }
      public String Lang { get; set; }
      public Branding Branding { get; set; }
      public Boolean AddImageQuery { get; set; }
      public String ContentId { get; set; }

      private string m_baseUri;
      public String BaseUri {
         get { return m_baseUri; }
         set { m_baseUri = value.ValidateUri(true, false); }
      }
      protected abstract IEnumerable<XElement> GetBindingElements();

      public override XElement ToXElement() {
         var content = new List<Object>();
         content.AddRange(GetBindingElements());
         if (Version.HasValue) content.Add(new XAttribute("version", Version));
         if (!String.IsNullOrWhiteSpace(Lang)) content.Add(new XAttribute("lang", Lang.HttpEncode()));
         if (!String.IsNullOrWhiteSpace(ContentId)) content.Add(new XAttribute("contentId", ContentId.HttpEncode()));
         if (!String.IsNullOrWhiteSpace(BaseUri)) content.Add(new XAttribute("baseUri", BaseUri.HttpEncode()));
         if (AddImageQuery) content.Add(new XAttribute("addImageQuery", AddImageQuery.ToString().ToLowerInvariant()));
         if (Branding != Branding.Logo) content.Add(new XAttribute("branding", Branding.ToString().ToLowerInvariant()));
         return new XElement("visual", content);
      }
   }

   public abstract class BindingTemplate<TEnum> : TemplateBase where TEnum : struct {
      public BindingTemplate(TEnum templateType) {
         TemplateType = templateType;
         Text = new List<BindingText>();
         Images = new List<BindingImage>();
      }

      public TEnum TemplateType { get; set; }
      public IList<BindingText> Text { get; set; }
      public IList<BindingImage> Images { get; set; }

      // Lang, BaseUri, Branding, ContentId are the same in Visual & Binding
      public String Lang { get; set; }
      public String ContentId { get; set; }
      private String m_baseUri;
      public String BaseUri {
         get { return m_baseUri; }
         set { m_baseUri = value.ValidateUri(true, false); }
      }
      public Branding Branding { get; set; }
      public Boolean AddImageQuery { get; set; }

      public override XElement ToXElement() {
         // If the TileTemplate string contains "Square" not followed by a 1 or 3, change it to "Square150x150"
         String templateType = TemplateType.ToString();
         Int32 indexOfSquare = templateType.IndexOf("Square");
         if (indexOfSquare != -1 && templateType[indexOfSquare + 6] != '1' && templateType[indexOfSquare + 6] != '3')
            templateType = templateType.Replace("Square", "Square150x150");

         // If the TileTemplate string contains "Wide" not followed by a 3, change it to "Wide310x150"
         Int32 indexOfWide = templateType.IndexOf("Wide");
         if (indexOfWide != -1 && templateType[indexOfWide + 4] != '3')
            templateType = templateType.Replace("Wide", "Wide310x150");

         var content = new List<Object>() { new XAttribute("template", templateType) };
         if (!String.IsNullOrWhiteSpace(Lang)) content.Add(new XAttribute("lang", Lang.HttpEncode()));
         if (!String.IsNullOrWhiteSpace(ContentId)) content.Add(new XAttribute("contentId", ContentId.HttpEncode()));
         if (!String.IsNullOrWhiteSpace(BaseUri)) content.Add(new XAttribute("baseUri", BaseUri.HttpEncode()));
         if (AddImageQuery) content.Add(new XAttribute("addImageQuery", AddImageQuery.ToString().ToLowerInvariant()));
         if (Branding != Branding.Logo) content.Add(new XAttribute("branding", Branding.ToString().ToLowerInvariant()));

         Int32 id = 1;  // Assign ascending IDs to Binding elements
         foreach (BindingImage image in Images) {
            image.Id = id++; content.Add(image.ToXElement());
         }
         id = 1;
         foreach (BindingText text in Text) {
            text.Id = id++; content.Add(text.ToXElement());
         }
         return new XElement("binding", content);
      }
   }

   public abstract class BindingElement : TemplateBase {
      public BindingElement() { }
      public Int32 Id { get; set; }
   }

   public sealed class BindingImage : BindingElement {
      public static implicit operator BindingImage(String src) { return new BindingImage(src); }
      /// <summary></summary>
      /// <param name="id">Must be &gt 0</param>
      /// <param name="src">Identifies a JPG or PNG file that is &lt=150KB. 
      /// Protocol must start with http://, https://, ms-appx:///, ms-appdata:///local/, or file:/// </param>
      /// <param name="alt"></param>
      public BindingImage(String src, String alt = null) : base() { Src = src; Alt = alt; }
      /// <summary>
      /// http://, https://, ms-appx:///, ms-appdata:///local/, or file:/// 
      /// </summary>
      public String Src { get; set; }
      public String Alt { get; set; }
      public Boolean AddImageQuery { get; set; }
      public override XElement ToXElement() {
         var content = new List<Object> { new XAttribute("id", Id), new XAttribute("src", Src.HttpEncode()) };
         if (!String.IsNullOrWhiteSpace(Alt)) content.Add(new XAttribute("alt", Alt.HttpEncode()));
         if (AddImageQuery) content.Add(new XAttribute("addImageQuery", AddImageQuery.ToString().ToLowerInvariant()));
         return new XElement("image", content);
      }
   }

   public sealed class BindingText : BindingElement {
      public static implicit operator BindingText(String text) { return new BindingText(text); }

      public BindingText(String text) : base() { Text = text; }
      public String Text { get; set; }
      public String Lang { get; set; }
      public override XElement ToXElement() {
         var content = new List<Object> { new XAttribute("id", Id), Text.HttpEncode() };
         if (!String.IsNullOrWhiteSpace(Lang)) content.Add(new XAttribute("lang", Lang.HttpEncode()));
         return new XElement("text", content);
      }
   }
   #endregion

   #region Tile specific types
   public sealed class TileTemplate : TemplateBase {
#if WindowsStore
      private static ManifestTies? s_manifestTiles = null;
      enum ManifestTies { Square150x150 = 0, Wide310x150 = 1, Square310x310 = 2 }

      private static async Task<ManifestTies> GetManifestTileseAsync() {
         if (s_manifestTiles == null) {
            s_manifestTiles = ManifestTies.Square150x150;
            var pm = await PackageManifest.LoadAsync();
            if (pm.Applications.First().VisualElements.DefaultTile.Wide310x150Logo != null)
               s_manifestTiles = ManifestTies.Wide310x150;
            if (pm.Applications.First().VisualElements.DefaultTile.Square310x310Logo != null)
               s_manifestTiles = ManifestTies.Square310x310;
         }
         return s_manifestTiles.Value;
      }
#endif

      public TileTemplate() { Visual = new TileVisual { Version = 2 }; }
      public TileVisual Visual { get; set; }

      public Int32? VisualVersion {
         get { return Visual.Version; }
         set { Visual.Version = value; }
      }
      public String VisualLang {
         get { return Visual.Lang; }
         set { Visual.Lang = value; }
      }
      public Branding VisualBranding {
         get { return Visual.Branding; }
         set { Visual.Branding = value; }
      }
      public String VisualBaseUri {
         get { return Visual.BaseUri; }
         set { Visual.BaseUri = value; }
      }

      public TileBinding Square150x150Tile {
         get { return Visual.Square150x150Tile; }
         set { Visual.Square150x150Tile = value; }
      }

      public TileBinding Wide310x150Tile {
         get { return Visual.Wide310x150Tile; }
         set { Visual.Wide310x150Tile = value; }
      }

      public TileBinding Square310x310Tile {
         get { return Visual.Square310x310Tile; }
         set { Visual.Square310x310Tile = value; }
      }

      public override XElement ToXElement() {
         if (TemplateBase.ValidateTemplates) {
            if (Square150x150Tile == null)
               throw new NotSupportedException("Square 150x150 tile template must always be specified.");
            Task.Run(() => {
#if WindowsStore
               var manifestTiles = GetManifestTileseAsync().GetAwaiter().GetResult();
               if ((Wide310x150Tile == null) && (manifestTiles >= ManifestTies.Wide310x150))
                  throw new NotSupportedException("Wide 310x150 tile template must be specified since manifest includes this tile size.");
               if ((Square310x310Tile == null) && (manifestTiles >= ManifestTies.Square310x310))
                  throw new NotSupportedException("Square 310x310 tile template must be specified since manifest includes this tile size.");
#endif
               // Get collection of image for all tile bindings
               var images = Square150x150Tile.Images.AsEnumerable();
               if (Wide310x150Tile != null) images = images.Concat(Wide310x150Tile.Images);
               if (Square310x310Tile != null) images = images.Concat(Square310x310Tile.Images);
               ValidateImages(Visual.BaseUri, images);
            }).Wait();
         }
         var element = new XElement("tile", Visual.ToXElement());
         return element;
      }
   }

   public sealed class TileVisual : VisualTemplate {
      public TileVisual() { }
      public TileBinding Square150x150Tile { get; set; }
      public TileBinding Wide310x150Tile { get; set; }
      public TileBinding Square310x310Tile { get; set; }
      protected override IEnumerable<XElement> GetBindingElements() {
         yield return Square150x150Tile.ToXElement();
         if (this.Wide310x150Tile != null) yield return Wide310x150Tile.ToXElement();
         if (this.Square310x310Tile != null) yield return Square310x310Tile.ToXElement();
      }
   }

   public sealed class TileBinding : BindingTemplate<TileTemplateType> {
      public TileBinding(TileTemplateType templateType) : base(templateType) { }
   }
   #endregion

   #region Badges specific types
   public enum BadgeGlyph {
      None, Activity, Alert, Available, Away, Busy, NewMessage, Paused, Playing, Unavailable, Error, Attention
   }

   public sealed class BadgeTemplate : TemplateBase {
      private BadgeGlyph? m_glyph;
      private Int32? m_value;
      public BadgeTemplate(BadgeGlyph glyph) { Glyph = glyph; }
      public BadgeTemplate(Int32 value) { Value = value; }
      public BadgeGlyph? Glyph { get { return m_glyph; } set { m_value = null; m_glyph = value; } }
      public Int32? Value { get { return m_value; } set { m_glyph = null; m_value = value; } }
      public Int32? Version { get; set; }
      public override XElement ToXElement() {
         var content = new List<Object> { new XAttribute("value", (m_glyph.HasValue) 
            ? Char.ToLowerInvariant(m_glyph.ToString()[0]) + m_glyph.ToString().Substring(1) 
            : m_value.ToString()) };
         if (Version.HasValue) content.Add(new XAttribute("version", Version));
         var element = new XElement("badge", content);
         return element;
      }
   }
   #endregion

   #region Toast specific types
   public enum ToastDuration { Short, Long }
   public enum SoundEvent {
      Default, IM, Mail, Reminder, SMS,
      LoopingAlarm, LoopingAlarm2, LoopingAlarm3, LoopingAlarm4, LoopingAlarm5, LoopingAlarm6, LoopingAlarm7, LoopingAlarm8, LoopingAlarm9, LoopingAlarm10,
      LoopingCall, LoopingCall2, LoopingCall3, LoopingCall4, LoopingCall5, LoopingCall6, LoopingCall7, LoopingCall8, LoopingCall9, LoopingCall10
   }

   public enum ToastCommandScenario {
      /// <summary>Alarm</summary>
      alarm,
      /// <summary>Incoming Call</summary>
      incomingCall
   }


   public abstract class ToastCommand {
      private readonly ToastCommandScenario m_scenario;
      protected ToastCommand(ToastCommandScenario scenario) { m_scenario = scenario; }

      public XElement ToXElement() {
         List<XElement> commands = new List<XElement>();
         // <command id? = "snooze" | "dismiss" | "video" | "voice" | "decline" arguments? = string />
         // http://msdn.microsoft.com/en-us/library/windows/apps/dn268317.aspx

         return new XElement("commands", new XAttribute("scenario", m_scenario.ToString()), 
            AddCommands(new List<XElement>()));
      }
      protected abstract List<XElement> AddCommands(List<XElement> commands);
      protected void AddCommand(List<XElement> commands, String id, String arguments) {
         if (arguments == null) return;
         List<XAttribute> contents = new List<XAttribute>();
         contents.Add(new XAttribute("id", id));
         if (arguments != String.Empty) contents.Add(new XAttribute("arguments", arguments));
         commands.Add(new XElement("command", contents));
      }
   }

   /// <summary>Requires the "windows.alarm" extension be manually added to the app's extensions in the 
   /// package manifest and that the app be added to the lock screen as an alarm app (See AlarmApplicationManager.RequestAccessAsync).</summary>
   public sealed class ToastAlarmCommand : ToastCommand {
      private readonly String m_snoozeArguments, m_dismissArguments;
      public ToastAlarmCommand(String snoozeArguments = null, String dismissArguments = null) : base(ToastCommandScenario.alarm) {
         m_snoozeArguments = snoozeArguments;
         m_dismissArguments = dismissArguments;
      }
      protected override List<XElement> AddCommands(List<XElement> commands) {
         AddCommand(commands, "snooze", m_snoozeArguments);
         AddCommand(commands, "dismiss", m_dismissArguments);
         return commands;
      }
   }

   /// <summary>Requires the "windows.lockScreenCall" extension be manually added to the app's extensions in the package manifest.</summary>
   public sealed class ToastIncomingCallCommand : ToastCommand {
      private readonly String m_videoArguments, m_voiceArguments, m_declineArguments;
      public ToastIncomingCallCommand(String videoArguments = null, String voiceArguments = null, String declineArguments = null) :base(ToastCommandScenario.incomingCall) {
         m_videoArguments = videoArguments;
         m_voiceArguments = voiceArguments;
         m_declineArguments = declineArguments;
      }
      protected sealed override List<XElement> AddCommands(List<XElement> commands) {
         AddCommand(commands, "video", m_videoArguments);
         AddCommand(commands, "voice", m_voiceArguments);
         AddCommand(commands, "decline", m_declineArguments);
         return commands;
      }
   }

   public sealed class ToastTemplate : TemplateBase {
      public ToastTemplate(ToastTemplateType templateType) {
         Visual = new ToastVisual(new ToastBinding(templateType));
      }
      public String Launch { get; set; }
      public ToastDuration? Duration { get; set; }
      public ToastAudio Audio { get; set; }
      public ToastVisual Visual { get; set; }
      public ToastCommand Command { get; set; }

      public Int32? VisualVersion {
         get { return Visual.Version; }
         set { Visual.Version = value; }
      }
      public String VisualLang {
         get { return Visual.Lang; }
         set { Visual.Lang = value; }
      }
      // Not used for toast: public Branding VisualBranding { get { return Visual.Branding; } set { Visual.Branding = value; } }
      public String VisualBaseUri {
         get { return Visual.BaseUri; }
         set { Visual.BaseUri = value; }
      }
      public IList<BindingImage> Images {
         get { return Visual.Binding.Images; }
         set { Visual.Binding.Images = value; }
      }
      public IList<BindingText> Text {
         get { return Visual.Binding.Text; }
         set { Visual.Binding.Text = value; }
      }
      public override XElement ToXElement() {
         ValidateImages(Visual.BaseUri, Images);
         var content = new List<Object>();
         if (Duration.HasValue) content.Add(new XAttribute("duration", Duration.ToString().ToLowerInvariant()));
         if (!String.IsNullOrWhiteSpace(Launch)) content.Add(new XAttribute("launch", Launch.HttpEncode()));
         if (Audio != null) content.Add(Audio.ToXElement());
         content.Add(Visual.ToXElement());
         if (Command != null) content.Add(Command.ToXElement());
         return new XElement("toast", content);
      }
   }

   public sealed class ToastAudio : TemplateBase {
      // For looping sounds, loop must be set to true or default looping sound is played
      public ToastAudio() { }
      public SoundEvent? Source { get; set; }
      public Boolean? Loop { get; set; }
      public Boolean? Silent { get; set; }
      public override XElement ToXElement() {
         var content = new List<Object>();
         if (Loop.HasValue) content.Add(new XAttribute("loop", Loop));
         if (Source.HasValue) {
            Boolean looping = Source.ToString().StartsWith("Looping");
            String soundName = looping ? Source.ToString().Substring(7) : Source.ToString();
            content.Add(new XAttribute("src", "ms-winsoundevent:Notification." + (looping ? "Looping." : String.Empty) + soundName));
         }
         if (Silent.HasValue) content.Add(new XAttribute("silent", Silent));
         return new XElement("audio", content);
      }
   }

   public sealed class ToastVisual : VisualTemplate {
      public ToastVisual(ToastBinding binding) { Binding = binding; }
      public ToastBinding Binding { get; set; }
      protected override IEnumerable<XElement> GetBindingElements() { return new[] { Binding.ToXElement() }; }
   }

   public sealed class ToastBinding : BindingTemplate<ToastTemplateType> {
      public ToastBinding(ToastTemplateType templateType) : base(templateType) { }
   }
   #endregion
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
