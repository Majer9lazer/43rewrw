﻿/******************************************************************************
Module:  Networking.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Text;
using Windows.Networking.Connectivity;

namespace Wintellect.WinRT.Networking {
   public static class NetworkExtensions {
      public static Boolean IsMetered(this NetworkCostType nct) {
         return nct == NetworkCostType.Fixed || nct == NetworkCostType.Variable;
      }

      public static UInt64 GetMaxTransferSizeInMegabytes(this ConnectionProfile cp, Boolean userOptIn = false,
         NetworkConnectivityLevel requiredLevel = NetworkConnectivityLevel.InternetAccess) {

         // If no physical connection or less than required, transfer 0 bytes
         if ((cp == null) || (cp.GetNetworkConnectivityLevel() < requiredLevel)) return 0; 

         // If the user opts in to full network usage, there is no limit
         if (userOptIn) return UInt64.MaxValue;

         ConnectionCost cc = cp.GetConnectionCost();

         // If expensive, don't transfer anything (your app can really use 1MB more)
         if (cc.Roaming || cc.OverDataLimit) return 0;

         // No limit if not metered
         if (!cc.NetworkCostType.IsMetered()) return UInt64.MaxValue;  

         // Return MaxTransferSizeinMegabytes (if exist) or no limit
         return cp.GetDataPlanStatus().MaxTransferSizeInMegabytes ?? UInt64.MaxValue;
      }

      public static String GetConnectionProfileString(this ConnectionProfile cp) {
         String NL2 = Environment.NewLine + Environment.NewLine;
         if (cp == null) return "Not connected";
         var sb = new StringBuilder();

         sb.AppendLine("Connection Profile:");
         sb.AppendFormat("   Connectivity level={0}, Names={1}" + NL2,
            cp.GetNetworkConnectivityLevel(), String.Join("; ", cp.GetNetworkNames()));

         sb.AppendLine("Network Adapter:");
         NetworkAdapter na = cp.NetworkAdapter;
         sb.AppendFormat("   Id={0}, Iana interface type={1}, Max in/out bytes/sec={2:N0}/{3:N0}" + NL2,
            na.NetworkAdapterId, na.IanaInterfaceType, na.InboundMaxBitsPerSecond, na.OutboundMaxBitsPerSecond);

         sb.AppendLine("Network Security Settings:");
         NetworkSecuritySettings nss = cp.NetworkSecuritySettings;
         sb.AppendFormat("   Authentication type={0}, Encryption type={1}" + NL2,
            nss.NetworkAuthenticationType, nss.NetworkEncryptionType);

         sb.AppendLine("Connection Cost:");
         ConnectionCost cc = cp.GetConnectionCost();
         sb.AppendFormat("   Cost type={0}, Roaming={1}, Over data limit={2}, Approaching data limit={3}" + NL2,
            cc.NetworkCostType, cc.Roaming, cc.OverDataLimit, cc.ApproachingDataLimit);

         sb.AppendLine("Data Plan Status:");
         DataPlanStatus dps = cp.GetDataPlanStatus();
         sb.AppendFormat("   Data limit={0}MB, In/out bits/sec={1}/{2}, Max transfer size={3}MB, Next billing cycle={4}" + NL2,
            dps.DataLimitInMegabytes, dps.InboundBitsPerSecond, dps.OutboundBitsPerSecond, dps.MaxTransferSizeInMegabytes, dps.NextBillingCycle);

         sb.AppendLine("Data Plan Usage:");
         DataPlanUsage dpu = dps.DataPlanUsage;
         if (dpu == null) sb.AppendLine("   Not available");
         else sb.AppendFormat("   MB used={0:N0} as of {1:D}", dpu.MegabytesUsed, dpu.LastSyncTime);

         return sb.ToString();
      }
   }

   /*public static class IanaInterfaceType {
      public const Int32 Other = 1;
      public const Int32 Ethernet = 6;
      public const Int32 TokenRing = 9;
      public const Int32 Ppp = 23;
      public const Int32 Loopback = 24;
      public const Int32 Atm = 37;
      public const Int32 IEEE802_11Wireless = 71;
      public const Int32 Tunnel = 131;
      public const Int32 IEEE1394 = 144;
   }*/
}