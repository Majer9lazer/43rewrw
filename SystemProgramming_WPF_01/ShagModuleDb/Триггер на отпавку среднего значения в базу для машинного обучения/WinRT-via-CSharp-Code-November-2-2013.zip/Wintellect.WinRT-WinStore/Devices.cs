﻿/******************************************************************************
Module:  Devices.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using Windows.Storage.Streams;
using Windows.System.Profile;
using System.Runtime.InteropServices.WindowsRuntime;

#if false
      private async void Foo() {
         string filter = Windows.Devices.Portable.ServiceDevice.GetDeviceSelectorFromServiceId(Wintellect.WinRT.Devices.WellKnownDeviceGuids.Processor);
         var devices = await Windows.Devices.Enumeration.DeviceInformation.FindAllAsync(filter);
         foreach (Windows.Devices.Enumeration.DeviceInformation device in devices) {
            var str = new System.Text.StringBuilder();
            str.AppendFormat("{0} ({1}){2}", device.Name, device.Id, Environment.NewLine);
            foreach (string propName in device.Properties.Keys) {
               str.AppendFormat("   {0} ({1}){2}", propName, device.Properties[propName], Environment.NewLine);
            }
            var s = str.ToString();
         }
      }
#endif

namespace Wintellect.WinRT.Devices {
#if false
   public static class AppSpecificHardwareID {
      public static Byte[] GetHardwareId() {
         HardwareToken hardwareToken = HardwareIdentification.GetPackageSpecificToken(null);
         IBuffer hardwareId = hardwareToken.Id;
         return hardwareId.ToArray();
      }
   }
   To verify on the server (also see http://msdn.microsoft.com/en-us/library/windows/apps/jj835815.aspx):
               var key = cert.PublicKey.Key as RSACryptoServiceProvider;
            var rsa = new RSACng(1024)
                          {
                              EncryptionHashAlgorithm = CngAlgorithm.Sha256,
                              SignatureHashAlgorithm = CngAlgorithm.Sha1,
                              SignaturePaddingMode = AsymmetricPaddingMode.Pss,
                              SignatureSaltBytes = 0,
                          };
             var parameters = key.ExportParameters(false);
            rsa.ImportParameters(parameters);
            
            var ok = rsa.VerifyData(data, signature);

#endif

   public static class WellKnownDeviceGuids {
      // http://msdn.microsoft.com/en-us/library/windows/hardware/ff553412(v=vs.85).aspx
      public static readonly Guid BatteryAndAcpi_Processor = new Guid("97fadb10-4e33-40ae-359c-8bef029dbdd0");
      public static readonly Guid BatteryAndAcpi_ApplicationLaunchButton = new Guid("629758EE-986E-4D9E-8E47-DE27F8AB054D");
      public static readonly Guid BatteryAndAcpi_Battery = new Guid("72631E54-78A4-11D0-BCF7-00AA00B7B32A");
      public static readonly Guid BatteryAndAcpi_Lid = new Guid("4AFA3D52-74A7-11d0-be5e-00A0C9062857");
      public static readonly Guid BatteryAndAcpi_Memory = new Guid("3FD0F03D-92E0-45FB-B75C-5ED8FFB01021");
      public static readonly Guid BatteryAndAcpi_MessageIndicator = new Guid("CD48A365-FA94-4CE2-A232-A1B764E5D8B4");
      public static readonly Guid BatteryAndAcpi_SysButton = new Guid("4AFA3D53-74A7-11d0-be5e-00A0C9062857");
      public static readonly Guid BatteryAndAcpi_ThermalZone = new Guid("4AFA3D51-74A7-11d0-be5e-00A0C9062857");

      public static readonly Guid DisplayAndImage_Brightness = new Guid("FDE5BBA4-B3F9-46FB-BDAA-0728CE3100B4");
      public static readonly Guid DisplayAndImage_DisplayAdapter = new Guid("5B45201D-F2F2-4F3B-85BB-30FF1F953599");
      public static readonly Guid DisplayAndImage_I2C = new Guid("2564AA4F-DDDB-4495-B497-6AD4A84163D7");
      public static readonly Guid DisplayAndImage_Image = new Guid("6BDD1FC6-810F-11D0-BEC7-08002BE2092F}");
      public static readonly Guid DisplayAndImage_Monitor = new Guid("E6F07B5F-EE97-4a90-B076-33F57BF4EAA7}");
      public static readonly Guid DisplayAndImage_Opm = new Guid("BF4672DE-6B4E-4BE4-A325-68A91EA49C09");
      public static readonly Guid DisplayAndImage_VideoOutputArrival = new Guid("1AD9E4F0-F88D-4360-BAB9-4C2D55E564CD");
      public static readonly Guid DisplayAndImage_DeviceArrival = new Guid("1CA05180-A699-450A-9A0C-DE4FBE3DDD89");

      public static readonly Guid InteractiveInput_Hid = new Guid("4D1E55B2-F16F-11CF-88CB-001111000030");
      public static readonly Guid InteractiveInput_Keyboard = new Guid("884b96c3-56ef-11d1-bc8c-00a0c91405dd");
      public static readonly Guid InteractiveInput_Mouse = new Guid("378DE44C-56EF-11D1-BC8C-00A0C91405DD");

      public static readonly Guid Network_Net = new Guid("CAC88484-7515-4C03-82E6-71A87ABAC361");

      public static readonly Guid Usb_Device = new Guid("A5DCBF10-6530-11D2-901F-00C04FB951ED");
      public static readonly Guid Usb_HostController = new Guid("3ABF6F2D-71C4-462A-8A92-1E6861E6AF27");
      public static readonly Guid Usb_Hub = new Guid("F18A0E88-C30C-11D0-8815-00A0C906BED8");
   }
}