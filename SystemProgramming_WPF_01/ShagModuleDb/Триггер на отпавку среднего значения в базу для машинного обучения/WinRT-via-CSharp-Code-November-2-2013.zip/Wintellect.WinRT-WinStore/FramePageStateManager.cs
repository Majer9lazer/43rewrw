﻿/******************************************************************************
Module:  FramePageStateManager.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Xml;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls;

namespace Wintellect.WinRT.FramePageStateManager {
   using Windows.ApplicationModel.Activation;
   using PageInstanceState = Dictionary<String, Object>;
   using PagesState = List<Dictionary<String, Object>>;

   public static class FramePageStateManager {
      // App holds Frame(s), each Frame holds FrameState, each FrameState hold NavState & PagesState,
      // each PagesState holds PageInstance State
      private static readonly ConditionalWeakTable<Frame, FrameState> s_frames = new ConditionalWeakTable<Frame, FrameState>();

      [DataContract]
      private sealed class FrameState {
         public FrameState() { PagesState = new PagesState(); }
         [DataMember]
         public String NavigationState { get; set; }
         [DataMember]
         public PagesState PagesState { get; private set; }
      }

      public static PageInstanceState GetCurrentPageState(this Page page, Boolean newPage) {
         // When page created, it asks us for PIS and page holds reference to it.
         // Page can read/write to it over its lifetime
         Frame frame = page.Frame;
         FrameState frameState = s_frames.GetOrCreateValue(frame);
         PagesState pagesState = frameState.PagesState;
         if (newPage) {
            pagesState.RemoveRange(frame.BackStackDepth, pagesState.Count - frame.BackStackDepth);
            var pis = new PageInstanceState();
            pagesState.Add(pis);
            return pis;
         }
         return pagesState[frame.BackStackDepth];
      }

      private static readonly List<Type> s_knownTypes = new List<Type> { typeof(FrameState), typeof(DateTimeOffset) };
      public static IList<Type> KnownTypes { get { return s_knownTypes; } }

      // When app suspended, Get active page (Window.Current), cast to IXxx and call PersistState & serialize all state including backstack info.
      public static async Task SerializePageStateAsync(this Frame frame, String filename) {
         // Serialize synchronously to avoid asynchronous access to shared state
         var dcs = new DataContractSerializer(typeof(PagesState), s_knownTypes);
         using (var memStream = new MemoryStream()) {
            FrameState frameState = s_frames.GetOrCreateValue(frame);
            frameState.NavigationState = frame.GetNavigationState();
            dcs.WriteObject(memStream, frameState);

            StorageFile file = await ApplicationData.Current.LocalFolder.CreateFileAsync(filename, CreationCollisionOption.ReplaceExisting).AsTask().ConfigureAwait(false);
            using (StorageStreamTransaction sst = await file.OpenTransactedWriteAsync().AsTask().ConfigureAwait(false))
            using (IRandomAccessStream stream = sst.Stream) {
               await stream.WriteAsync(memStream.ToArray().AsBuffer()).AsTask().ConfigureAwait(false);
               await sst.CommitAsync().AsTask().ConfigureAwait(false);
            }
         }
      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="filename"></param>
      /// <param name="frame"></param>
      /// <returns>true if previous state restored</returns>
      public static async Task<Boolean> DeserializePageStateAsync(this Frame frame, String filename, IActivatedEventArgs args, Boolean test = false) {
         Boolean previousStateRestored = false;
         try {
            StorageFile file = null;
            if (test || args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               var dcs = new DataContractSerializer(typeof(PagesState), s_knownTypes);
               file = await ApplicationData.Current.LocalFolder.GetFileAsync(filename).AsTask().ConfigureAwait(false);
               using (var stream = await file.OpenStreamForReadAsync().ConfigureAwait(false)) {
                  FrameState frameState = (FrameState)dcs.ReadObject(stream);
                  s_frames.Add(frame, frameState);
                  frame.SetNavigationState(frameState.NavigationState);
               }
               previousStateRestored = true;
            }
            if (!test && file != null)
               await file.DeleteAsync(StorageDeleteOption.PermanentDelete).AsTask().ConfigureAwait(false); // Delete the state whether we use it or not
         }
         catch (Exception ex) {
            if (ex is FileNotFoundException || ex is XmlException /* empty file */) {
               s_frames.Add(frame, new FrameState());
            } else throw;
         }
         return previousStateRestored;
      }
   }
}
