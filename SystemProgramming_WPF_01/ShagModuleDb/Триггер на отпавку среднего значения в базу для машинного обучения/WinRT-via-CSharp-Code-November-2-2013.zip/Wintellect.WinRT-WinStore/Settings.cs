﻿/******************************************************************************
Module:  Settings.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using Windows.Storage;
using Wintellect.Settings;
using Wintellect.WinRT.Settings;

namespace Wintellect.Settings {
   public class SettingAttribute : Attribute {
      public String SettingName { get; internal set; }

      public SettingAttribute(String settingName = null) {
         SettingName = settingName;
      }
   }

   public interface ISettingStore<TSettings> : INotifyPropertyChanged {
      T Get<T>(T defaultValue = default(T), [CallerMemberName] String propertyName = null);
      T Get<T>(Func<T> defaultValue, [CallerMemberName] String propertyName = null);
      void Set<T>(T value, [CallerMemberName] String propertyName = null);
      void RemoveSettings();
   }

   public abstract class SettingStore<TSettings, TAttribute> : ISettingStore<TSettings> where TAttribute : SettingAttribute {
      private static IDictionary<String, TAttribute> s_propertiesToSettings = null;

      protected SettingStore() {
         LazyInitializer.EnsureInitialized(ref s_propertiesToSettings, DiscoverPropertySettings);
         if (s_propertiesToSettings.Count == 0) {
            throw new InvalidOperationException(
               String.Format("No properties on the {0} type have an {1} attribute applied.",
               typeof(TSettings), typeof(TAttribute).FullName));
         }
      }

      protected virtual IDictionary<String, TAttribute> DiscoverPropertySettings() {
         var dic = new Dictionary<String, TAttribute>();
         foreach (var pi in typeof(TSettings).GetTypeInfo().DeclaredProperties) {
            TAttribute sa = ProcessPropertySetting(pi, pi.GetCustomAttribute<TAttribute>());
            if (sa == null) continue;
            sa.SettingName = sa.SettingName ?? pi.Name;
            dic.Add(pi.Name, sa);
         }
         return dic;
      }

      protected virtual TAttribute ProcessPropertySetting(PropertyInfo pi, TAttribute attribute) {
         if (attribute == null) attribute = (TAttribute)new SettingAttribute(pi.Name);
         return attribute;
      }

      protected TAttribute GetPropertySettings([CallerMemberName] String propertyName = null) {
         return s_propertiesToSettings[propertyName];
      }

      public T Get<T>(T defaultValue = default(T), [CallerMemberName] String propertyName = null) {
         Object value;
         return TryGetValue(propertyName, out value) ? (T)value : defaultValue;
      }

      public T Get<T>(Func<T> defaultValue, [CallerMemberName] String propertyName = null) {
         Object value;
         return TryGetValue(propertyName, out value) ? (T)value : defaultValue();
      }

      protected abstract Boolean TryGetValue(String propertyName, out Object value);

      public void Set<T>(T value, [CallerMemberName] String propertyName = null) {
         if (SetValue(propertyName, value)) OnPropertyChanged(propertyName);
      }
      protected abstract Boolean SetValue(String propertyName, Object value);

      public event PropertyChangedEventHandler PropertyChanged;
      public virtual void OnPropertyChanged(String propertyName) {
         var handler = PropertyChanged;
         if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
      }

      public void RemoveSettings() {
         foreach (var property in s_propertiesToSettings)
            Remove(property.Value);
      }
      protected abstract void Remove(TAttribute setting);
   }

   public sealed class DictionarySettingStore<TSettings> : SettingStore<TSettings, SettingAttribute> {
      private readonly IDictionary<String, Object> m_dictionary;
      public IDictionary<String, Object> Dictionary { get { return m_dictionary; } }
      public DictionarySettingStore(IDictionary<String, Object> dictionary) {
         m_dictionary = dictionary;
      }

      protected override Boolean TryGetValue(String propertyName, out Object value) {
         return m_dictionary.TryGetValue(propertyName, out value);
      }

      protected override Boolean SetValue(String propertyName, Object value) {
         m_dictionary[propertyName] = value;
         return true;
      }

      protected override void Remove(SettingAttribute setting) {
         m_dictionary.Remove(setting.SettingName);
      }
   }
}

namespace Wintellect.WinRT.Settings {
   #region Setting Custom Attributes
   public class AppDataSettingAttribute : SettingAttribute {
      public ApplicationDataLocality Locality { get; private set; }
      public ApplicationDataContainer Container { get; private set; }
      public AppDataSettingAttribute(ApplicationDataLocality locality, String settingName = null, String containerPath = null)
         : base(settingName) {
         Locality = locality;
         Container = SettingsHelpers.GetContainer(Locality, (containerPath == null) ? null : containerPath.Split('/'));
      }
   }

   // HighPriority value sync'd with <1 minute; must be in roaming root container.
   // Use with ApplicationData.Current.DataChanged
   // Use for media location, game board/high score.
   public sealed class HighPrioritySettingAttribute : AppDataSettingAttribute {
      public HighPrioritySettingAttribute() : base(ApplicationDataLocality.Roaming, "HighPriority") { }
   }
   #endregion

   public sealed class AppDataSettingStore<TSettings> : SettingStore<TSettings, AppDataSettingAttribute> {
      public ApplicationData AppData { get; private set; }

      public AppDataSettingStore(ApplicationData appData = null) {
         AppData = appData ?? ApplicationData.Current;
      }

      protected sealed override AppDataSettingAttribute ProcessPropertySetting(PropertyInfo pi, AppDataSettingAttribute attribute) {
         return (attribute == null) ? null : attribute;
      }

      private ApplicationDataContainer GetContainerAndSettingName(String propertyName, out String settingName) {
         var a = GetPropertySettings(propertyName);
         settingName = a.SettingName;
         return a.Container;
      }

      protected sealed override Boolean TryGetValue(String propertyName, out Object value) {
         String settingName;
         return GetContainerAndSettingName(propertyName, out settingName).Values.TryGetValue(settingName, out value);
      }

      public TComposite GetComposite<TComposite>([CallerMemberName] String propertyName = null) {
         // Get the ApplicationDataCompositeValue or a new one if none exists
         ApplicationDataCompositeValue adcv = Get<ApplicationDataCompositeValue>(
            () => new ApplicationDataCompositeValue(), propertyName);

         // Create the facade type passing the backing store to its constructor
         return (TComposite)Activator.CreateInstance(typeof(TComposite),
            new AppDataCompositeValueSettingStore<TComposite>(adcv));
      }
      public void SetComposite<TComposite>(AppDataCompositeValueSettingStore<TComposite> value, [CallerMemberName] String propertyName = null) {
         Set<ApplicationDataCompositeValue>(value.CompositeValue, propertyName);
      }

      protected sealed override Boolean SetValue(String propertyName, Object value) {
         String settingName;
         GetContainerAndSettingName(propertyName, out settingName).Values[settingName] = value;
         return true;
      }

      protected sealed override void Remove(AppDataSettingAttribute setting) {
         setting.Container.Values.Remove(setting.SettingName);
      }
   }

   public sealed class AppDataCompositeValueSettingStore<TSettings> : SettingStore<TSettings, SettingAttribute> {
      public ApplicationDataCompositeValue CompositeValue { get; private set; }
      public AppDataCompositeValueSettingStore(ApplicationDataCompositeValue compositeValue) {
         CompositeValue = compositeValue;
      }

      protected override Boolean TryGetValue(String propertyName, out Object value) {
         return CompositeValue.TryGetValue(GetPropertySettings(propertyName).SettingName, out value);
      }

      protected sealed override Boolean SetValue(String propertyName, Object value) {
         CompositeValue[GetPropertySettings(propertyName).SettingName] = value;
         return true;
      }

      protected sealed override void Remove(SettingAttribute setting) {
         CompositeValue.Remove(setting.SettingName);
      }
   }
}

namespace Wintellect.WinRT.Settings {
   public static class SettingsHelpers {
      public static ApplicationDataContainer GetContainer(ApplicationDataLocality locality, String[] path = null) {
         ApplicationDataContainer adc = null;
         switch (locality) {
            case ApplicationDataLocality.Local: adc = ApplicationData.Current.LocalSettings; break;
            case ApplicationDataLocality.Roaming: adc = ApplicationData.Current.RoamingSettings; break;
            case ApplicationDataLocality.Temporary: throw new ArgumentException("No such thing as Temporary settings.");
         }
         if (path == null) return adc;
         for (Int32 p = 0; p < path.Length; p++) {
            adc = adc.CreateContainer(path[p], ApplicationDataCreateDisposition.Always);
         }
         return adc;
      }

      private static String Dump(ApplicationDataLocality locality) {
         var sb = new StringBuilder();
         foreach (var kvp in GetContainer(locality).Values) {
            if (sb.Length > 0) sb.Append(", ");
            sb.AppendFormat("{0}={1}", kvp.Key, kvp.Value);
         }
         return sb.ToString();
      }

#if false
      private static readonly Type[] s_supportedTypes = new[] { 
         typeof(Byte), typeof(Int32), typeof(UInt32), typeof(Int64), typeof(UInt64), typeof(Single), typeof(Double), 
         typeof(Boolean), typeof(Char), typeof(String), typeof(DateTimeOffset), typeof(TimeSpan), 
         typeof(Guid), typeof(Point), typeof(Size), typeof(Rect)
      };
      public static Boolean IsSupportedType(Type type, Boolean containerIsApplicationDataCompositeValue = false) {
         if (!containerIsApplicationDataCompositeValue && (type == typeof(ApplicationDataCompositeValue))) return true;
         if (type.IsArray) type = type.GetElementType();   // Arrays of the supported types is OK
         return s_supportedTypes.Any(t => t == type);
      }

      internal static Object SerializedValue<T>(T value, Boolean containerIsApplicationDataCompositeValue = false) {
         // Supported types are placed directly in the container
         if (IsSupportedType(typeof(T), containerIsApplicationDataCompositeValue)) return value;

         // Unsupported types are serialized
         using (var ms = new MemoryStream()) {
            new DataContractSerializer(typeof(T)).WriteObject(ms, value);
            return ms.ToArray();
         }
      }

      internal static T DeserializedValue<T>(Object value, Boolean containerIsApplicationDataCompositeValue = false) {
         // Supported types are returned directly; unsupported types are deserialized
         if (IsSupportedType(typeof(T), containerIsApplicationDataCompositeValue)) return (T)value;

         // Unsupported types are deserialized
         using (var ms = new MemoryStream((Byte[])value)) {
            return (T)new DataContractSerializer(typeof(T)).ReadObject(ms);
         }
      }
#endif
   }
}

#if false
namespace SampleUsage {
   using Wintellect.Settings;
   using Wintellect.WinRT.Settings;
   internal static class Sample {
      public static void Main() {
         var dic = new Dictionary<String, Object>();
         var store = (ISettingStore<UserSettings>)new DictionarySettingStore<UserSettings>(dic);
         //var state = new UserSettings(store);   // Requires ISettingStore; not IAppDataSettingStore
      }

      public sealed class UserSettings : INotifyPropertyChanged {
         private readonly AppDataSettingStore<UserSettings> m_store;
         public UserSettings(AppDataSettingStore<UserSettings> store = null) {
            m_store = store ?? new AppDataSettingStore<UserSettings>();
         }

         // The Composite property shows how to declare a "HighPriority" & composite setting
         [HighPrioritySetting]
         public Composite Composite {
            get { return m_store.GetComposite<Composite>(); }
            set { m_store.SetComposite(value.m_store); }
         }

         [AppDataSetting(ApplicationDataLocality.Local, "User")]
         public String Name {
            get { return m_store.Get(String.Empty); }
            set { m_store.Set(value); }
         }
         public void RemoveSettings() { m_store.RemoveSettings(); }
         public event PropertyChangedEventHandler PropertyChanged {
            add { m_store.PropertyChanged += value; }
            remove { m_store.PropertyChanged -= value; }
         }
      }

      // This class shows how to define a composite value
      public sealed class Composite : INotifyPropertyChanged {
         // Internal because UserSettings' property needs to access it
         internal AppDataCompositeValueSettingStore<Composite> m_store;

         public Composite(AppDataCompositeValueSettingStore<Composite> store) { m_store = store; }

         public String Prop1 {
            get { return m_store.Get("Prop1 Default"); }
            set { m_store.Set(value); }
         }
         public Int32 Prop2 {
            get { return m_store.Get(123); }
            set { m_store.Set(value); }
         }
         public void RemoveSettings() {
            m_store.RemoveSettings();
         }
         public event PropertyChangedEventHandler PropertyChanged {
            add { m_store.PropertyChanged += value; }
            remove { m_store.PropertyChanged -= value; }
         }
      }
   }
}
#endif


