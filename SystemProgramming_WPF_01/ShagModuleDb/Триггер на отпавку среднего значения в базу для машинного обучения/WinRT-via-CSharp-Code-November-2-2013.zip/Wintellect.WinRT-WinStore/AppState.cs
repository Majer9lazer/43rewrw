﻿/******************************************************************************
Module:  AppData.cs
Notices: Copyright (c) 2012 by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Storage;
using Wintellect.WinRT.AppState;


namespace Example {
   using Wintellect;
   public sealed class MyState {
      private readonly BackingStore m_backingStore;
      public MyState(BackingStore backingStore) { m_backingStore = backingStore; }
      public String Name {
         get { return m_backingStore.Load(String.Empty); }
         set { m_backingStore.Save(value); }
      }
      public DateTime Birthday {
         get { return m_backingStore.Load(default(DateTime)); }
         set { m_backingStore.Save(value); }
      }
   }
}


namespace Wintellect {
   public abstract class BackingStore : INotifyPropertyChanged {
      public abstract void Clear();
      public abstract T Load<T>(T defaultValue = default(T), [CallerMemberName] String propertyName = null);

      public abstract void Save<T>(T value, [CallerMemberName] String propertyName = null);
      public event PropertyChangedEventHandler PropertyChanged;
      protected virtual void OnPropertyChanged(String propertyName) {
         var handler = PropertyChanged;
         if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
      }
   }

   public sealed class DictionaryBackingStore : BackingStore {
      public IDictionary<String, Object> Dictionary { get; private set; }
      public DictionaryBackingStore(IDictionary<String, Object> dictionary) {
         Dictionary = dictionary;
      }
      public override void Clear() { Dictionary.Clear(); }

      public override T Load<T>(T defaultValue = default(T), string propertyName = null) {
         return (T)Dictionary[propertyName];
      }

      public override void Save<T>(T value, String propertyName = null) {
         Dictionary[propertyName] = value;
         OnPropertyChanged(propertyName);
      }
   }
}

namespace Wintellect.WinRT.AppState {
   public sealed class AppDataContainerBackingStore : BackingStore {
      public ApplicationDataCompositeValue CompositeValue { get; private set; }
      public AppDataContainerBackingStore(ApplicationDataCompositeValue compositeValue) {
         CompositeValue = compositeValue;
      }
      public override void Clear() { CompositeValue.Clear(); }

      public override T Load<T>(T defaultValue = default(T), string propertyName = null) {
         return (T)CompositeValue[propertyName];
      }

      public override void Save<T>(T value, String propertyName = null) {
         //AppStateAttribute asa = m_propertyNameToStateInfo[propertyName];
         //Container.Values[asa.SettingKeyName ?? propertyName] = AppStateHelpers.SerializedValue(value);
         CompositeValue[propertyName] = value;
         OnPropertyChanged(propertyName);
      }
   }

   public sealed class AppStateAttribute : Attribute {
      public ApplicationDataLocality Locality { get; private set; }
      public ApplicationDataContainer Container { get; private set; }
      public String SettingKeyName { get; set; }

      public AppStateAttribute(ApplicationDataLocality locality, String containerPath = null) {
         Locality = locality;
         Container = AppStateHelpers.GetContainer(Locality, containerPath.Split('/'));
      }
   }

   public class AppDataBackingStore : BackingStore, INotifyPropertyChanged {
      private readonly Dictionary<String, AppStateAttribute> m_propertyToAppStateAttribute = new Dictionary<String, AppStateAttribute>();

      private ApplicationData AppData { get; set; }
      public AppDataBackingStore(ApplicationData appData = null) { 
         AppData = appData ?? ApplicationData.Current;

         foreach (var pi in GetType().GetTypeInfo().DeclaredProperties) {  // TODO: What about HighPriority & derived classes?
            var asa = pi.GetCustomAttribute<AppStateAttribute>();
            if (asa == null) asa = new AppStateAttribute(ApplicationDataLocality.Local) { SettingKeyName = pi.Name };
            m_propertyToAppStateAttribute.Add(pi.Name, asa);
         }
      }
      public override void Clear() { AppData.ClearAsync().GetAwaiter().GetResult(); }  // JMR: Async other localities

      public override T Load<T>(T defaultValue = default(T), string propertyName = null) {
         String key;
         return AppStateHelpers.DeserializedValue<T>(GetContainerAndKey(propertyName, out key).Values[key]);
      }

      public override void Save<T>(T value, String propertyName = null) {
         String key;
         GetContainerAndKey(propertyName, out key).Values[key] = AppStateHelpers.SerializedValue(value);
         OnPropertyChanged(propertyName);
      }

      private ApplicationDataContainer GetContainerAndKey(String propertyName, out String key) {
         var a = m_propertyToAppStateAttribute[propertyName];
         key = a.SettingKeyName;
         return a.Container;
      }
   }

   public sealed class AppDataBackingStore<THighPriority> : AppDataBackingStore, INotifyPropertyChanged {
      // HighPriority value sync'd with <1 minute; must be in roaming root container.
      // Use with ApplicationData.Current.DataChanged
      // Use for media location, game board/high score.
      [AppState(ApplicationDataLocality.Roaming, SettingKeyName = "HighPriority")]
      public THighPriority HighPriority {
         get { return Load(default(THighPriority)); }
         set { Save(value); }
      }
   }
}



namespace Wintellect.WinRT.AppState {
   public static class AppStateHelpers {
      private static readonly Type[] s_supportedTypes = new[] { 
         typeof(Byte), typeof(Int32), typeof(UInt32), typeof(Int64), typeof(UInt64), typeof(Single), typeof(Double), 
         typeof(Boolean), typeof(Char), typeof(String), typeof(DateTimeOffset), typeof(TimeSpan), 
         typeof(Guid), typeof(Point), typeof(Size), typeof(Rect)
      };
      public static Boolean IsSupportedType(Type type, Boolean containerIsApplicationDataCompositeValue = false) {
         if (!containerIsApplicationDataCompositeValue && (type == typeof(ApplicationDataCompositeValue))) return true;
         if (type.IsArray) type = type.GetElementType();   // Arrays of the supported types is OK
         return s_supportedTypes.Any(t => t == type);
      }

      //private static readonly Windows.Storage.ApplicationData s_appData = Windows.Storage.ApplicationData.Current;
      public static ApplicationDataContainer GetContainer(ApplicationDataLocality locality, String[] path = null) {
         ApplicationDataContainer adc = null;
         switch (locality) {
            case ApplicationDataLocality.Local: adc = ApplicationData.Current.LocalSettings; break;
            case ApplicationDataLocality.Roaming: adc = ApplicationData.Current.RoamingSettings; break;
            case ApplicationDataLocality.Temporary: throw new ArgumentException("No such thing as Temporary settings.");
         }
         if (path == null) return adc;
         for (Int32 p = 0; p < path.Length; p++) {
            adc = adc.CreateContainer(path[p], ApplicationDataCreateDisposition.Always);
         }
         return adc;
      }

      private static String Dump(ApplicationDataLocality locality) {
         var sb = new StringBuilder();
         foreach (var kvp in GetContainer(locality).Values) {
            if (sb.Length > 0) sb.Append(", ");
            sb.AppendFormat("{0}={1}", kvp.Key, kvp.Value);
         }
         return sb.ToString();
      }
      //private static readonly StorageFolder[] s_folders = new[] { s_appData.LocalFolder, s_appData.RoamingFolder, s_appData.TemporaryFolder };

      internal static Object SerializedValue<T>(T value, Boolean containerIsApplicationDataCompositeValue = false) {
         // Supported types are placed directly in the container
         if (IsSupportedType(typeof(T), containerIsApplicationDataCompositeValue)) return value;

         // Unsupported types are serialized
         using (var ms = new MemoryStream()) {
            new DataContractSerializer(typeof(T)).WriteObject(ms, value);
            return ms.ToArray();
         }
      }

      internal static T DeserializedValue<T>(Object value, Boolean containerIsApplicationDataCompositeValue = false) {
         // Supported types are returned directly; unsupported types are deserialized
         if (IsSupportedType(typeof(T), containerIsApplicationDataCompositeValue)) return (T)value;

         // Unsupported types are deserialized
         using (var ms = new MemoryStream((Byte[])value)) {
            return (T)new DataContractSerializer(typeof(T)).ReadObject(ms);
         }
      }
   }
}

namespace Wintellect.WinRT.AppState {
   public abstract class AppState : INotifyPropertyChanged {
      #region static members
      private static ApplicationData Current { get { return ApplicationData.Current; } }

      public static event TypedEventHandler<ApplicationData, Object> DataChanged {
         add { Current.DataChanged += value; }
         remove { Current.DataChanged -= value; }
      }

      public static void SignalDataChanged() { Current.SignalDataChanged(); }
      #endregion

      protected const String HighPriority = "HighPriority";
      private readonly ApplicationDataContainer[] m_containers = new ApplicationDataContainer[2]; // For LocalSettings(0) & RoamingSettings(1)

      private readonly String[] m_containerPath = null;
      private readonly Dictionary<String, AppStateAttribute> m_propertyNameToStateInfo = new Dictionary<String, AppStateAttribute>();

      /// <summary>
      /// Path to desired subcontainer within locality; Use '/' to separate subcontainers.
      /// </summary>
      /// <param name="containerPath"></param>
      protected AppState(String containerPath = null) {
         if (containerPath != null) m_containerPath = containerPath.Split('/');
         Boolean anyLocal = false, anyRoaming = false;
         foreach (var pi in GetType().GetTypeInfo().DeclaredProperties) {
            var asa = pi.GetCustomAttribute<AppStateAttribute>();
            if (asa == null) continue;
            m_propertyNameToStateInfo.Add(pi.Name, asa);
            if (asa.Locality == ApplicationDataLocality.Local) anyLocal = true;
            if (asa.Locality == ApplicationDataLocality.Roaming) anyRoaming = true;
         }

         if (anyLocal)
            m_containers[0] = AppStateHelpers.GetContainer(ApplicationDataLocality.Local, m_containerPath);

         if (anyRoaming)
            m_containers[1] = AppStateHelpers.GetContainer(ApplicationDataLocality.Roaming, m_containerPath);
      }

      public void ClearValues() {
         ClearValues(ApplicationDataLocality.Local);
         ClearValues(ApplicationDataLocality.Roaming);
      }

      public void ClearValues(ApplicationDataLocality locality) {
         var c = m_containers[(Int32)locality];
         if (c != null) c.Values.Clear();
      }

      public event PropertyChangedEventHandler PropertyChanged;
      protected virtual void OnPropertyChanged(String propertyName) {
         var handler = PropertyChanged;
         if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
      }

      protected void Save<T>(T value, [CallerMemberName] String propertyName = null) {
         AppStateAttribute asa = m_propertyNameToStateInfo[propertyName];
         m_containers[(Int32)asa.Locality].Values[asa.SettingKeyName ?? propertyName] =
            AppStateHelpers.SerializedValue(value);
         OnPropertyChanged(propertyName);
      }

      protected void SaveComposite<T>(T value, [CallerMemberName] String propertyName = null) where T : CompositeAppState {
         AppStateAttribute asa = m_propertyNameToStateInfo[propertyName];
         m_containers[(Int32)asa.Locality].Values[asa.SettingKeyName ?? propertyName] = value.m_adcv;
         OnPropertyChanged(propertyName);
      }

      protected T Load<T>(T defaultValue = default(T), [CallerMemberName] String propertyName = null) {
         AppStateAttribute asa = m_propertyNameToStateInfo[propertyName];
         Object value;
         if (!m_containers[(Int32)asa.Locality].Values.TryGetValue(asa.SettingKeyName ?? propertyName, out value))
            return defaultValue;
         return AppStateHelpers.DeserializedValue<T>(value);
      }

      protected T LoadComposite<T>([CallerMemberName] String propertyName = null) where T : CompositeAppState, new() {
         AppStateAttribute asa = m_propertyNameToStateInfo[propertyName];
         Object value;
         if (!m_containers[(Int32)asa.Locality].Values.TryGetValue(asa.SettingKeyName ?? propertyName, out value))
            return new T();
         return new T() { m_adcv = (ApplicationDataCompositeValue)value };
      }
   }

   public abstract class CompositeAppState : INotifyPropertyChanged {
      internal ApplicationDataCompositeValue m_adcv = new ApplicationDataCompositeValue();

      public event PropertyChangedEventHandler PropertyChanged;
      protected virtual void OnPropertyChanged(String propertyName) {
         var handler = PropertyChanged;
         if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
      }

      protected void SetValue<T>(T value, [CallerMemberName] String propertyName = null) {
         m_adcv.Add(propertyName, AppStateHelpers.SerializedValue<T>(value, true));
         OnPropertyChanged(propertyName);
      }

      protected T GetValue<T>(T defaultValue = default(T), [CallerMemberName] String propertyName = null) {
         Object value;
         if (!m_adcv.TryGetValue(propertyName, out value)) return defaultValue;
         return AppStateHelpers.DeserializedValue<T>(value, true);
      }
   }
}

#if false
namespace AppDataUsageDemo {
   using Wintellect.WinRT.AppData;

   internal sealed class PlmSettings : AppSettings {
      private static PlmSettings s_settings = null;
      public static PlmSettings GetCurrent() {
         if (s_settings == null) { s_settings = new PlmSettings(); }
         return s_settings;
      }
      private PlmSettings() { }

      [AppSetting(ApplicationDataLocality.Local)]
      public String Name {
         get { return GetValue("Default"); }
         set { SetValue(value); }
      }

      [AppSetting(ApplicationDataLocality.Local)]
      public Guid Guid {
         get { return GetValue(Guid.Empty); }
         set { SetValue(value); }
      }
   }
}
#endif