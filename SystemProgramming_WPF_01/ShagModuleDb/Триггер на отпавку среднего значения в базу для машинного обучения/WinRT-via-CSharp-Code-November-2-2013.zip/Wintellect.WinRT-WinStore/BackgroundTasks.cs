﻿using System;
using System.Collections.Generic;
using Windows.ApplicationModel.Background;

namespace Wintellect.WinRT.BackgroundTasks {
   public static class BackgroundTaskExtensions {
      public static IBackgroundTaskRegistration Register(this List<IBackgroundTaskRegistration> allTasks, String taskName, Type taskClass,
         IBackgroundTrigger trigger, Boolean cancelOnConditionLoss = true, params IBackgroundCondition[] conditions) {
         IBackgroundTaskRegistration registration = allTasks.Find(btr => btr.Name == taskName);
         if (registration == null) {
            registration = new BackgroundTaskBuilder().Configure(taskClass, trigger, taskName, cancelOnConditionLoss,
               conditions).Register();
            allTasks.Add(registration);
         }
         return registration;
      }
      public static BackgroundTaskBuilder Configure(this BackgroundTaskBuilder btb,
         Type taskClass, IBackgroundTrigger trigger,
         String name = null, Boolean cancelOnConditionLoss = true,
         params IBackgroundCondition[] conditions) {

         btb.Name = name ?? taskClass.Name;
         btb.TaskEntryPoint = taskClass.FullName;
         btb.SetTrigger(trigger);
         btb.CancelOnConditionLoss = cancelOnConditionLoss;
         foreach (IBackgroundCondition c in conditions) btb.AddCondition(c);
         return btb;
      }
      public static void UnregisterAll(this IReadOnlyDictionary<Guid, IBackgroundTaskRegistration> allTasks, Boolean cancelTask = true) {
         foreach (var kvp in allTasks) kvp.Value.Unregister(cancelTask);
      }
   }
}