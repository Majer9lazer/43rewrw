﻿/******************************************************************************
Module:  Wintellect.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Dynamic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Wintellect {
   public static class Helpers {
      [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
      public static TEnum[] GetEnumValues<TEnum>() where TEnum : struct { return (TEnum[])Enum.GetValues(typeof(TEnum)); }
   }

   public static class Extensions {
      [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
      public static Boolean IsNullOrWhiteSpace(this String @string) {
         return String.IsNullOrWhiteSpace(@string);
      }

      [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
      public static Byte[] Encode(this String @string, Encoding encoding = null) {
         return (encoding ?? Encoding.UTF8).GetBytes(@string);
      }

      [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
      public static String Decode(this Byte[] bytes, Encoding encoding = null) {
         return (encoding ?? Encoding.UTF8).GetString(bytes, 0, bytes.Length);
      }

      public static String CopyToClipboard(this String @string) {
         Windows.ApplicationModel.DataTransfer.Clipboard.Clear();
         var dp = new Windows.ApplicationModel.DataTransfer.DataPackage();
         dp.SetText(@string);
         Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(dp);
         Windows.ApplicationModel.DataTransfer.Clipboard.Flush();
         return @string;
      }

      [DebuggerStepThrough]
      public static String PascalCasingToWords(this Enum e) {
         return e.ToString().PascalCasingToWords();
      }

      [DebuggerStepThrough]
      public static String PascalCasingToWords(this String s) {
         var sb = new StringBuilder(s);
         for (Int32 index = 1; index < s.Length; index++) {
            if (Char.IsUpper(sb[index])) sb.Insert(index++, ' ');
         }
         return sb.ToString();
      }

      private static String[] PropsAsArray(this Object o) {
         return (from pi in o.GetType().GetTypeInfo().DeclaredProperties
                 orderby pi.Name
                 let value = pi.GetValue(o).ToString()
                 where pi.PropertyType.ToString() != value
                 select pi.Name + "=" + value).ToArray();
      }
      public static String PropsAsString(this Object o) {
         return String.Join(", ", PropsAsArray(o));
      }
   }

   public struct PropertyName<T> {
      public String this[LambdaExpression propertyExpression] {
         get {
            Expression body = propertyExpression.Body;
            MemberExpression me = (body is UnaryExpression)
               ? (MemberExpression)((UnaryExpression)body).Operand
               : (MemberExpression)body;
            return me.Member.Name;
         }
      }

      public String this[Expression<Func<T, Object>> propertyExpression] {
         get {
            return this[(LambdaExpression)propertyExpression];
         }
      }
      public String[] this[params Expression<Func<T, Object>>[] propertyExpressions] {
         get {
            var propertyNames = new String[propertyExpressions.Length];
            for (Int32 i = 0; i < propertyNames.Length; i++) propertyNames[i] = this[(LambdaExpression)propertyExpressions[i]];
            return propertyNames;
         }
      }
   }

   public sealed class Observable<T> : INotifyPropertyChanged {
      private T m_value;
      public Observable(T value) { m_value = value; }
      public T Value {
         get { return m_value; }
         set {
            if (!m_value.Equals(value)) {
               m_value = value;
               if (PropertyChanged != null)
                  PropertyChanged(this, new PropertyChangedEventArgs("Value"));
            }
         }
      }
      public override Boolean Equals(Object obj) {
         return m_value.Equals(obj);
      }
      public override Int32 GetHashCode() {
         return m_value.GetHashCode();
      }
      public override String ToString() {
         return m_value.ToString();
      }
      public event PropertyChangedEventHandler PropertyChanged;
   }

   public sealed class AwaitableEvent<TSender, TEventArgs> {
      private TaskCompletionSource<AwaitableEventArgs<TSender, TEventArgs>> m_tcs;

      public void Prime(Object state = null) { RaisedAsync(state); }

      // Returns an (awaitable) Task; set when EventHandler is invoked
      public Task<AwaitableEventArgs<TSender, TEventArgs>> RaisedAsync(Object state = null) {
         if (m_tcs == null)
            m_tcs = new TaskCompletionSource<AwaitableEventArgs<TSender, TEventArgs>>(state);
         return m_tcs.Task;
      }

      // Invoked when event is raised
      public void Handler(TSender sender, TEventArgs eventArgs) {
         if (m_tcs == null) return;
         // We use the temporary variable (tcs) & reset m_tcs to null before calling
         // SetResult because SetResult returns from await immediately which may
         // call RaisedAsync again and we need this to create a new TaskCompletionSource
         TaskCompletionSource<AwaitableEventArgs<TSender, TEventArgs>> tcs = m_tcs;
         m_tcs = null;
         tcs.SetResult(new AwaitableEventArgs<TSender, TEventArgs>(sender, eventArgs));
      }
   }

   public sealed class AwaitableEventArgs<TSender, TEventArgs> {
      public readonly TSender Sender;
      public readonly TEventArgs Args;
      internal AwaitableEventArgs(TSender sender, TEventArgs args) {
         Sender = sender;
         Args = args;
      }
   }

   /// <summary>Construct an instance of this class and cast the reference to 'dynamic' 
   /// to dynamically invoke a type's static members</summary>
   internal sealed class StaticMemberDynamicWrapper : DynamicObject {
      private readonly TypeInfo m_type;
      public StaticMemberDynamicWrapper(Type type) { m_type = type.GetTypeInfo(); }

      public override IEnumerable<String> GetDynamicMemberNames() {
         return m_type.DeclaredMembers.Select(mi => mi.Name);
      }

      public override bool TryGetMember(GetMemberBinder binder, out object result) {
         result = null;
         var field = FindField(binder.Name);
         if (field != null) { result = field.GetValue(null); return true; }

         var prop = FindProperty(binder.Name, true);
         if (prop != null) { result = prop.GetValue(null, null); return true; }
         return false;
      }

      public override bool TrySetMember(SetMemberBinder binder, object value) {
         var field = FindField(binder.Name);
         if (field != null) { field.SetValue(null, value); return true; }

         var prop = FindProperty(binder.Name, false);
         if (prop != null) { prop.SetValue(null, value, null); return true; }
         return false;
      }

      public override Boolean TryInvokeMember(InvokeMemberBinder binder, Object[] args, out Object result) {
         MethodInfo method = FindMethod(binder.Name, args.Select(o => o.GetType()).ToArray());
         if (method == null) { result = null; return false; }
         result = method.Invoke(null, args);
         return true;
      }

      private MethodInfo FindMethod(String name, Type[] paramTypes) {
         return m_type.DeclaredMethods.FirstOrDefault(mi => mi.IsPublic && mi.IsStatic
            && mi.Name == name && ParametersMatch(mi.GetParameters(), paramTypes));
      }

      private Boolean ParametersMatch(ParameterInfo[] parameters, Type[] paramTypes) {
         if (parameters.Length != paramTypes.Length) return false;
         for (Int32 i = 0; i < parameters.Length; i++)
            if (parameters[i].ParameterType != paramTypes[i]) return false;
         return true;
      }

      private FieldInfo FindField(String name) {
         return m_type.DeclaredFields.FirstOrDefault(fi => fi.IsPublic && fi.IsStatic && fi.Name == name);
      }

      private PropertyInfo FindProperty(String name, Boolean get) {
         if (get)
            return m_type.DeclaredProperties.FirstOrDefault(
               pi => pi.Name == name && pi.GetMethod != null &&
               pi.GetMethod.IsPublic && pi.GetMethod.IsStatic);

         return m_type.DeclaredProperties.FirstOrDefault(
            pi => pi.Name == name && pi.SetMethod != null &&
               pi.SetMethod.IsPublic && pi.SetMethod.IsStatic);
      }
   }
}
