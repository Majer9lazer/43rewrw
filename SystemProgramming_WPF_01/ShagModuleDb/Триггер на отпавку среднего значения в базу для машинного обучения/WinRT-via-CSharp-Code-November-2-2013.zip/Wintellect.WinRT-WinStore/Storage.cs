﻿/******************************************************************************
Module:  Storage.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;  // IBuffer -> ToArray
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Streams;

namespace Wintellect.WinRT.Storage {
   public static class StorageExtensions {
      [DebuggerStepThrough, MethodImpl(MethodImplOptions.AggressiveInlining)]
      public static void Show(String label, IBuffer msg, Int64 length = -1) {
         Show(label, msg.ToArray(), length);
      }

      public static void Show(String label, Byte[] msg, Int64 length = -1) {
         if (length == -1) length = msg.Length;
         String output = String.Format("{0,10} ({1} bytes): {2}", label, length,
            BitConverter.ToString(msg, 0, checked((Int32)length)));
         Debug.WriteLine(output);
      }

      public static TStorageItem CopyPathToClipboard<TStorageItem>(this TStorageItem item) where TStorageItem : IStorageItem {
         item.Path.CopyToClipboard();
         return item;
      }
   }

#if false
   public sealed class RandomAccessStreamOverInputStream : IRandomAccessStream {
      private IInputStream m_stream;
      public RandomAccessStreamOverInputStream(IInputStream inputStream) {
         m_stream = inputStream;
      }

      public bool CanRead { get { return true; } }
      public bool CanWrite { get { return false; } }
      public IRandomAccessStream CloneStream() { throw new NotImplementedException(); }
      public IInputStream GetInputStreamAt(ulong position) { throw new NotImplementedException(); }
      public IOutputStream GetOutputStreamAt(ulong position) { throw new NotImplementedException(); }
      public ulong Position { get { throw new NotImplementedException(); } }
      public void Seek(ulong position) { throw new NotImplementedException(); }
      public ulong Size {
         get { throw new NotImplementedException(); }
         set { throw new NotImplementedException(); }
      }
      public void Dispose() { m_stream.Dispose(); }

      public IAsyncOperationWithProgress<IBuffer, uint> ReadAsync(IBuffer buffer, uint count, InputStreamOptions options) {
         return m_stream.ReadAsync(buffer, count, options);
      }
      public IAsyncOperation<bool> FlushAsync() { throw new NotImplementedException(); }
      public IAsyncOperationWithProgress<uint, uint> WriteAsync(IBuffer buffer) { throw new NotImplementedException(); }
   }

   public sealed class RandomStream : IRandomAccessStream {
      private readonly Stream m_stream;
      public RandomStream(Stream stream) { m_stream = stream; }
      public RandomStream(Byte[] bytes) { m_stream = new MemoryStream(bytes); }

      public IInputStream GetInputStreamAt(UInt64 position) {
         if ((Int64)position > m_stream.Length) throw new IndexOutOfRangeException();
         m_stream.Position = (Int64)position;
         return m_stream.AsInputStream();
      }

      public IOutputStream GetOutputStreamAt(UInt64 position) {
         if ((Int64)position > m_stream.Length) throw new IndexOutOfRangeException();
         m_stream.Position = (Int64)position;
         return m_stream.AsOutputStream();
      }

      public ulong Size {
         get { return (UInt64)m_stream.Length; }
         set { m_stream.SetLength((Int64)value); }
      }
      public bool CanRead { get { return true; } }
      public bool CanWrite { get { return true; } }
      public ulong Position { get { return (UInt64)m_stream.Position; } }
      public void Seek(UInt64 position) { m_stream.Seek((Int64)position, 0); }

      public IRandomAccessStream CloneStream() { throw new NotSupportedException(); }
      public void Dispose() { m_stream.Dispose(); }
      public IAsyncOperationWithProgress<IBuffer, UInt32> ReadAsync(IBuffer buffer, UInt32 count, InputStreamOptions options) {
         throw new NotSupportedException();
      }
      public IAsyncOperation<Boolean> FlushAsync() { throw new NotImplementedException(); }
      public IAsyncOperationWithProgress<UInt32, UInt32> WriteAsync(IBuffer buffer) { throw new NotImplementedException(); }
   }
#endif
}
