﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace Popups {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
      }

      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         Frame rootFrame = Window.Current.Content as Frame;

         // Don't repeat app initialization when Window already has content, just activate window
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When navigation stack isn't restored, navigate to 1st page
            if (!rootFrame.Navigate(typeof(PopupsPage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure current window is active
         Window.Current.Activate();

         //Window.Current.Dispatcher.Invoke(CoreDispatcherPriority.Normal, (s, e) => { }, null, null);
         var id = Windows.ApplicationModel.Core.CoreApplication.Id;
         var v = Windows.ApplicationModel.Core.CoreApplication.GetCurrentView().CoreWindow == Window.Current.CoreWindow;
         var p = Windows.ApplicationModel.Core.CoreApplication.Properties;
         var views = Windows.ApplicationModel.Core.CoreApplication.Views.ToArray();
      }
   }
}
