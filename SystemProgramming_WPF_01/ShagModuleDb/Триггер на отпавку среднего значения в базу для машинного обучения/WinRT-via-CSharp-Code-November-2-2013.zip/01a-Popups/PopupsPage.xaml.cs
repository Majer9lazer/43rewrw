﻿/******************************************************************************
Module:  PopupsPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Web.Http;
using Wintellect.WinRT.AppAids;

namespace Popups {
   public sealed partial class PopupsPage : Page {
      // Invoked because DISABLE_XAML_GENERATED_MAIN is defined:
      public static void Main(String[] args) {
         AppAid.Start(p => new App(), null);
      }

      #region Mapping WinRT Async to .NET
      public static void WinRTAsyncIntro() {
         var asyncOp = KnownFolders.MusicLibrary.GetFileAsync("Song.mp3");
         asyncOp.Completed = OpCompleted;
         // Optional: call asyncOp.Cancel() sometime later
      }

      // NOTE: Code executes via GUI or thread pool thread:
      private static void OpCompleted(IAsyncOperation<StorageFile> asyncOp, AsyncStatus asyncStatus) {
         if (asyncStatus == AsyncStatus.Canceled) {
            // Process cancellation...
         } else {
            try {
               StorageFile file = asyncOp.GetResults();  // Throws if operation failed
               // Process result...
            }
            catch (Exception) {
               // Process exception...
            }
         }
         asyncOp.Close();
      }

      // NOTE: If invoked by GUI thread, all code executes via GUI thread:
      public async static void WinRTAsyncIntro2() {
         try {
            StorageFile file = await KnownFolders.MusicLibrary.GetFileAsync("Song.mp3");
            /* Completed... */
         }
         catch (TaskCanceledException) { /* Canceled... */ }
         catch (Exception) { /* Error... */ }
      }

      public static Task<TResult> AsTask<TResult, TProgress>(/*this */IAsyncOperationWithProgress<TResult, TProgress> asyncOp,
         CancellationToken ct = default(CancellationToken),
         IProgress<TProgress> progress = null) {

         // When CancellationTokenSource is canceled, cancel the async operation
         ct.Register(() => asyncOp.Cancel());

         // When the async operation reports progress, report it to the progress callback 
         asyncOp.Progress = (asyncInfo, p) => progress.Report(p);

         // This TaskCompletionSource monitors the async operation's completion
         var tcs = new TaskCompletionSource<TResult>();

         // When the async operation completes, notify the TaskCompletionSource
         // Code awaiting the TaskCompletionSource regains control when this happens
         asyncOp.Completed = (asyncOp2, asyncStatus) => {
            switch (asyncStatus) {
               case AsyncStatus.Completed: tcs.SetResult(asyncOp2.GetResults()); break;
               case AsyncStatus.Canceled: tcs.SetCanceled(); break;
               case AsyncStatus.Error: tcs.SetException(asyncOp2.ErrorCode); break;
            }
         };

         // When calling code awaits this returned Task, it calls GetAwaiter which 
         // wraps a SynchronizationContext around the Task ensuring that completion 
         // occurs on the SynchronizationContext object's context
         return tcs.Task;
      }

      private CancellationTokenSource m_cts = new CancellationTokenSource();

      private async void MappingWinRTAsyncToDotNet() {
         Windows.Storage.Streams.IInputStream s = null;
         try {
            // Returns IAsyncOperationWithProgress<IBuffer, UInt32> 
            IBuffer result2 = await s.ReadAsync(null, 0, InputStreamOptions.None).AsTask(m_cts.Token, new Progress<UInt32>(ProgressReport));
         }
         catch (OperationCanceledException) {
         }
      }

      private void ProgressReport(UInt32 progress) {
      }

      private void Cancel() {
         m_cts.Cancel();  // Called sometime later
      }
      #endregion

      public PopupsPage() {
         this.InitializeComponent();
         //WinRTAsyncIntro();
      }

      private async void CoreWindowDialog_Click(object sender, RoutedEventArgs e) {
         var cwd = new CoreWindowDialog("My Title") {
            DefaultCommandIndex = 0,
            BackButtonCommand = UICommandHandler,
            CancelCommandIndex = 0,
         };
         AddCommands(cwd.Commands, 3);
         IUICommand result = await cwd.ShowAsync();
      }
      //d.Showing += (s, e) => { };
      //d.SetDefaultCommandIndex(1);
      //var maxs = d.MaxSize;
      //var mins = d.MinSize;

      private async void CoreWindowFlyout_Click(object sender, RoutedEventArgs e) {
         var cwf = new CoreWindowFlyout(new Point(100, 100), "My Title") {
            DefaultCommandIndex = 0,
            BackButtonCommand = UICommandHandler
         };
         AddCommands(cwf.Commands, 2);
         IUICommand result = await cwf.ShowAsync();
      }

      private async void MessageDialog_Click(object sender, RoutedEventArgs e) {
         var md = new MessageDialog("This is the content", "This is the title") {
            DefaultCommandIndex = 0,
            CancelCommandIndex = 1
         };
         AddCommands(md.Commands, 3);
         IUICommand result = await md.ShowAsync();
      }

      private async void PopupMenu_Click(object sender, RoutedEventArgs e) {
         var pm = new PopupMenu();
         AddCommands(pm.Commands, 6);
         Rect bounds = Window.Current.CoreWindow.Bounds;
         IUICommand result = await pm.ShowAsync(new Point(bounds.Width / 2, bounds.Height / 2));
      }

      private void AddCommands(IList<IUICommand> commands, Int32 count) {
         // dialog <=3; flyout <= 2; message box <= 3; popup menu <= 6
         for (Int32 c = 0; c < count; c++) {
            if (c == 3) commands.Add(new UICommandSeparator());
            else commands.Add(new UICommand("Cmd #" + c, UICommandHandler, c));
         }
      }

      private void UICommandHandler(IUICommand command) {
         Object id = command.Id;
         UICommandInvokedHandler invoked = command.Invoked;
         String label = command.Label;
         var noWarning = Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
            () => m_txtSelectedCommand.Text = String.Format("Id={0}, Label={1}", id ?? "(none)", label));
      }
   }
}
