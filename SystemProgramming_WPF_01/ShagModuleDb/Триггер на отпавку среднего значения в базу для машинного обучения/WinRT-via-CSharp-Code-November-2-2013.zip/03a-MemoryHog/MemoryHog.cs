﻿/******************************************************************************
Module:  MemoryHog.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class Program {
   [STAThread]
   public static void Main() {
      if (IntPtr.Size != 8) {
         MessageBox.Show("Recompile this app specifying x64 for the platform", "Memory Hog App");
         Environment.Exit(1);
      }

      try {
         while (true) {
            var addr = VirtualAlloc(0, 2 * 1024 * 1024 * 1024ul, 
               AllocationType.Reserve | AllocationType.Commit, Protect.ReadWrite);
         }
      }
      catch (OutOfMemoryException) { }
      MessageBox.Show("Memory Allocated. Close this dialog to free the memory.", "Memory Hog App");
   }

   private enum AllocationType : int {
      Commit = 0x1000,
      Reserve = 0x2000,
      Reset = 0x80000
   }

   private enum Protect : int { ReadWrite = 0x4 }
 
   [DllImport("Kernel32", ExactSpelling = true, SetLastError = true)]
   private static extern UInt64 VirtualAlloc(UInt64 pAddress, UInt64 dwSize, AllocationType flAllocationType, Protect flProtect);
}