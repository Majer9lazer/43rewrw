﻿/******************************************************************************
Module:  MyPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.ComponentModel;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Wintellect.Settings;
using Wintellect.WinRT.DemoSpecific;
using Wintellect.WinRT.Settings;
using Wintellect.WinRT.FramePageStateManager;
using Windows.Storage.AccessCache;
using Windows.Storage.Pickers;
using Windows.ApplicationModel.Search;
using Windows.ApplicationModel.DataTransfer;
using Windows.System;
using Windows.ApplicationModel.Activation;
using Windows.Storage.Provider;
using Windows.Data.Xml.Dom;
using Windows.UI.Notifications;
using Windows.ApplicationModel.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Core;
using Windows.ApplicationModel.Contacts;

public sealed class SuspendSettings : INotifyPropertyChanged {
   private readonly ISettingStore<SuspendSettings> m_store;
   public SuspendSettings(ISettingStore<SuspendSettings> settingStore) { m_store = settingStore; }

   public Int32 PageNumber {
      get { return m_store.Get(0); }
      set { m_store.Set(value); }
   }

   public String SomeText {
      get { return m_store.Get(String.Empty); }
      set { m_store.Set(value); }
   }

   public void RemoveSettings() { m_store.RemoveSettings(); }

   public event PropertyChangedEventHandler PropertyChanged {
      add { m_store.PropertyChanged += value; }
      remove { m_store.PropertyChanged -= value; }
   }
}

namespace ProcessModel {
   public sealed partial class MyPage : Page {
      private SuspendSettings Settings;

      public MyPage() {
         InitializeComponent();
      }

      protected override void OnNavigatedTo(NavigationEventArgs e) {
         m_txtArgument.Text = e.Parameter.ToString(); // Show passed-in arg

         // Get this page's session state dictionary
         var pageState = this.GetCurrentPageState(e.NavigationMode == NavigationMode.New);

         // Create a strongly-typed Settings object backed by the dictionary store
         Settings = new SuspendSettings(new DictionarySettingStore<SuspendSettings>(pageState));

         // Save some state
         Settings.PageNumber = Frame.BackStackDepth;
         m_txtPageNum.Text = "Page #" + Settings.PageNumber;

         // Data bind the Text control to Setting's SomeText so it automatically stays in sync
         m_txtSomeText.DataContext = Settings;
         m_txtOther.DataContext = this;
         base.OnNavigatedTo(e);
      }

      protected override void OnNavigatedFrom(NavigationEventArgs e) {
         base.OnNavigatedFrom(e);
      }

      private void Crash(object sender, RoutedEventArgs e) {
         throw new InvalidOperationException("Purposeful app crash");
      }

      private void GoBack(object sender, RoutedEventArgs e) { Frame.GoBack(); }
      private void GoForward(object sender, RoutedEventArgs e) { Frame.GoForward(); }
      private void NewPage(object sender, RoutedEventArgs e) { Frame.Navigate(typeof(MyPage), Settings.SomeText); }

      #region Activation Tests
      public String OtherText { get { return String.Format("Previous execution state={0}", App.PreviousExecutionState); } }

      private async void FileActivate(object sender, RoutedEventArgs e) {
         StorageFile sf = await StorageFile.CreateStreamedFileAsync("Whatever.wintellect", sfdr => { sfdr.Dispose(); }, null);
         var t = Launcher.LaunchFileAsync(sf);
      }
      private void Protocol(object sender, RoutedEventArgs e) {
         var t = Launcher.LaunchUriAsync(new Uri("wintellect://foo"));
      }
      private async void FileOpen(object sender, RoutedEventArgs e) {
         StorageFile sf = await new FileOpenPicker { FileTypeFilter = { ".txt" } }.PickSingleFileAsync();
         if (sf == null) return;
         StorageApplicationPermissions.FutureAccessList.Clear();
         var token = StorageApplicationPermissions.FutureAccessList.Add(sf);
         sf = await StorageApplicationPermissions.FutureAccessList.GetFileAsync(token, AccessCacheOptions.None);
         var status = await CachedFileManager.CompleteUpdatesAsync(sf);
         var text = await FileIO.ReadTextAsync(sf);
      }
      private async void FileSave(object sender, RoutedEventArgs e) {
         var file = await new FileSavePicker {
            FileTypeChoices = { { "Wintellect files", new[] { ".wintellect" } } }
         }.PickSaveFileAsync();
         if (file == null) return;
         await FileIO.WriteTextAsync(file, "Text");
         await CachedFileManager.CompleteUpdatesAsync(file);
      }

      private void Search(object sender, RoutedEventArgs e) {
         SearchPane.GetForCurrentView().Show();
      }

      private void Share(object sender, RoutedEventArgs e) {
         DataTransferManager.ShowShareUI();
      }
      private async void Contact(object sender, RoutedEventArgs e) {
         Contact contact = await new ContactPicker().PickContactAsync();
      }

      private void Toast(object sender, RoutedEventArgs e) {
         XmlDocument xml = new XmlDocument();
         xml.LoadXml("<toast launch=\"???\"><visual><binding template=\"ToastText01\"><text id=\"1\">Click Me!</text></binding></visual></toast>");
         var tn = new ToastNotification(xml);
         ToastNotificationManager.CreateToastNotifier().Show(tn);
      }

      private IActivatedEventArgs m_args = null;
      private async void AddCachedFile(object sender, RoutedEventArgs e) {
         var args = (FileOpenPickerActivatedEventArgs)m_args;
         var sf = await ApplicationData.Current.LocalFolder.CreateFileAsync("CachedFile.plm", CreationCollisionOption.ReplaceExisting);
         await FileIO.WriteTextAsync(sf, "Cached file created...");
         CachedFileUpdater.SetUpdateInformation(sf, sf.DisplayName, ReadActivationMode.BeforeAccess,
            WriteActivationMode.AfterWrite, CachedFileOptions.RequireUpdateOnAccess);
         var token = StorageApplicationPermissions.FutureAccessList.Add(sf);
         sf = await StorageApplicationPermissions.FutureAccessList.GetFileAsync(token);
         var text = await FileIO.ReadTextAsync(sf);
         var dd = args.FileOpenPickerUI.AddFile(sf.Name, sf);
      }
      #endregion

      private async void NewView(object sender, RoutedEventArgs e) {
         // Have Windows create a new thread, CoreDispatcher, CoreWindow, and CoreApplcationView
         CoreApplicationView cav = CoreApplication.CreateNewView();

         CoreWindow newAppViewWindow = null; // This will hold the new view's window

         // Have the new thread initialize the new view's content
         await cav.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () => {
            // Give the new thread's window back to the creating thread
            newAppViewWindow = Window.Current.CoreWindow;

            // Create the desired UI element tree & make it the content of the new window
            Window.Current.Content = new MyPage();
            Window.Current.Activate();

            // Give the ID of the new thread's view back to the creating thread
            ApplicationView newAppView = ApplicationView.GetForCurrentView();
            newAppView.Title = "View #" + newAppView.Id;
            newAppView.IsScreenCaptureEnabled = false;
            newAppView.Consolidated += (appView, args) => { var x = args.IsUserInitiated; };
         });

         // After the new thread initializes its view, the creating thread makes it appear
         Int32 newAppViewId = ApplicationView.GetApplicationViewIdForWindow(newAppViewWindow);
         await ApplicationViewSwitcher.TryShowAsStandaloneAsync(newAppViewId, ViewSizePreference.UseLess);
      }
   }
}
