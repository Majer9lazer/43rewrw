﻿/******************************************************************************
Module:  App.Xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using ProcessModel.Settings;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Pickers.Provider;
using Windows.Storage.Provider;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Wintellect;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.FramePageStateManager;
using Wintellect.WinRT.Settings;

namespace ProcessModel {
   // Our singleton App class; store all app-wide data in this class object
   public sealed partial class App : Application {
      private const String c_FramePageStateFileName = "FramePageState.xml";

      // Accessing app data with the Windows Runtime: http://msdn.microsoft.com/en-us/library/windows/apps/hh464917.aspx
      internal readonly UserSettings Settings = new UserSettings();

      #region App Initialization
      // Invoked because DISABLE_XAML_GENERATED_MAIN is defined:
      public static void Main(String[] args) {
         // Invoked via process' primary thread each time the process initializes
         if (Debugger.IsAttached) Debugger.Break();
         AppAid.Start(AppInitialization, (f, a) => f.DeserializePageStateAsync(c_FramePageStateFileName, a));
      }

      private static void AppInitialization(ApplicationInitializationCallbackParams p) {
         // Invoked via main view thread 
         // But, the main view's CoreWindow & CoreDispatcher do NOT exist yet; 
         // they are created by Application.Start after this method returns         
         if (Debugger.IsAttached) Debugger.Break();

         // Create a singleton App object. It never gets GC'd because the base class (Application)
         // holds a reference to it obtainable via Application.Current
         var app = new App();  

         // Optional: Call this method to show an extended splash screen during 1st main view activation
         //AppAid.SetShowSplashScreenAsync(app.ShowSplashScreenAsync);
      }

      private App() {
         // Invoked via main view thread; CoreWindow & CoreDispatcher do NOT exist yet
         this.InitializeComponent();
         this.Resuming += OnResuming;     // Raised when main view thread resumes from suspend
         this.Suspending += OnSuspending; // Raised when main view thread is being suspended
         // TODO: Add any addition app initialization
      }
      #endregion

      #region Splash screen operations
         // Delete this method if you do not want an extended splash screen
      private Task ShowSplashScreenAsync(IActivatedEventArgs args, Window currentWindow) {
         // No UI content set: 1st main view activation
         args.SplashScreen.Dismissed += OnSplashScreenDismissed;

         return ExtendedSplashScreen.ShowAsync(args, currentWindow);
      }

      // Delete this method if you dont' to know when the splash screen is dismissed
      private void OnSplashScreenDismissed(SplashScreen ss, Object o) {
         AppAid.Log();
         // NOTE: Invoked via some thread which is NOT a main view or hosted view thread
         // Executed when system transitions from splash screen to 
         // application's first call to Windows.Current.Activate()
      }
      #endregion

      #region Resuming & Suspending
      private void OnResuming(Object sender, Object e) {
         // Invoked via main view thread when it resumes from suspend
         // TODO: Update any stale state in the UI (news, weather, scores, etc.)
         if (Debugger.IsAttached) Debugger.Break();
         AppAid.Log();
      }

      private void OnSuspending(Object sender, SuspendingEventArgs e) {
         AppAid.Beep(10);
         // Invoked via main view thread when app is being suspended or closed by user

         // Windows gives 5 seconds for app to suspend or OS kills the app
         // Windows Store certification requires suspend to complete in 2 seconds
         var timeToSuspend = e.SuspendingOperation.Deadline - DateTimeOffset.Now;
         if (Debugger.IsAttached) Debugger.Break();
         AppAid.Log();

         // TODO: Save user session state in case app is terminated (see ApplicationData.Current.LocalFolder)
         AppAid.CurrentFrame.SerializePageStateAsync(c_FramePageStateFileName).GetAwaiter().GetResult();
      }
      #endregion

      #region Operations common to main view & hosted view
      protected override void OnWindowCreated(WindowCreatedEventArgs args) {
         // Invoked once via the main view thread and once for each hosted view thread
         // NOTE: In here, you do not know the activation kind (Launch, Share, Protocol, etc.)
         switch (args.OnWindowCreated()) {
            case ViewType.Main:
               // TODO: Put any code here that you want to execute for the main view thread/window

               // Ex: Register with the DataTransferManager to test Share Target contract's hosted view
               DataTransferManager.GetForCurrentView().DataRequested += OnDataRequested;
               break;
            case ViewType.Hosted:
               // TODO: Put any code here that you want to execute for a hosted view thread/window
               break;
            case ViewType.Auxiliary:
               // TODO: Put any code here that you want to execute for an auxiliary view thread/window
               break;
         }

         // Optional: register handlers with these events
         Window w = args.Window; // Refers to the view's window (drawing surface)
         w.Activated += Window_Activated;
         w.VisibilityChanged += Window_VisibilityChanged;
      }

      private void OnDataRequested(DataTransferManager sender, DataRequestedEventArgs e) {
         e.Request.Data.Properties.Title = "Process Model";
         e.Request.Data.Properties.Description = "Share with Process Model to see its HostedView";
         e.Request.Data.SetText("Some text");
      }

      private void Window_Activated(Object sender, WindowActivatedEventArgs e) {
         // Invoked via view thread each time its window changes activation state
         CoreWindowActivationState activateState = e.WindowActivationState;
      }

      private void Window_VisibilityChanged(Object sender, VisibilityChangedEventArgs e) {
         // Invoked via view thread each time its window changes visibility
         // A window becomes not-visible whenever the app is suspending or closing
         if (e.Visible) return;
      }
      #endregion

      #region Activation members
      // NotRunning: App install, 1st run after signin (even if user closed app last session), crash, Task Manager kill (TerminateProcess)
      // Terminated: Terminated by system due to low memory, log off/shutdown (Suspend happens first)
      // ClosedByUser: User closed app (Suspend happens first)
      public static ApplicationExecutionState PreviousExecutionState { get; private set; }

      private String GetNavParam(IActivatedEventArgs args) {
         PreviousExecutionState = args.PreviousExecutionState;
         return String.Format("{0}View {1} activation", AppAid.ViewType,
            args.Kind.ToString().PascalCasingToWords());
      }

      protected override async void OnActivated(IActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args)); 
      }

      #region File picker activations
      protected override async void OnFileOpenPickerActivated(FileOpenPickerActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));

         var filename = "CachedFile" + args.FileOpenPickerUI.AllowedFileTypes[0];
         StorageFile sf = await ApplicationData.Current.LocalFolder.CreateFileAsync(filename, CreationCollisionOption.ReplaceExisting);
         await FileIO.WriteTextAsync(sf, "Some sample text");
         CachedFileUpdater.SetUpdateInformation(sf, sf.DisplayName, ReadActivationMode.BeforeAccess,
            WriteActivationMode.NotNeeded, CachedFileOptions.RequireUpdateOnAccess);
         Window.Current.Dispatcher.RunAsync(CoreDispatcherPriority.Low, () => {
            AddFileResult afr = args.FileOpenPickerUI.AddFile(sf.DisplayName, sf);
         }).Forget();
      }

      protected override async void OnFileSavePickerActivated(FileSavePickerActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));
      }
      protected override async void OnCachedFileUpdaterActivated(CachedFileUpdaterActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));
      }
      #endregion

      protected override async void OnFileActivated(FileActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));
      }

      protected override async void OnLaunched(LaunchActivatedEventArgs args) {
         if (Debugger.IsAttached) Debugger.Break();
         Boolean previousStateRestored = await args.ActivateViewAsync();
         switch (args.GetLaunchReason()) {
            case LaunchReason.PrimaryTile:
               if (previousStateRestored) {
                  // Previous state restored back to what is was
                  // before app was terminated; nothing else to do 
               } else {
                  // Previous state not restored; navigate to app's first page
                  this.Navigate(typeof(MyPage), GetNavParam(args));
               }
               break;

            case LaunchReason.SecondaryTile:
               // TODO: Do whatever ...
               this.Navigate(typeof(MyPage), GetNavParam(args));
               break;

            case LaunchReason.Toast:
               // TODO: Do whatever ...
               this.Navigate(typeof(MyPage), GetNavParam(args));
               break;

            case LaunchReason.Proximity:
               // TODO: Do whatever ...
               break;
         }
      }

   #if true
      protected override async void OnSearchActivated(SearchActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));
      }
   #endif
      protected override async void OnShareTargetActivated(ShareTargetActivatedEventArgs args) {
         await args.ActivateViewAsync();
         this.Navigate(typeof(MyPage), GetNavParam(args));
      }
      #endregion

      #region AppState
      private static async void RestoreAppState() {
         const Int32 currentStateVersion = 1;

         ApplicationData appData = ApplicationData.Current;
         UInt32 version = appData.Version; // Default=0
         if (version < currentStateVersion) {
            // If old version, upgrade to new version
            await appData.SetVersionAsync(currentStateVersion, SetVersionHandler);
         }

         // Register for notifications when data changes (explicit or roaming):
         appData.DataChanged += AppDataChanged;
         appData.SignalDataChanged();	// After modifying data, call to raise event
      }

      private static void AppDataChanged(ApplicationData ad, Object o) { }

      private static void SetVersionHandler(SetVersionRequest setVersionRequest) {
         var currentVer = setVersionRequest.CurrentVersion;
         var desiredVer = setVersionRequest.DesiredVersion;
         // Transform existing app data from current to desired version.
         // Throw on failure & system won’t update version number.
         // Update data...
         ApplicationData.Current.SignalDataChanged();
      }
      #endregion
   }
}


namespace ProcessModel.Settings {
   public sealed class UserSettings {
      private readonly AppDataSettingStore<UserSettings> m_store = new AppDataSettingStore<UserSettings>();

      // The Composite property shows how to declare a "HighPriority" & composite setting
      [HighPrioritySetting]
      public Composite Composite {
         get { return m_store.GetComposite<Composite>(); }
         set { m_store.SetComposite(value.m_store); }
      }

      [AppDataSetting(ApplicationDataLocality.Local)]
      public String Name {
         get { return m_store.Get(String.Empty); }
         set { m_store.Set(value); }
      }

      public void RemoveSettings() { m_store.RemoveSettings(); }
   }

   // This class shows how to define a composite value
   public sealed class Composite {
      // Internal because UserSettings' property needs to access it
      internal AppDataCompositeValueSettingStore<Composite> m_store;

      public Composite(AppDataCompositeValueSettingStore<Composite> store) { m_store = store; }

      public String Prop1 {
         get { return m_store.Get("Prop1 Default"); }
         set { m_store.Set(value); }
      }
      public Int32 Prop2 {
         get { return m_store.Get(123); }
         set { m_store.Set(value); }
      }
      public void RemoveSettings() {
         m_store.RemoveSettings();
      }
   }
}