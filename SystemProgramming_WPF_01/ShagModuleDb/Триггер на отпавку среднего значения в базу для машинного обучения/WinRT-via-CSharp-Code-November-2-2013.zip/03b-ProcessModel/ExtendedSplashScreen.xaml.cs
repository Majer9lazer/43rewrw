﻿/******************************************************************************
Module:  ExtendedSplashScreen.Xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Wintellect.WinRT.Packaging;
using SplashScreen = Windows.ApplicationModel.Activation.SplashScreen;

namespace ProcessModel {
   public sealed partial class ExtendedSplashScreen : UserControl {
      private readonly TaskCompletionSource<Boolean> m_tcs;

      public static Task ShowAsync(IActivatedEventArgs args, Window window) {
         var tcs = new TaskCompletionSource<Boolean>();
         window.Content = new ExtendedSplashScreen(tcs, args);
         window.Activate();
         return tcs.Task;
      }

      public ExtendedSplashScreen(TaskCompletionSource<Boolean> tcs, IActivatedEventArgs args) {
         m_tcs = tcs;
         this.InitializeComponent();
         SplashScreen splashScreen = args.SplashScreen;
         PositionSplashImage(splashScreen);
         Window.Current.SizeChanged += (s, e) => PositionSplashImage(splashScreen);
         this.Loaded += OnLoaded;
      }

      private void PositionSplashImage(SplashScreen splashScreen) {
         // Position the extended splash screen image in the same location as the splash screen image.
         Rect loc = splashScreen.ImageLocation;
         m_imgSplash.SetValue(Canvas.LeftProperty, loc.X);
         m_imgSplash.SetValue(Canvas.TopProperty, loc.Y);
         m_imgSplash.Height = loc.Height;
         m_imgSplash.Width = loc.Width;
      }

      private static async Task<Color> GetSplashScreenBackgroundColor() {
         var pm = await PackageManifest.LoadAsync();
         return pm.Applications.First().VisualElements.BackgroundColor;
      }

      private async void OnLoaded(Object sender, RoutedEventArgs e) {
         // Make extended splash screen's background match the color set in the app's manifest
         m_root.Background = new SolidColorBrush(await GetSplashScreenBackgroundColor());

         // Perform extended initialization here
         for (Int32 seconds = 3; seconds > 0; seconds--) {
            m_txtInitializing.Text = String.Format("Initializing ({0} seconds remaining)...", seconds);
            await Task.Delay(1000);
         }
         // After initializing, report that extended splash screen is done
         m_tcs.SetResult(true);
      }
   }
}
