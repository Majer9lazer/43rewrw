﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/
using System;
using Windows.ApplicationModel.Activation;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Wintellect.WinRT.AppAids;

namespace DataSharing {
   sealed partial class App : Application {
      // Invoked because DISABLE_XAML_GENERATED_MAIN is defined:
      public static void Main(String[] args) {
         AppAid.Start(p => new App());
      }

      public App() {
         this.InitializeComponent();
      }

      protected override void OnLaunched(LaunchActivatedEventArgs e) {
         Frame rootFrame = Window.Current.Content as Frame;

         // Do not repeat app initialization when the Window already has content,
         // just ensure that the window is active
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (e.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When the navigation stack isn't restored navigate to the first page,
            // configuring the new page by passing required information as a navigation
            // parameter
            if (!rootFrame.Navigate(typeof(SharingAppPage), e.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure the current window is active
         Window.Current.Activate();
      }

      protected override void OnShareTargetActivated(ShareTargetActivatedEventArgs e) {
         var shareTargetPage = new DataSharing.ShareTargetPage();
         shareTargetPage.Activate(e);
      }

      protected override async void OnActivated(IActivatedEventArgs args) {
         if (args.Kind == ActivationKind.Protocol) {
            ProtocolActivatedEventArgs paea = (ProtocolActivatedEventArgs)args;
            await new MessageDialog(paea.Uri.ToString(), "Protocol activation").ShowAsync();
         }
         base.OnActivated(args);
      }
   }
}
