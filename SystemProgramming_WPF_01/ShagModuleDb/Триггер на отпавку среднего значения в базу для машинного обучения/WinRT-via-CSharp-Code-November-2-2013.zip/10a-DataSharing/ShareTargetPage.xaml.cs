﻿using DataSharing.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer.ShareTarget;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace DataSharing {
   public sealed partial class ShareTargetPage : Page {
      private ShareOperation m_shareOperation;
      private readonly ObservableDictionary m_viewModel = new ObservableDictionary();

      public ObservableDictionary ViewModel { get { return m_viewModel; } }

      public ShareTargetPage() {
         this.InitializeComponent();
      }

      public async void Activate(ShareTargetActivatedEventArgs e) {
         // Activate our window 1st so Windows won't terminate our process
         // Still, time-consuming operations should not be done during activation
         Window.Current.Content = this;
         Window.Current.Activate();

         // Save the ShareOperation object so we can use it while performing the share operation
         m_shareOperation = e.ShareOperation;

         // Populate the hosted view page with properties so user knows what is being shared
         var shareProperties = m_shareOperation.Data.Properties;

         // If a thumbnail image is available, show it
         if (shareProperties.Thumbnail == null) {
            m_viewModel["ShowImage"] = false;
         } else {
            m_viewModel["ShowImage"] = true;
            BitmapImage thumbnailImage = new BitmapImage();
            IRandomAccessStream stream = await shareProperties.Thumbnail.OpenReadAsync();
            await thumbnailImage.SetSourceAsync(stream);
            m_viewModel["Image"] = thumbnailImage;
         }

         // Show some other DataPackage properties in the hostted view page
         m_viewModel["Title"] = "Title=" + shareProperties.Title;
         m_viewModel["Description"] = "Description=" + shareProperties.Description;

         // Here I show the formats in the DataPackage
         String dataFormats = String.Empty;
         foreach (String dataFormat in m_shareOperation.Data.AvailableFormats) {
            dataFormats += ((dataFormats.Length > 0) ? ", " : String.Empty) + dataFormat;
         }
         m_viewModel["DataFormats"] = "Formats=" + dataFormats;

         // If shared activated via QuickLink, use ID to set share "destination"
         if (m_shareOperation.QuickLinkId == String.Empty)
            m_viewModel["QuickLink"] = "QuickLinkId=(none)";
         else {
            m_viewModel["Placeholder"] = "QuickLinkId=" + m_shareOperation.QuickLinkId;

            // DEMO: This removes the QuickLink from the Share charm
            m_shareOperation.RemoveThisQuickLink();
         }

         // Show the status of the share operation; updated in ShareButton_Click
         m_viewModel["Status"] = "Status: Share not started";
      }

      private async void ShareButton_Click(object sender, RoutedEventArgs e) {
         // Don't suspend source app, add target app to progress list
         m_shareOperation.ReportStarted();

         // Hide hosted view so user can work with share source app right away
         m_shareOperation.DismissUI();

         // TODO: get everything needed from the DataPackageView here...
         for (Int32 second = 0; second < 10; second++) {
            m_viewModel["Status"] = "Status: Started - " + second;
            await Task.Delay(TimeSpan.FromSeconds(1));
         }

         // Target app no longer needs source app running; OS can suspend/terminate it
         m_shareOperation.ReportDataRetrieved();

         // TODO: Continue processing (sharing) the data here...
         for (Int32 second = 0; second < 10; second++) {
            m_viewModel["Status"] = "Status: Data retrieved - " + second;
            await Task.Delay(TimeSpan.FromSeconds(1));
         }

         // Share is done, report error or success (possibly with QuickLink)
         if (m_chkSimulateFailure.IsChecked.Value) {
            m_shareOperation.ReportError("Share failed.");
         } else {
            if (!m_chkCreateQuickLink.IsChecked.Value) {
               m_shareOperation.ReportCompleted();
            } else {
               QuickLink ql = new QuickLink {
                  // Set mandatory properties:
                  Title = "QuickLink title",
                  Id = "QuickLink created on " + DateTimeOffset.Now,
                  Thumbnail = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/Logo.png")),

                  // At least 1 of these properties: 
                  SupportedDataFormats = { "Text" },
                  SupportedFileTypes = { ".txt" }
               };
               m_shareOperation.ReportCompleted(ql);
            }
         }
      }
   }
}
