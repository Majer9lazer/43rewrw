﻿/******************************************************************************
Module:  SharingAppPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/
using System;
using System.Linq;
using System.Text;
using Transhipment;
using Windows.ApplicationModel;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Wintellect.WinRT.AppAids;

namespace DataSharing {
   public sealed partial class SharingAppPage : Page {
      public SharingAppPage() {
         this.InitializeComponent();
         Clipboard.ContentChanged += Clipboard_ContentChanged;
         Clipboard_ContentChanged(null, null);
      }

      private async void Clipboard_ContentChanged(object sender, object e) {
         DataPackageView dpv = Clipboard.GetContent();
         StringBuilder sb = new StringBuilder();
         sb.AppendLine("Clipboard contents last changed at: " + DateTimeOffset.Now);
         sb.AppendLine();
         if (dpv.Properties.Thumbnail != null) {
            var image = new Windows.UI.Xaml.Media.Imaging.BitmapImage();
            image.SetSource(await dpv.Properties.Thumbnail.OpenReadAsync());
            m_img.Source = image;
            m_img.Visibility = Visibility.Visible;
         } else {
            m_img.Visibility = Visibility.Collapsed;
         }
         sb.AppendLine("Properties:");
         foreach (var key in dpv.Properties.Keys) {
            String value = (key != "FileTypes") ? dpv.Properties[key].ToString() : String.Join(", ", dpv.Properties.FileTypes);
            sb.AppendFormat("   {0}: {1}", key, value);
            sb.AppendLine();
         }
         sb.AppendLine();

         sb.AppendLine("Data formats:");
         foreach (var format in dpv.AvailableFormats) {
            sb.AppendFormat("   {0}", format);
            sb.AppendLine();
         }
         m_txtClipboardContents.Text = sb.ToString();
      }
      protected override void OnNavigatedTo(NavigationEventArgs e) {
         DataTransferManager dtm = DataTransferManager.GetForCurrentView();
         dtm.DataRequested += OnDataRequested;
         base.OnNavigatedTo(e);
      }
      protected override void OnNavigatingFrom(NavigatingCancelEventArgs e) {
         DataTransferManager dtm = DataTransferManager.GetForCurrentView();
         dtm.DataRequested -= OnDataRequested;
         base.OnNavigatingFrom(e);
      }

      private void OnDataRequested(DataTransferManager dtm, DataRequestedEventArgs e) {
         AppAid.Log();  // Code executes via GUI thread
         if (!m_chkAppHasSharableContent.IsChecked.Value) { // Replace this with your own logic
            // Windows will show this string in the share pane. 
            e.Request.FailWithDisplayText("Select something to share.");
            return;
         }
         PopulateDataPackage(e.Request.Data);
      }

      private DataPackage PopulateDataPackage(DataPackage dp, DataPackageOperation operation = DataPackageOperation.None) {
         // 1. Set some DataPackage properties:
         dp.RequestedOperation = operation;
         dp.Properties.ApplicationName = Package.Current.DisplayName;
         dp.Properties.Title = "DataPackage Title";
         dp.Properties.Description = "DataPackage Description";
         RandomAccessStreamReference image =
            RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/Planets.png"));
         dp.Properties.Thumbnail = image;

         // Optional: Add a URI a target app can use to get back to the content in the source app
         // Requires the source app declare a "datasharingdemo" protocol activation in the manifest
         Uri sourceAppContentUri = new Uri("datasharingdemo:Shared at " + DateTimeOffset.Now);
         dp.Properties.ContentSourceApplicationLink = sourceAppContentUri;

         // Optional: Add a URI a target app can use to get back to the content on the web
         Uri webContentUri = new Uri("http://WintellectNOW.com/");
         dp.Properties.ContentSourceWebLink = webContentUri;

         // 2. Add desired data formats to the DataPackage:
         // Target apps supporting "ApplicationLink" and "UniformResourceLocatorW" formats can
         // also get URIs to protocol activate the source app or access the content on the Web
         dp.SetApplicationLink(sourceAppContentUri);
         dp.SetWebLink(webContentUri);
         dp.SetText("Some text");
         dp.SetBitmap(image);

         // Demonstrates how to delay-render a format
         dp.Properties.FileTypes.Add(".png");
         dp.SetDataProvider(StandardDataFormats.StorageItems, DataProviderHandler);
         // Without delay-rendering: dp.SetStorageItems(new[] { storageFile });

         // Demonstrates using a custom http://Schema.org format via the Transhipment NuGet package
         // (Install-Package Transhipment). See https://github.com/AndreiMarukovich/Transhipment
         IBook book = (IBook)SchemaFactory.Create(Schema.Book);
         book.BookEdition = 4.ToString();
         book.BookFormat = BookFormatType.EBook;
         book.ISBN = "9780735667457";
         book.NumberOfPages = 900;
         dp.SetStructuredData(book);
         // Call SchemaFactory.GetStructuredDataAsync(this DataPackageView dataPackage, String formatId) to get a custom format
         // Example: IBook book = (IBook)await dp.GetView().GetStructuredDataAsync(Schema.Book);

         // 3. Optional: Register event handlers
         dp.OperationCompleted += OnShareCompleted;
         dp.Destroyed += OnDataPackageDestroyed;
         return dp;
      }

      private async void DataProviderHandler(DataProviderRequest request) {
         AppAid.Log();  // Code executes via GUI or thread pool thread
         DataProviderDeferral d = request.GetDeferral();
         try {
            switch (request.FormatId) {
               case "Text":
                  String data = "Perform time consuming or memory intensive task to acquire text data";
                  request.SetData(data);
                  break;
               case "Shell IDList Array":
                  request.SetData(new[] { 
                     await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///Assets/Planets.png"))
                  });
                  break;
            }
         }
         finally {
            d.Complete();
         }
      }
      private async void OnShareCompleted(DataPackage dp, OperationCompletedEventArgs args) {
         AppAid.Log();  // Called via GUI thread
         switch (args.Operation) {
            case DataPackageOperation.None:
               break;
            case DataPackageOperation.Copy:
               break;
            case DataPackageOperation.Move:
               break;
            case DataPackageOperation.Link:
               break;
         }
         await new MessageDialog(String.Format("Share completed due to {0}", args.Operation)).ShowAsync();
      }

      private void OnDataPackageDestroyed(DataPackage dp, Object o) {
         // Called when DataPackage object gets GC'd
         AppAid.Log();  // Code executes via GUI or thread pool thread
      }

      private void OnCut(object sender, RoutedEventArgs e) {
         Clipboard.SetContent(PopulateDataPackage(new DataPackage(), DataPackageOperation.Move));
      }

      private void OnCopy(object sender, RoutedEventArgs e) {
         Clipboard.SetContent(PopulateDataPackage(new DataPackage(), DataPackageOperation.Copy));
      }

      private static readonly String[] s_targetAppSupportedFormats = new[] { 
         StandardDataFormats.Html,
         StandardDataFormats.Rtf,
         StandardDataFormats.Text
      };

      private async void OnPaste(object sender, RoutedEventArgs e) {
         AppAid.Log();
         DataPackageView dpv = Clipboard.GetContent();

         // Grab the format the source app says has highest fidelity that that target app supports
         String highestFidelityFormat = dpv.AvailableFormats.FirstOrDefault(af => s_targetAppSupportedFormats.Contains(af));
         String msg = null;
         if (highestFidelityFormat == null) {
            msg = "Clipboard doesn't contain any formats supported by target app.";
         } else {
            Object data = await dpv.GetDataAsync(highestFidelityFormat);
            msg = "Pasting: " + data;
         }

         // Do real paste operation here (this demo displays a MessageDialog)...
         MessageDialog md = new MessageDialog(msg,
            String.Format("Pasting content from AppName={0}, Title={1}, Description={2}",
               dpv.Properties.ApplicationName, dpv.Properties.Title, dpv.Properties.Description));
         await md.ShowAsync();
         dpv.ReportOperationCompleted(dpv.RequestedOperation);
      }

      private void OnShare(object sender, RoutedEventArgs e) {
         DataTransferManager.ShowShareUI();
      }
   }
}
