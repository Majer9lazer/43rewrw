﻿/******************************************************************************
Module:  WindowsStoreProxy.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

#if !StoreSubmission

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel.Store;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Streams;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.WindowsStore.Simulator;

namespace Wintellect.WindowsStore.Simulator {
   internal static class WindowsStoreSimulator {
      private static StorageFile s_proxyFile;
      private static XDocument s_proxyXml;

      public static async Task ReloadSimulatorAsync(XDocument xml, Boolean reset) {
         Boolean firstTime = s_proxyFile == null;
         if (firstTime) {
            // First time method is called, get/create the XML file the simulator needs
            const String filename = "WindowsStoreProxy.xml";
            StorageFolder folder = await WindowsStoreProxyHelper.GetProxyFolderAsync();
            s_proxyFile = (StorageFile)await folder.TryGetItemAsync(filename);
            if (s_proxyFile == null) {
               s_proxyFile = await folder.CreateFileAsync(filename, CreationCollisionOption.ReplaceExisting);
               reset = true;
            }
         }
         if (reset) {
            // Create XML document and save it to the file
            s_proxyXml = xml;
            await PersistProxyXmlAsync(false);
         } else {
            // Load existing XML document
            s_proxyXml = XDocument.Parse(await FileIO.ReadTextAsync(s_proxyFile, UnicodeEncoding.Utf16BE));
         }
         await CurrentAppSimulator.ReloadSimulatorAsync(s_proxyFile);
         if (firstTime) CurrentAppSimulator.LicenseInformation.LicenseChanged += OnLicenseChanged;
      }

      private static IAsyncAction PersistProxyXmlAsync(Boolean update) {
         if (update) s_proxyXml = CurrentAppSimulator.LicenseInformation.UpdateProxyXml(s_proxyXml);
         return FileIO.WriteTextAsync(s_proxyFile, s_proxyXml.ToString(), UnicodeEncoding.Utf16BE);
      }

      private static void OnLicenseChanged() {
         PersistProxyXmlAsync(true).Forget();
      }

      public static IEnumerable<String> Markets {
         get {
            // Get market languages from proxy XML file:
            return s_proxyXml.Element("CurrentApp").Element("ListingInformation").Element("App")
               .Elements("MarketData").Select(me => me.Attribute(MarketSpecificData.LangNamespace + "lang").Value);
         }
      }
   }
}
#endif
