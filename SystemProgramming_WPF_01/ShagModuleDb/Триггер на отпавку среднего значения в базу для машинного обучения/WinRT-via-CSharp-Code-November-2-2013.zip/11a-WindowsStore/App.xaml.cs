﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.Store;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.WindowsStore.Simulator;

namespace WindowsStoreDemo {
   sealed partial class App : Application {
      // Invoked because DISABLE_XAML_GENERATED_MAIN is defined:
      public static void Main(String[] args) { AppAid.Start(p => new App()); }

      public App() { AppAid.Log(); this.InitializeComponent(); }

      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         // Do not repeat app initialization when already running, just ensure that
         // the window is active
         if (args.PreviousExecutionState == ApplicationExecutionState.Running) {
            Window.Current.Activate();
            return;
         }

         if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
            //TODO: Load state from previously suspended application
         }

         // Create a Frame to act navigation context and navigate to the first page
         var rootFrame = new Frame();
         if (!rootFrame.Navigate(typeof(WindowsStorePage))) {
            throw new Exception("Failed to create initial page");
         }

         // Place the frame in the current Window and ensure that it is active
         Window.Current.Content = rootFrame;
         Window.Current.Activate();
      }
   }
}
