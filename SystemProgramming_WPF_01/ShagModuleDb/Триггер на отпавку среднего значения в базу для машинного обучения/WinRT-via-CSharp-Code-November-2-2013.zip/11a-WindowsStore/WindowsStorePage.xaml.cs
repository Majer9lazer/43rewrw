﻿/******************************************************************************
Module:  WindowsStorePage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

//#define StoreSubmission

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Store;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using Wintellect.WinRT.AppAids;

#if StoreSubmission  // In VS, create a "Windows Store" project configuration that defines this symbol
using CurrentApp = Windows.ApplicationModel.Store.CurrentApp;
#else
using CurrentApp = Windows.ApplicationModel.Store.CurrentAppSimulator;
using Wintellect.WinRT.WindowsStore.Simulator;
using Wintellect.WindowsStore.Simulator;
#endif

namespace WindowsStoreDemo {
   public sealed partial class WindowsStorePage : Page {
      private const Int32 E_FAIL = unchecked((Int32)0x80004005);
      private const Int32 ERROR_NETWORK_UNREACHABLE = unchecked((Int32)0x800704CF);
      private ListingInformation m_listingInformation;
      private LicenseInformation m_licenseInfo;
      public WindowsStorePage() {
         this.InitializeComponent();
      }

      private struct ProductIds {
         public const String DurableProduct = "DurableProduct";
         public const String DurableExpiringProduct = "DurableExpiringProduct";
         public const String ConsumableProduct = "ConsumableProduct";
         public const String ConsumableProductOffer = "ConsumableProductOffer";
      }
      private Int32 m_ConsumableProductTimesBought = 0;
      private struct OfferIds {
         public const String A = "Offer-A";
         public const String B = "Offer-B";
      }

      private readonly Dictionary<String, Int32> m_ConsumableProductOffers =
         new Dictionary<String, Int32> { 
         { OfferIds.A, 0 }, 
         { OfferIds.B, 0 } 
      };

      protected override async void OnNavigatedTo(NavigationEventArgs e) {
         var b = CurrentApp.LicenseInformation.IsActive; // False if not side-loaded or debugging
         m_licenseInfo = CurrentApp.LicenseInformation;
         await ReloadStoreSimulatorAsync(false);
         m_licenseInfo.LicenseChanged += UpdateListingAndLicenseInfo;
      }

      private void UpdateListingAndLicenseInfo() {
         if (this.DispatchToGui(() => UpdateListingAndLicenseInfo())) return;

         #region Listing info
         // Initialize App listing information
         m_txtAppName.Text = m_listingInformation.Name;
         m_btnAppPurchase.Content = "Purchase for " + m_listingInformation.FormattedPrice;

         // Initialize durable product listing information
         ProductListing listing = m_listingInformation.ProductListings[ProductIds.DurableProduct.ToString()];
         m_txtDurableProductName.Text = listing.Name;
         m_btnDurableProductPurchase.Content = "Purchase for " + listing.FormattedPrice;

         // Initialize durable expiring product listing information
         listing = m_listingInformation.ProductListings[ProductIds.DurableExpiringProduct.ToString()];
         m_txtDurableExpiringProductName.Text = listing.Name;
         m_btnDurableExpiringProductPurchase.Content = "Purchase for " + listing.FormattedPrice;

         // Initialize consumable product listing information
         listing = m_listingInformation.ProductListings[ProductIds.ConsumableProduct.ToString()];
         m_txtConsumableProductName.Text = listing.Name;
         m_btnConsumableProductPurchase.Content = "Purchase for " + listing.FormattedPrice;

         // Initialize consumable product offer listing information
         listing = m_listingInformation.ProductListings[ProductIds.ConsumableProductOffer];
         m_txtConsumableProductOfferAName.Text = listing.Name + ": " + OfferIds.A;
         m_btnConsumableProductOfferAPurchase.Content = "Purchase for " + listing.FormattedPrice;
         m_txtConsumableProductOfferBName.Text = listing.Name + ": " + OfferIds.B;
         m_btnConsumableProductOfferBPurchase.Content = "Purchase for " + listing.FormattedPrice;
         #endregion

         #region License Info
         var licenseInfo = CurrentApp.LicenseInformation;

         // Update App licensing
         m_txtAppLicense.Text = !licenseInfo.IsActive ? "Not active" : (licenseInfo.IsTrial ? "Active trial" : "Active & licensed");
         m_txtAppExpiration.Text = licenseInfo.IsTrial ? licenseInfo.ExpirationDate.ToString("g") : String.Empty;

         // Update durable product licensing
         ProductLicense license = licenseInfo.ProductLicenses[ProductIds.DurableProduct.ToString()];
         m_txtDurableProductLicense.Text = license.IsActive ? "Licensed" : "Not licensed";
         m_txtDurableProductExpiration.Text = license.IsActive ? license.ExpirationDate.ToString("g") : String.Empty;

         // Update durable expiring product licensing
         license = licenseInfo.ProductLicenses[ProductIds.DurableExpiringProduct.ToString()];
         m_txtDurableExpiringProductLicense.Text = license.IsActive ? "Licensed" : "Not licensed";
         m_txtDurableExpiringProductExpiration.Text = license.IsActive ? license.ExpirationDate.ToString("g") : String.Empty;

         // Update consumable product purchases
         m_txtConsumableProductTimesBought.Text = m_ConsumableProductTimesBought.ToString();

         // Update consumable product offer purchases
         m_txtConsumableProductOfferATimesBought.Text = m_ConsumableProductOffers[OfferIds.A].ToString();
         m_txtConsumableProductOfferBTimesBought.Text = m_ConsumableProductOffers[OfferIds.B].ToString();
         #endregion
      }

      private async void OnReloadStoreSimulator(object sender, RoutedEventArgs e) {
         await ReloadStoreSimulatorAsync(false);
      }
      private async void OnResetStoreSimulator(object sender, RoutedEventArgs e) {
         await ReloadStoreSimulatorAsync(true);
      }
      private async Task ReloadStoreSimulatorAsync(Boolean reset) {
         await WindowsStoreSimulator.ReloadSimulatorAsync(CreateWindowsStoreProxyXml(), reset);
         try {
            m_listingInformation = await CurrentApp.LoadListingInformationAsync();
            UpdateListingAndLicenseInfo();
         }
         catch (Exception ex) {
            var m = ex.Message;
         }
      }
      private async void OnAppPurchase(object sender, RoutedEventArgs e) {
         String msg;
         if (!m_licenseInfo.IsTrial) {
            msg = "App already licensed";
         } else {
            try {
               // Prompt the user to purchase a license for the app
               String receipt = await CurrentApp.RequestAppPurchaseAsync(true);
               msg = m_licenseInfo.IsActive ? "App license purchased" : "App license purchase canceled";
            }
            catch (ArgumentException ex) { msg = ex.Message; }
            catch (OutOfMemoryException ex) { msg = ex.Message; }
            catch (COMException ex) {
               if (ex.HResult != E_FAIL) throw;
               msg = ex.Message;
            }
            catch (Exception ex) {
               if (ex.HResult != ERROR_NETWORK_UNREACHABLE) throw;
               msg = ex.Message;
            }
         }
         await new MessageDialog(msg).ShowAsync();
      }

      private async void OnDurableProductPurchase(object sender, RoutedEventArgs e) {
         String msg;
         if (!m_licenseInfo.IsActive || m_licenseInfo.IsTrial) {
            msg = "Can't license product until app is licensed";
         } else {
            String productId = (sender == m_btnDurableProductPurchase ? ProductIds.DurableProduct : ProductIds.DurableExpiringProduct);
            ProductLicense pl = m_licenseInfo.ProductLicenses[productId];
            if (pl.IsActive) {
               msg = "Product already licensed";
            } else {
               try {
                  // Prompt the user to purchase a license for the durable in-app product
                  PurchaseResults purchaseResult = await CurrentApp.RequestProductPurchaseAsync(pl.ProductId);
                  msg = "Product purchase status: " + purchaseResult.Status;
               }
               catch (ArgumentException ex) { msg = ex.Message; }
               catch (OutOfMemoryException ex) { msg = ex.Message; }
               catch (COMException ex) { if (ex.HResult != E_FAIL) throw; msg = ex.Message; }
               catch (Exception ex) {
                  if (ex.HResult != ERROR_NETWORK_UNREACHABLE) throw;
                  msg = ex.Message;
               }
            }
         }
         await new MessageDialog(msg).ShowAsync();
      }
      private async void OnConsumableProductPurchase(object sender, RoutedEventArgs e) {
         // When the user purchases a consumable product, IsActive remains false and the LicenseChanged event is not raised
         String msg = String.Empty;
         if (!m_licenseInfo.IsActive || m_licenseInfo.IsTrial) {
            msg = "Can't license product until app is licensed";
         } else {
            String productId = ProductIds.ConsumableProduct;
            try {
               // Prompt the user to purchase a consumable in-app product
               PurchaseResults purchaseResult = await CurrentApp.RequestProductPurchaseAsync(productId);
               switch (purchaseResult.Status) {
                  case ProductPurchaseStatus.Succeeded:
                     // Consumable in-app product purchased
                     // Since app hasn't fulfilled the consumable, Store won't let user buy more

                     // TODO: Integrate product into app (This example increments purchase count)
                     m_ConsumableProductTimesBought += 1;

                     // Tell the Store the app fulfilled the consumable
                     FulfillmentResult fulfillmentResult =
                        await CurrentApp.ReportConsumableFulfillmentAsync(productId, purchaseResult.TransactionId);
                     switch (fulfillmentResult) {
                        // For these cases, assume user purchased our product successfully
                        case FulfillmentResult.Succeeded:
                           msg = "Consumable product purchased. You can purchase it again";
                           break;
                        case FulfillmentResult.ServerError:
                           msg = "There was a problem receiving getting fulfilment status from the server";
                           break;

                        // For these cases, assume purchase failed (undo product integration) 
                        case FulfillmentResult.NothingToFulfill:
                        case FulfillmentResult.PurchasePending:
                        case FulfillmentResult.PurchaseReverted:
                           msg = "There was a problem fulfilling the purchase: " + fulfillmentResult;
                           m_ConsumableProductTimesBought -= 1;
                           break;
                     }
                     break;
                  case ProductPurchaseStatus.NotPurchased:
                  case ProductPurchaseStatus.NotFulfilled:
                  case ProductPurchaseStatus.AlreadyPurchased:
                     // Notify user that the purchase failed
                     msg = "Failed to purchase consumable product: " + purchaseResult.Status;
                     break;
               }
            }
            catch (ArgumentException ex) { msg = ex.Message; }
            catch (OutOfMemoryException ex) { msg = ex.Message; }
            catch (COMException ex) { if (ex.HResult != E_FAIL) throw; msg = ex.Message; }
            catch (Exception ex) {
               if (ex.HResult != ERROR_NETWORK_UNREACHABLE) throw;
               msg = ex.Message;
            }
         }
         UpdateListingAndLicenseInfo(); // To update the Total coins cell
         await new MessageDialog(msg).ShowAsync();
      }

      private async void OnConsumableProductOfferPurchase(object sender, RoutedEventArgs e) {
         // Product offers MUST be consumables (not Durables).
         // When the user purchses a consumable product, IsActive remains false and the LicenseChanged event is not raised
         String msg = String.Empty;
         if (!m_licenseInfo.IsActive || m_licenseInfo.IsTrial) {
            msg = "Can't license product until app is licensed";
         } else {
            String productId = ProductIds.ConsumableProductOffer;
            String offerId = (sender == m_btnConsumableProductOfferAPurchase ? OfferIds.A : OfferIds.B);
            ProductPurchaseDisplayProperties ppdp = new ProductPurchaseDisplayProperties(productId) {
               Description = "Queen's Bohemian Rhapsody",
               Image = new Uri("http://upload.wikimedia.org/wikipedia/en/9/9f/Bohemian_Rhapsody.png")
            };

            try {
               // Prompt the user to purchase a the consumable in-app product offer
               PurchaseResults purchaseResult = await CurrentApp.RequestProductPurchaseAsync(productId, offerId, ppdp);
               switch (purchaseResult.Status) {
                  case ProductPurchaseStatus.Succeeded:
                     var ss = await CurrentApp.GetUnfulfilledConsumablesAsync();
                     // Product offer purchased. 
                     // Since app hasn't fulfilled the consumable, Store won't let user buy more

                     // The product offer was purchased; execute code to integrate product offer into your app
                     m_ConsumableProductOffers[offerId] += 1; // Offer bought 1 more time

                     // Now, tell the Store that the app has fulfilled the consumable
                     FulfillmentResult fulfillmentResult =
                        await CurrentApp.ReportConsumableFulfillmentAsync(productId, purchaseResult.TransactionId);
                     switch (fulfillmentResult) {
                        // For these 2 cases, we'll assume the user purchased our product successfully
                        case FulfillmentResult.Succeeded:
                           msg = "Consumable product offer purchased. You can purchase it again";
                           break;
                        case FulfillmentResult.ServerError:
                           msg = "There was a problem receiving getting fulfilment status from the server";
                           break;

                        // For these 3 cases, the purchase failed so we'll subtract the coins from the user's total
                        case FulfillmentResult.NothingToFulfill:
                        // Item already fulfilled or bad ProductId or TransactionId...
                        case FulfillmentResult.PurchasePending:
                        // Purchase not yet completed (it could be reversed to to provider failure)...
                        case FulfillmentResult.PurchaseReverted:
                           // The product offer was reverted; execute code to remove product offer from your app
                           msg = "There was a problem fulfilling the purchase: " + fulfillmentResult;
                           m_ConsumableProductOffers[offerId] -= 1; // Reset since the offer purchase failed
                           break;
                     }
                     break;
                  case ProductPurchaseStatus.NotPurchased:
                  case ProductPurchaseStatus.NotFulfilled:
                  case ProductPurchaseStatus.AlreadyPurchased:
                     // Notify user that the purchase failed
                     msg = "Failed to purchase consumable product offer: " + purchaseResult.Status;
                     break;
               }
            }
            catch (ArgumentException ex) { msg = ex.Message; }
            catch (OutOfMemoryException ex) { msg = ex.Message; }
            catch (COMException ex) { if (ex.HResult != E_FAIL) throw; msg = ex.Message; }
         }
         UpdateListingAndLicenseInfo();
         await new MessageDialog(msg).ShowAsync();
      }

      private static XDocument CreateWindowsStoreProxyXml() {
         return new CurrentAppDefinition {
            ListingInformation = new ListingDefinition {
               App = new AppListingDefinition {
                  AppId = Guid.Empty,
                  LinkUri = new Uri("http://apps.microsoft.com/webpdp/app/00000000-0000-0000-0000-000000000000"),
                  AgeRating = 3,
                  CurrentMarket = "en-us",
                  MarketData = new MarketSpecificAppData("en-us", Package.Current.DisplayName, Package.Current.Description, 1.99, "$", "USD")
               },
               Products = new[] {
                  new ProductListingDefinition { 
                     ProductId = ProductIds.DurableProduct, ProductType = ProductType.Durable, MarketData = new [] {
                        new MarketSpecificProductData("en-us", "Durable product", null, 2.99, "$", "USD")
                     }
                  },
                  new ProductListingDefinition { 
                     ProductId = ProductIds.DurableExpiringProduct,  LicenseDuration = 1, ProductType = ProductType.Durable, MarketData = new [] {
                        new MarketSpecificProductData("en-us", "Durable expiring product", null, 3.99, "$", "USD")
                     }
                  },
                  new ProductListingDefinition { 
                     ProductId = ProductIds.ConsumableProduct, ProductType = ProductType.Consumable, MarketData = new [] {
                        new MarketSpecificProductData("en-us", "Consumable product", null, 4.99, "$", "USD")
                     }
                  },
                  new ProductListingDefinition { 
                     ProductId = ProductIds.ConsumableProductOffer, ProductType = ProductType.Consumable, MarketData = new [] {
                        new MarketSpecificProductData("en-us", "Consumable product offer", null, 5.99, "$", "USD")
                     }
                  },                  
               }
            },
            LicenseInformation = new LicenseDefinition {
               App = new AppLicenseDefinition { IsActive = false, IsTrial = true, ExpirationDate = DateTimeOffset.UtcNow.AddDays(3) },
               Products = new[] {
                  new ProductLicenseDefinition { IsActive = false, ProductId = "DurableProduct" },
                  new ProductLicenseDefinition { IsActive = false, ProductId = "ExpiringDurableProduct", ExpirationDate = DateTimeOffset.UtcNow.AddDays(2) },
                  new ProductLicenseDefinition { IsActive = false, ProductId = "ConsumableProduct" },
               }
            },
            ConsumableInformation = new ConsumableProductDefinition[] { 
               new ConsumableProductDefinition { ProductId = "ConsumableProduct", TransactionId = Guid.NewGuid(), Status = ConsumableStatus.Active }
            },
#if false
            Simulation = new SimulationDefinition {
               SimulationMode = SimulationMode.Automatic, DefaultResponses = new[] { 
                 new DefaultResponseDefinition { MethodName = StoreMethodName.RequestAppPurchaseAsync_GetResult, HResult = ReponseCodes.S_OK},
               },
            }
#endif
         }.ToXml();
      }
   }
}
