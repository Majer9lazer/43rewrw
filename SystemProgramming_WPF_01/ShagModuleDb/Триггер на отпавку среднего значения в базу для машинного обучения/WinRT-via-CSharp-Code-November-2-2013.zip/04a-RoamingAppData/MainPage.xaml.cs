﻿/******************************************************************************
Module:  MainPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Networking.Proximity;
using Windows.Storage;
using Windows.System;
using Windows.System.Profile;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.Settings;

namespace RoamingAppData {
   public sealed partial class MainPage : Page {
      private readonly String m_machineName = PeerFinder.DisplayName;
      public MainPage() {
         this.InitializeComponent();
         ApplicationData.Current.DataChanged += OnDataChanged;
      }

      protected override void OnNavigatedTo(NavigationEventArgs e) {
         m_txtMachineName.Text = m_machineName;
         ShowValues(WhatToShow.Both);
      }

      private void OnDataChanged(ApplicationData appData, Object e) {
         Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () => ShowValues(WhatToShow.All)).Forget();
      }
      private void OnSignalDataChange(object sender, RoutedEventArgs e) {
         ApplicationData.Current.SignalDataChanged();
      }

      enum WhatToShow { Normal = 1, High = 2, Both = 3, DataChanged = 4, All = Both | DataChanged }
      private void ShowValues(WhatToShow whatToShow) {
         if (whatToShow.HasFlag(WhatToShow.DataChanged)) {
            m_txtDataChangedTime.Text = DateTimeOffset.Now.ToString();
         }
         if ((whatToShow & WhatToShow.Normal) != 0)
            m_txtNormalPrioritySettingValue.Text = String.Format("Set at {0:T} by {1}",
               m_settings.NormalPrioritySetting.TimeSet,
               m_settings.NormalPrioritySetting.Machine);

         if ((whatToShow & WhatToShow.High) != 0)
            m_txtHighPrioritySettingValue.Text = String.Format("Set at {0:T} by {1}",
               m_settings.HighPrioritySetting.TimeSet,
               m_settings.HighPrioritySetting.Machine);
      }

      public sealed class Settings : INotifyPropertyChanged {
         // If the type has no composite values, use ISettingStore instead of IAppDataSettingStore
         private readonly AppDataSettingStore<Settings> m_store;
         public Settings(AppDataSettingStore<Settings> store = null) {
            m_store = store ?? new AppDataSettingStore<Settings>();
         }

         // The Composite property shows how to declare a "HighPriority" & composite setting
         [HighPrioritySetting]
         public MachineAndTime HighPrioritySetting {
            get { return m_store.GetComposite<MachineAndTime>(); }
            set { m_store.SetComposite(value.m_store); }
         }

         [AppDataSetting(ApplicationDataLocality.Roaming, "NormalPriority")]
         public MachineAndTime NormalPrioritySetting {
            get { return m_store.GetComposite<MachineAndTime>(); }
            set { m_store.SetComposite(value.m_store); }
         }
         public void RemoveSettings() { m_store.RemoveSettings(); }
         public event PropertyChangedEventHandler PropertyChanged {
            add { m_store.PropertyChanged += value; }
            remove { m_store.PropertyChanged -= value; }
         }
      }

      // This class shows how to define a composite value
      public sealed class MachineAndTime : INotifyPropertyChanged {
         // Internal because UserSettings' property needs to access it
         internal AppDataCompositeValueSettingStore<MachineAndTime> m_store;

         public MachineAndTime(AppDataCompositeValueSettingStore<MachineAndTime> store = null) {
            m_store = store ?? new AppDataCompositeValueSettingStore<MachineAndTime>(new ApplicationDataCompositeValue());
         }

         public String Machine {
            get { return m_store.Get(String.Empty); }
            set { m_store.Set(value); }
         }
         public DateTimeOffset TimeSet {
            get { return m_store.Get(DateTimeOffset.MinValue); }
            set { m_store.Set(value); }
         }
         public void RemoveSettings() { m_store.RemoveSettings(); }
         public event PropertyChangedEventHandler PropertyChanged {
            add { m_store.PropertyChanged += value; }
            remove { m_store.PropertyChanged -= value; }
         }
      }

      private readonly Settings m_settings = new Settings();

      private void OnChangeHighPrioritySetting(object sender, RoutedEventArgs e) {
         m_settings.HighPrioritySetting = new MachineAndTime {
            Machine = m_machineName,
            TimeSet = DateTimeOffset.UtcNow
         };
         ShowValues(WhatToShow.High);
      }

      private void OnChangeNormalPrioritySetting(object sender, RoutedEventArgs e) {
         m_settings.NormalPrioritySetting = new MachineAndTime {
            Machine = m_machineName,
            TimeSet = DateTimeOffset.UtcNow
         };
         ShowValues(WhatToShow.Normal);
      }

      private async void OnClearSettings(object sender, RoutedEventArgs e) {
         await ApplicationData.Current.ClearAsync(ApplicationDataLocality.Roaming);
         ShowValues(WhatToShow.Both);
      }

      private void OnClearSkyDrive(object sender, RoutedEventArgs e) {
         Launcher.LaunchUriAsync(new Uri("https://SkyDrive.Live.com/Win8PersonalSettingsPrivacy/")).Forget();
      }
   }
}
