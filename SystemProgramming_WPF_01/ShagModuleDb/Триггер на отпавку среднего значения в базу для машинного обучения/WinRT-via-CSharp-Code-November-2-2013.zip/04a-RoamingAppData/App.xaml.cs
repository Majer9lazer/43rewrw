﻿using System;
using Windows.ApplicationModel.Activation;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace RoamingAppData {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
         const UInt32 appDataLatestVersion = 3;
         if (ApplicationData.Current.Version < appDataLatestVersion)
            ApplicationData.Current.SetVersionAsync(appDataLatestVersion, ApplicationDataSetVersionHandler).AsTask().GetAwaiter().GetResult();
         var v = ApplicationData.Current.Version;
      }

      private void ApplicationDataSetVersionHandler(SetVersionRequest setVersionRequest) {
         // To upgrade storage files, leave this method 'async', use the deferral and 'await' file I/O methods
         // If you're only upgrading settings, delete 'async' and the deferral-related code
         var deferral = setVersionRequest.GetDeferral();
         switch (setVersionRequest.CurrentVersion) {
            case 0:
               // TODO: Code to convert from version 0 to latest version goes here
               break;
            case 1:
               // TODO: Code to convert from version 1 to latest version goes here
               break;
         }
         deferral.Complete();
      }

      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         Frame rootFrame = Window.Current.Content as Frame;
         if (rootFrame == null) {
            rootFrame = new Frame();
            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            if (!rootFrame.Navigate(typeof(MainPage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         Window.Current.Activate();
      }
   }
}
