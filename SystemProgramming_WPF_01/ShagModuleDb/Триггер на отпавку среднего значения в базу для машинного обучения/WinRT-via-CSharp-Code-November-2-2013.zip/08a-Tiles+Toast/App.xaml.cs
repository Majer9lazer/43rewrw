﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

// Tiles:  http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx
// Badges: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868205.aspx
// Toasts: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868267.aspx
// Audio:  http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868265.aspx

using System;
using System.Diagnostics;
using Windows.ApplicationModel.Activation;
using Windows.Data.Xml.Dom;
using Windows.UI.Notifications;
using Windows.UI.Popups;
using Windows.UI.StartScreen;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Wintellect;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.DemoSpecific;
using Wintellect.WinRT.Notifications;


namespace TilesAndToast {
   sealed partial class App : Application {
      // Invoked because DISABLE_XAML_GENERATED_MAIN is defined:
      public static void Main(String[] args) { AppAid.Start(p => new App()); }

      public App() {
         this.InitializeComponent();
      }

      protected override async void OnLaunched(LaunchActivatedEventArgs args) {
         LaunchReason lr = args.GetLaunchReason();
         if (lr != LaunchReason.PrimaryTile) {
            Debugger.Break();
            String title = "App launched via " + lr.ToString().PascalCasingToWords();
            String content = "TileId = " + args.TileId + "\nArguments = " + args.Arguments;
            await new MessageDialog(content, title).ShowAsync();

            if (lr == LaunchReason.SecondaryTile) {
               // Ask user to destroy the secondary tile:
               var tile = new SecondaryTile(args.TileId);
               // NOTE: RequestDeleteAsync returns false if tileId doesn't exist
               Boolean userDeleted = await Demo.DebuggerDelayAsync(() => tile.RequestDeleteAsync());
               Debugger.Break();
            }
         }

         Frame rootFrame = Window.Current.Content as Frame;

         // Don't repeat app initialization when Window already has content, just activate window
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When navigation stack isn't restored, navigate to 1st page
            if (!rootFrame.Navigate(typeof(TilePage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure current window is active
         Window.Current.Activate();
      }
   }
}
