﻿/******************************************************************************
Module:  TilePage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

// Tiles:  http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx
// Badges: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868205.aspx
// Toasts: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868267.aspx
// Audio:  http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868265.aspx

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Networking.PushNotifications;
using Windows.UI;
using Windows.UI.Notifications;
using Windows.UI.Popups;
using Windows.UI.StartScreen;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Wintellect;
using Wintellect.WinRT.DemoSpecific;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.Notifications;
using Wintellect.WinRT.PushNotifications;
using Windows.Web.Http;

namespace TilesAndToast {
   /// <summary>
   /// An empty page that can be used on its own or navigated to within a Frame.
   /// </summary>
   public sealed partial class TilePage : Page {
      private const String c_baseUri = "ms-appx:///Assets/";
      public TilePage() {
         this.InitializeComponent();
         VerifyTilesCanBeUpdated();
#if DEBUG
         TileTemplate.ValidateTemplates = true;
#endif
      }

      private async void VerifyTilesCanBeUpdated() {
         NotificationSetting setting = TileUpdateManager.CreateTileUpdaterForApplication().Setting;
         switch (setting) {
            case NotificationSetting.Enabled: break;
            case NotificationSetting.DisabledForUser:
            case NotificationSetting.DisabledForApplication:
            case NotificationSetting.DisabledByManifest:
            case NotificationSetting.DisabledByGroupPolicy:
               await new MessageDialog("Tile updates are " + setting.ToString().PascalCasingToWords()).ShowAsync();
               break;
         }
      }

      private void ClearTiles(object sender, RoutedEventArgs e) {
         ClearTiles().Forget();
      }

      private async Task ClearTiles() {
         // Reverts app's primary tile to its default content as declared in the app's manifest
         TileUpdateManager.CreateTileUpdaterForApplication().Clear();
         BadgeUpdateManager.CreateBadgeUpdaterForApplication().Clear();
         foreach (SecondaryTile tile in await SecondaryTile.FindAllAsync()) {
            await tile.RequestDeleteAsync();
         }
      }

      private static XmlDocument GetTileXml(Int32 n = 0) {
         // User can make a wide tile small so, small tiles are mandatory & wide tiles are optional:
         // Tile templates: http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx
         String relativeImageUri = n + ".png";
         String text = n + " - " + DateTimeOffset.Now;
         TileTemplate tile = new TileTemplate {
            VisualBaseUri = c_baseUri,
            Square150x150Tile = new TileBinding(TileTemplateType.TileSquare150x150PeekImageAndText04) {
               Images = { relativeImageUri }, Text = { text }
            },
            Wide310x150Tile = new TileBinding(TileTemplateType.TileWide310x150ImageAndText01) {
               Images = { relativeImageUri }, Text = { text }
            },
            Square310x310Tile = new TileBinding(TileTemplateType.TileSquare310x310ImageAndTextOverlay01) {
               Images = { relativeImageUri }, Text = { text }
            }
         };
         String xml = tile.ToString();
         return tile;
      }

      private async void AppTileBasics(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // NOTE: If you want wide tiles, you MUST set Application UI -> Wide Logo in the manifest
         await ClearTiles();   // Reset the demo

         // User can make a wide tile small so, small tiles are mandatory & wide tiles are optional:
         // Tiles: http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx
         TileTemplate tile = new TileTemplate {
            VisualBaseUri = c_baseUri,
            Square150x150Tile = new TileBinding(TileTemplateType.TileSquare150x150PeekImageAndText02) {
               Images = { "Tiger.png" }, Text = { "Tiger", "Running in the snow" }
            },
            Wide310x150Tile = new TileBinding(TileTemplateType.TileWide310x150ImageAndText01) {
               Branding = Branding.Name,
               Images = { "Tiger.png" }, Text = { "Tiger running in the snow" }
            },
            Square310x310Tile = new TileBinding(TileTemplateType.TileSquare310x310ImageAndTextOverlay02) {
               Branding = Branding.Name,
               Images = { "Tiger.png" }, Text = { "Tiger", "Running in the snow" }
            }
         };
         String xml = tile.ToString(); // See what it looks like

         // Get a TileUpdater for the app's tile
         TileUpdater tu = TileUpdateManager.CreateTileUpdaterForApplication();

         // Update our app's tile with a notification that lasts for a few seconds
         TileNotification tn = new TileNotification(tile) {
            ExpirationTime = DateTimeOffset.Now.AddSeconds(15)
         };
         tu.Update(tn);

         // Enable queuing up to 5 notifications for all tile sizes
         tu.EnableNotificationQueue(true);

         // Queue a few notifications to our app's tile:
         for (Int32 tileNum = 0; tileNum < 3; tileNum++) {
            tn = new TileNotification(GetTileXml(tileNum)) {
               Tag = tileNum.ToString() /* Max=16 characters */
            };
            tu.Update(tn);
         }

         // Replace the notification whose tag is "1":
         // Note: To delete a notification, set ExpirationTime to near future
         TileTemplate tileXml = new TileTemplate {
            Square150x150Tile = new TileBinding(TileTemplateType.TileSquare150x150Block) { Text = { "Replacement Tile" } },
            Wide310x150Tile = new TileBinding(TileTemplateType.TileWide310x150Text01) { Text = { "Replacement Tile" } },
            Square310x310Tile = new TileBinding(TileTemplateType.TileSquare310x310Text01) { Text = { "Replacement Tile" } }
         };
         String ss = tileXml.ToString();
         tn = new TileNotification(tileXml) { ExpirationTime = DateTimeOffset.Now.AddSeconds(10), Tag = "1" };
         tu.Update(tn);

         // Overlay a badge on our app's tile (including the small tile):
         // Badge glyphs: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868205.aspx
         BadgeUpdater bu = BadgeUpdateManager.CreateBadgeUpdaterForApplication();
         BadgeTemplate badgeXml = new BadgeTemplate(BadgeGlyph.NewMessage);
         bu.Update(new BadgeNotification(badgeXml));

         badgeXml = new BadgeTemplate(42);
         bu.Update(new BadgeNotification(badgeXml));

         // Clear the app's tile notifications and badge:
         tu.Clear();
         bu.Clear();
      }

      private void AppTilePeriodicUpdate(object sender, RoutedEventArgs e) {
         Debugger.Break();
         TileUpdater tu = TileUpdateManager.CreateTileUpdaterForApplication();
         tu.StartPeriodicUpdate(new Uri("http://WintellectNOW.blob.core.windows.net/public/TileTemplates.xml"),
            DateTimeOffset.UtcNow.AddSeconds(10), PeriodicUpdateRecurrence.HalfHour);
         tu.StopPeriodicUpdate();
      }

      private async void SecondaryTileBasics(object sender, RoutedEventArgs e) {
         Debugger.Break();
         const String c_tileId = "SecondaryTile";
         SecondaryTile tile = new SecondaryTile(c_tileId) {    // ID passed to OnLaunched
            Arguments = DateTimeOffset.Now.ToString(),         // Arguments passed to OnLaunched (can't be "")
            DisplayName = "2nd tile-Display Name",
         };
         // Properties common to all tile sizes:
         tile.VisualElements.BackgroundColor = Colors.Green;
         tile.VisualElements.ForegroundText = ForegroundText.Light;  // Dark=#2A2A2A, Light=#FFFFFF
         tile.VisualElements.Square30x30Logo = new Uri(c_baseUri + "SmallLogo.png");           // Optional

         // Select tile sizes to offer the user:
         tile.VisualElements.Square70x70Logo = new Uri(c_baseUri + "Square70x70Logo.png");     // Optional
         tile.VisualElements.Square150x150Logo = new Uri(c_baseUri + "Logo.png");              // Mandatory
         tile.VisualElements.ShowNameOnSquare150x150Logo = false;
         tile.VisualElements.Wide310x150Logo = new Uri(c_baseUri + "WideLogo.png");            // Optional
         tile.VisualElements.ShowNameOnWide310x150Logo = true;
         tile.VisualElements.Square310x310Logo = new Uri(c_baseUri + "Square310x310Logo.png"); // Optional
         tile.VisualElements.ShowNameOnSquare310x310Logo = true;

         // Ask user to create the secondary tile (run to BP in debugger):
         Point point = ((FrameworkElement)sender).TransformToVisual(null).TransformPoint(new Point());
         Boolean userCreated = await Demo.DebuggerDelayAsync<Boolean>(() => tile.RequestCreateAsync(point));
         Debugger.Break();

         // Check for existence of a secondary tile:
         Boolean exists = SecondaryTile.Exists(c_tileId);

         // Enumerate the app's secondary tiles:
         SecondaryTile[] tiles = (await SecondaryTile.FindAllAsync()).ToArray();

         if (!userCreated) return;

         // Update a secondary tile's notification & badge:
         TileUpdater tu = TileUpdateManager.CreateTileUpdaterForSecondaryTile(c_tileId);
         tu.Update(new TileNotification(GetTileXml()));

         BadgeUpdater bu = BadgeUpdateManager.CreateBadgeUpdaterForSecondaryTile(c_tileId);
         bu.Update(new BadgeNotification(new BadgeTemplate(12)));

         // DEMO: Return from here & launch app via secondary tile:
         // NOTE: Launch event is posted to GUI thread so we have to return 
         // from this method to get it
      }

      private void ToastBasics(object sender, RoutedEventArgs args) {
         Debugger.Break();
         // NOTE: If you want toast, you MUST set Application UI -> Toast Capable: Yes
         // Toasts: http://msdn.microsoft.com/en-us/library/windows/apps/xaml/hh868267.aspx
         ToastNotifier toastNotifier = ToastNotificationManager.CreateToastNotifier();

         // Make sure toasts are enabled via Settings -> Notifications
         if (toastNotifier.Setting != NotificationSetting.Enabled) return;

         // Create a toast notification, register with its events, and show it
         ToastTemplate xml = new ToastTemplate(ToastTemplateType.ToastImageAndText01) {
            Launch = "Toast arguments go here",
            Duration = ToastDuration.Long,
            Audio = new ToastAudio { Source = SoundEvent.LoopingCall3, Loop = true },
            Text = { "This is a toast!" },
            Images = { c_baseUri + "Tiger.png" },
            Command = new ToastIncomingCallCommand("video", "voice", "decline")  // Optional
         };
         String seeTheXml = xml.ToString();
         ToastNotification toastNotification = new ToastNotification(xml);

         toastNotification.Activated += (toastNotification_, @object) => {
            // NonGUI: User activated the toast
            Debugger.Break();
            String toastArgs = ((ToastActivatedEventArgs)@object).Arguments;
         };

         toastNotification.Dismissed += (toastNotification_, toastDismissedEventArgs) => {
            // NonGUI: If app suspended when toast dismissed, method called on resume
            ToastDismissalReason reason = toastDismissedEventArgs.Reason;
            // UserCanceled, TimedOut (Short=7s, Long=20s), ApplicationHidden (ToastNotifier.Hide)
            Debugger.Break();
         };
         toastNotifier.Show(toastNotification);
      }

      private void ScheduledToast(object sender, RoutedEventArgs args) {
         Debugger.Break();
         ToastTemplate xml = new ToastTemplate(ToastTemplateType.ToastText01) {
            Launch = "MeetingReminder", Text = { "Meeting Reminder" },
            Duration = ToastDuration.Long,
            Audio = new ToastAudio { Source = SoundEvent.Reminder, Loop = true }
         };

         ToastNotifier toastNotifier = ToastNotificationManager.CreateToastNotifier();
         var scheduledToastNotification = new ScheduledToastNotification(xml,
            DateTimeOffset.Now.AddSeconds(10),  // Delivery time
            TimeSpan.FromMinutes(1),            // Snooze interval (minimum=1 minute)
            2) { Id = "Meeting" };              // Max display count & ID
         // NOTE: Scheduled toasts don't offer Activated/Dismissed events

         toastNotifier.AddToSchedule(scheduledToastNotification);

         IReadOnlyList<ScheduledToastNotification> scheduledToasts =
            toastNotifier.GetScheduledToastNotifications();
         for (Int32 n = 0; n < scheduledToasts.Count; n++) {
            var props = scheduledToasts[n].PropsAsString();
         }
      }

      private async void WindowsPushNotifications(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // NOTE: You must register your application with Windows Live: http://manage.dev.live.com/Build
         // You get back a new package name; put this in your Manifest -> Packaging -> Package Name
         // You also get package security identifier (SID) & secret; your server app needs these to talk to WNS

         // 1. On App start (usually), request a channel uri from WNS for a specific tile (Channels expire in 30 days):
         PushNotificationChannel channel = await
            PushNotificationChannelManager.CreatePushNotificationChannelForApplicationAsync();

         // 2. Register event handler to be invoked if our app is running when WNS sends an update:
         channel.PushNotificationReceived += PushNotificationReceived;

         // 3. Send channel Uri to App server (not shown here)...

         // *** The code below is typically executed by the app's companion web service:  ***
         AppServerWns appServerWns = new AppServerWns(
            WinRTSecrets.TileAndToastWnsSecurityId, WinRTSecrets.TileAndToastWnsSecret);
         appServerWns.RequestHeaders.WnsType = WnsType.Tile;
         appServerWns.RequestHeaders.RequestForStatus = true;

         // Create XML string payload to push:
         TileTemplate tile = new TileTemplate {
            Square150x150Tile = new TileBinding(TileTemplateType.TileSquare150x150PeekImageAndText01) {
               Images = { "http://images.plaxo.com/fetch_image?path=21475127560_0_139128642&size=40" },
               Text = { "Jeffrey", "Richter" }
            },
            Wide310x150Tile = new TileBinding(TileTemplateType.TileWide310x150ImageAndText01) {
               Images = { "http://images.plaxo.com/fetch_image?path=21475127560_0_139128642&size=40" },
               Text = { "Jeffrey Richter" }
            },
            Square310x310Tile = new TileBinding(TileTemplateType.TileSquare310x310ImageAndText01) {
               Images = { "http://images.plaxo.com/fetch_image?path=21475127560_0_139128642&size=40" },
               Text = { "Jeffrey Richter" }
            }
         };
         String xml = tile.ToString(); // See what it looks like

         TileUpdateManager.CreateTileUpdaterForApplication().Clear();   // For testing

         // NOTE: The app MUST be running to see the tile update because WNS notifications
         // are sent to the app 1st if running so the app can cancel the WNS notification
         // See the PushNotification.PushNotificationReceived event
         HttpResponseMessage response = await appServerWns.PushAsync(tile, channel.Uri);
         WnsResponseHeaders wnsResponseHeaders = response.GetWnsResponseHeaders();
         String msg = response.StatusCode.ToWnsResponseMessage();
      }

      // Non-GUI
      private void PushNotificationReceived(PushNotificationChannel sender, PushNotificationReceivedEventArgs e) {
         XmlDocument xml = null;
         switch (e.NotificationType) {
            case PushNotificationType.Tile: xml = e.TileNotification.Content; break;
            case PushNotificationType.Badge: xml = e.BadgeNotification.Content; break;
            case PushNotificationType.Toast: xml = e.ToastNotification.Content; break;
            case PushNotificationType.Raw: String s = e.RawNotification.Content; break;
         }
         //this.RunOnGui(async () => await new MessageDialog(xml.GetXml(), e.NotificationType.ToString() + " push notification received").ShowAsync());
         //e.Cancel = true;  // If true (default=false), notification ignored & tile doesn't change
      }
   }
}

#if false
   internal static class NotificationExtensions {
      //      public static XmlDocument ToXmlDocument(this XElement element) { XmlDocument xmlDocument = new XmlDocument(); xmlDocument.LoadXml(element.ToString()); return xmlDocument; }
      public static XmlDocument SetTemplateText(this XmlDocument xml, params String[] text) {
         XmlNodeList textElements = xml.GetElementsByTagName("text");
         for (Int32 i = 0; i < Math.Min(textElements.Length, text.Length); i++) {
            if (textElements[i].ChildNodes.Count == 0)
               textElements[i].AppendChild(xml.CreateTextNode(text[i]));
            else textElements[i].ChildNodes[0].NodeValue = text[i];
         }
         return xml;
      }

      public static XmlDocument SetTemplateImages(this XmlDocument xml, params String[] imageUris) {
         XmlNodeList elements = xml.GetElementsByTagName("image");
         for (Int32 i = 0; i < Math.Min(elements.Length, imageUris.Length); i++) {
            XmlElement element = (XmlElement)elements[i];
            element.SetAttribute("src", imageUris[i]);
            element.SetAttribute("alt", imageUris[i]);   // Consider passing the alt text as an argument
         }
         return xml;
      }

      public static XmlDocument MergeTemplate(this XmlDocument master, XmlDocument toBeMerged) {
         var node = master.ImportNode(toBeMerged.GetElementsByTagName("binding")[0], true);
         master.GetElementsByTagName("visual")[0].AppendChild(node);
         return master;
      }

      public static XmlDocument SetBranding(this XmlDocument xml, String branding = "none") {
         var binding = xml.GetElementsByTagName("binding");
         ((XmlElement)binding[0]).SetAttribute("branding", branding);
         return xml;
      }

      public static XmlDocument SetBadgeValue(this XmlDocument xml, String value) {
         ((XmlElement)xml.GetElementsByTagName("badge")[0]).SetAttribute("value", value);
         return xml;
      }

      public static XmlDocument SetBadgeNumber(this XmlDocument xml, Int32 value) {
         return xml.SetBadgeValue(value.ToString());
      }

      public static XmlDocument SetBadgeGlyph(this XmlDocument xml, BadgeGlyph glyph) {
         return xml.SetBadgeValue(glyph.ToString());
      }
   }
#endif
