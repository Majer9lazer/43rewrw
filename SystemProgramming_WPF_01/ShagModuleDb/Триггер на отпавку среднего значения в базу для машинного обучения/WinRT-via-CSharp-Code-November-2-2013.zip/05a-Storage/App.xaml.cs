﻿/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Windows.ApplicationModel.Activation;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Storage {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
      }

      protected override void OnLaunched(LaunchActivatedEventArgs args) {
         Frame rootFrame = Window.Current.Content as Frame;

         // Don't repeat app initialization when Window already has content, just activate window
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When navigation stack isn't restored, navigate to 1st page
            if (!rootFrame.Navigate(typeof(StoragePage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure current window is active
         Window.Current.Activate();
      }

      protected override async void OnFileActivated(FileActivatedEventArgs args) {
         StorageFile[] selectedFiles = args.Files.OfType<StorageFile>().ToArray();
         // args.NeighboringFilesQuer is null if multiple items are being activated
         StorageFile[] neighboringFiles = (args.NeighboringFilesQuery == null) ? null : args.NeighboringFilesQuery.GetFilesAsync().AsTask().Result.ToArray();

         StorageFile file = selectedFiles[0];
         var sb = new StringBuilder().AppendFormat("Activated to '{0}' the '{1}' file.\n\r", args.Verb, file.Name);
         if (!String.IsNullOrWhiteSpace(file.FileType)) {
            // Open via StorageFile
            sb.AppendFormat("Path='{0}'", file.Path);
         } else {
            // Open via URI
            sb.AppendFormat("URI='{0}'", file.FolderRelativeId.Substring(file.FolderRelativeId.IndexOf('\\') + 1));
         }
         await new MessageDialog(sb.ToString()).ShowAsync();
         Debugger.Break();
      }
   }
}
