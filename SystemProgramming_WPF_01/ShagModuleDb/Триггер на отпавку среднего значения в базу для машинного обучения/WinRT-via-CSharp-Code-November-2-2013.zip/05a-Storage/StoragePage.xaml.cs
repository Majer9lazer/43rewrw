﻿/******************************************************************************
Module:  StoragePage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.AccessCache;
using Windows.Storage.BulkAccess;   // TODO: Remove
using Windows.Storage.FileProperties;
using Windows.Storage.Pickers;
using Windows.Storage.Search;
using Windows.Storage.Streams;
using Windows.System;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media.Imaging;
using Wintellect;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.Xaml;

namespace Storage {
   public sealed partial class StoragePage : Page {
      public StoragePage() {
         this.InitializeComponent();
      }
      private async void PackageData(Object sender, RoutedEventArgs e) {
         Debugger.Break(); // Put file.Path in watch window

         // *** Reading static data deployed with the package ***
         // You shouldn't write to this folder (but you can when running a non-Store deployment)
         StorageFolder folder = Windows.ApplicationModel.Package.Current.InstalledLocation;
         StorageFile file = await folder.GetFileAsync(@"Assets\Logo.scale-100.png");

         // Uri formats: http://msdn.microsoft.com/en-us/library/windows/apps/hh781215.aspx
         // Uri expansion: http://msdn.microsoft.com/en-us/library/windows/apps/Hh965372.aspx
         // Globalizing images: http://msdn.microsoft.com/en-us/library/windows/apps/Hh831183.aspx
         // Get asset from current package. NOTE: 3 slashes.
         file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///Assets/Logo.png"));       // Same as "ms-appx://" + packageId.Name + "/Assets/Logo.png"
         String defaultLanguage = Windows.ApplicationModel.Resources.Core.ResourceContext.GetForCurrentView().Languages[0];
         // Globalizing: http://msdn.microsoft.com/en-us/library/windows/apps/Hh831183.aspx
         String contrast = new Windows.UI.ViewManagement.AccessibilitySettings().HighContrastScheme;
         var scale = Windows.Graphics.Display.DisplayInformation.GetForCurrentView().ResolutionScale;

         // *** Reading/Writing per-user data associated with the package ***
         // See the LocalState, RoamingState, & TempState folders in this directory:
         PackageId packageId = Windows.ApplicationModel.Package.Current.Id;
         String giveToExplorer = (@"%UserProfile%/AppData/Local/Packages/" + packageId.FamilyName).CopyToClipboard();

         folder = ApplicationData.Current.LocalFolder;
         file = await folder.CreateFileAsync("LocalFile.txt", CreationCollisionOption.ReplaceExisting);
         file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appdata:///local/LocalFile.txt"));

         folder = ApplicationData.Current.RoamingFolder;
         file = await folder.CreateFileAsync("RoamingFile.txt", CreationCollisionOption.GenerateUniqueName);
         file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appdata:///roaming/RoamingFile.txt"));

         folder = ApplicationData.Current.TemporaryFolder;
         file = await folder.CreateFileAsync("TemporaryFile.txt", CreationCollisionOption.OpenIfExists);
         file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appdata:///temp/TemporaryFile.txt"));

         await ApplicationData.Current.ClearAsync();  // Erase all application data
      }
      private async void PickerIntro(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Accessing a folder & files that the user picks:      
         var picker = new FileOpenPicker {
            SuggestedStartLocation = PickerLocationId.Desktop,
            CommitButtonText = "Select",
            ViewMode = PickerViewMode.Thumbnail,
            FileTypeFilter = { ".jpg", ".png" },
            SettingsIdentifier = "SomeReason"   // Save user's folder & extension info
         };
         StorageFile file = await picker.PickSingleFileAsync();

         // Start folder & extension are remembered
         await picker.PickSingleFileAsync();

         // Start folder is Desktop & extension is ".jpg"
         picker.SettingsIdentifier = "AnotherReason";
         await picker.PickSingleFileAsync();

         // Start folder & extension match "SomeReason"
         picker.SettingsIdentifier = "SomeReason";
         await picker.PickSingleFileAsync();
         // SettingsIdentifier info is stored here: HKEY_CLASSES_ROOT\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\PackageFamilyName\PersistedPickerData
      }

      // Access list info is stored here: HKEY_CLASSES_ROOT\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\PackageFamilyName\PersistedStorageItemTable
      private static readonly IStorageItemAccessList s_mru = StorageApplicationPermissions.MostRecentlyUsedList;
      private async void FileOpenPicker(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         var picker = new FileOpenPicker() {
            SuggestedStartLocation = PickerLocationId.Desktop,
            CommitButtonText = "Open",
            ViewMode = PickerViewMode.List,
            FileTypeFilter = { ".txt", ".log" }
         };
         StorageFile file = await picker.PickSingleFileAsync();
         if (file == null) return;
         s_mru.AddOrReplace(file.DisplayName, file);
         m_txtFileData.Text = await FileIO.ReadTextAsync(file);
      }
      private async void OpenMRU(Object sender, RoutedEventArgs e) {
         var menu = new PopupMenu();
         foreach (String token in from ale in s_mru.Entries.Take(6) select ale.Token) {
            menu.Commands.Add(new UICommand(token));
         }

         Rect rect = new Rect(0, 0, m_btnOpenMru.ActualWidth, m_btnOpenMru.ActualHeight);
         rect = m_btnOpenMru.TransformToVisual(this).TransformBounds(rect);
         IUICommand c = await menu.ShowForSelectionAsync(rect);
         Debugger.Break();
         if (c == null) return;
         try {
            StorageFile file = await s_mru.GetFileAsync(c.Label);
            m_txtFileData.Text = await FileIO.ReadTextAsync(file);
         }
         catch (FileNotFoundException ex) {
            new MessageDialog(ex.Message).ShowAsync().Forget();
         }
      }
      private async void FileSavePicker(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         StorageFile lastFile = await s_mru.GetFileAsync(s_mru.Entries[0].Token);
         var picker = new FileSavePicker() {
            SuggestedStartLocation = PickerLocationId.Desktop,
            CommitButtonText = "Save",
            DefaultFileExtension = ".txt",
            SuggestedFileName = lastFile.Name,
            SuggestedSaveFile = lastFile,
            FileTypeChoices = { { "Text files", new[] { ".txt" } }, { "Log files", new[] { ".log" } } }
         };

         StorageFile file = await picker.PickSaveFileAsync();
         if (file == null) return;
         s_mru.AddOrReplace(file.Name, file);
         await FileIO.WriteTextAsync(file, m_txtFileData.Text);
      }
      private async void DeleteMruFiles(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         foreach (AccessListEntry ale in s_mru.Entries) {
            try {
               StorageFile file = await s_mru.GetFileAsync(ale.Token);
               await file.DeleteAsync(StorageDeleteOption.Default);
            }
            catch (FileNotFoundException) { }
         }
         s_mru.Clear();
      }
      private async void FileActivate(object sender, RoutedEventArgs e) {
         Debugger.Break();
         var md = new MessageDialog("How do you want to perform the file activation?", "File Activation") {
            Commands = { 
               new UICommand("StorageFile", null, 0), 
               new UICommand("URI Protocol", null, 1) 
            }
         };
         IUICommand result = await md.ShowAsync();
         try {
            switch ((Int32)result.Id) {
               case 0: {
                     var file = await StorageFile.CreateStreamedFileAsync("SomeFile.jeff", dr => { }, null);
                     var ok = await Launcher.LaunchFileAsync(file, new LauncherOptions { DisplayApplicationPicker = false });
                  }
                  break;
               case 1: {
                     var file = await StorageFile.CreateStreamedFileAsync("SomeFile.notJeff", dr => { }, null);
                     var ok = await Launcher.LaunchUriAsync(new Uri("http://Wintellect.com/SomeFile"),
                        new LauncherOptions {
                           ContentType = "application/jeff",   // Declared in manifest
                           DisplayApplicationPicker = true
                        });
                  }
                  break;
            }
         }
         catch (Exception ex) {
            var m = ex.Message;
         }
      }
      private async void Properties(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         var picker = new FileOpenPicker() {
            FileTypeFilter = { "*" },
            SuggestedStartLocation = PickerLocationId.ComputerFolder,
            ViewMode = PickerViewMode.List
         };
         StorageFile file = await picker.PickSingleFileAsync();
         if (file == null) return;

         // See file's built-in properties: Attributes, ContentType, DateCreated, 
         // DisplayName, DisplayType, FileType, FolderRelativeId, Name, Path

         // StorageFolder & StorageFile both implement IStorageItemProperties
         BasicProperties basicProps = await file.GetBasicPropertiesAsync();

         // See System properties http://msdn.microsoft.com/en-us/library/windows/desktop/dd561977(v=vs.85).aspx
         // You can get common property strings via the Windows.Storage.SystemProperties class
         IDictionary<String, Object> props = await file.Properties.RetrievePropertiesAsync(
            new String[] { 
               "System.FileAttributes", "System.DateModified", 
               "System.Size", SystemProperties.ItemNameDisplay 
            });
         String props2 = String.Join(", ", from p in props.Keys select p + "=" + props[p]);

         DocumentProperties dp = await file.Properties.GetDocumentPropertiesAsync();
         ImageProperties ip = await file.Properties.GetImagePropertiesAsync();
         MusicProperties mp = await file.Properties.GetMusicPropertiesAsync();
         VideoProperties vp = await file.Properties.GetVideoPropertiesAsync();
         // Update properties by calling *.SavePropertiesAsync()

         m_gv.Visibility = Visibility.Collapsed;
         m_imgThumbnail.Visibility = Visibility.Visible;
         StorageItemThumbnail t = await file.GetScaledImageAsThumbnailAsync(ThumbnailMode.SingleItem);
         var bitmap = new BitmapImage();
         bitmap.SetSourceAsync(t).Forget();
         m_imgThumbnail.Source = bitmap;
      }

#if false
         // How to change a file's attributes (NOTE: UInt32 cast is mandatory)
         await basicProps.SavePropertiesAsync(new[] { new KeyValuePair<String, Object>("System.FileAttributes", (UInt32) FileAttributes.ReadOnly) });
#endif

      private async Task SpecialProperties(Object sender, RoutedEventArgs e) {
         StorageFile file = await ApplicationData.Current.TemporaryFolder.CreateFileAsync("Temp", CreationCollisionOption.ReplaceExisting);
         BasicProperties basicProps = await file.GetBasicPropertiesAsync();
         Debugger.Break();

         IDictionary<String, Object> props = await basicProps.RetrievePropertiesAsync(new String[] { 
            "System.ComputerName", // Unrelated to any file (see also Windows.Networking.Proximity.PeerFinder.DisplayName)
            "System.Capacity", "System.FreeSpace", "System.PercentFull",    // Related to file's volume
            "System.FileOwner"   // Related to a specific file
         });
         String props2 = String.Join(", ", from p in props.Keys select p + "=" + props[p]);

         await file.DeleteAsync();  // Cleanup demo
      }

      private async Task CopyFolder(StorageFolder source, StorageFolder destination, String desiredName, CreationCollisionOption existingOption) {
         IAsyncOperation<IReadOnlyList<StorageFile>> subfileListAsync = source.GetFilesAsync();
         IAsyncOperation<IReadOnlyList<StorageFolder>> subfolderListAsync = source.GetFoldersAsync();

         StorageFolder destinationFolder = await destination.CreateFolderAsync(source.Name, existingOption);
         foreach (StorageFile file in await subfileListAsync) {
            await file.CopyAsync(destinationFolder, file.Name, NameCollisionOption.FailIfExists);
         }

         // Copy folders by calling this function recursively
         foreach (StorageFolder folder in await subfolderListAsync) {
            await CopyFolder(folder, destinationFolder, folder.Name, existingOption);
         }
      }

      private async void IndexedAppData(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Under LocalFolder, an app can create an "Indexed" folder whose contents will be indexed by Windows Search
         // As these files are an "implementation detail" of the app, Explorer searches will NOT normally return them         
         // Specifically, Windows Search excludes the AppData folder: http://msdn.microsoft.com/en-us/library/windows/desktop/bb266513(v=vs.85).aspx

         // To test, go to %UserProfile%\AppData\Local\Packages\PackageFamilyName/LocalState/Indexed in Explorer & now a search will work
         // You can check Indexer status in Control via “Indexing Options”. If it says “Indexing complete”, then Indexer is done indexing files
         // Programmatic queries can return the content as shown in the code below:

         // Create the local app folder's "Indexed" subdirectory:
         StorageFolder localFolder = ApplicationData.Current.LocalFolder;
         StorageFolder indexedSubdir = await localFolder.CreateFolderAsync("Indexed", CreationCollisionOption.OpenIfExists);

         // Create two text files in the "Indexed" subdirectory:
         await FileIO.WriteTextAsync(
            await indexedSubdir.CreateFileAsync("File1.txt", CreationCollisionOption.ReplaceExisting), "abc");
         await FileIO.WriteTextAsync(
            await indexedSubdir.CreateFileAsync("File2.txt", CreationCollisionOption.ReplaceExisting), "abcd");

         // Create a query that looks for .txt files containing "abcd"
         var qo = new QueryOptions(CommonFileQuery.DefaultQuery, new[] { ".txt" }) {
            ApplicationSearchFilter = "abcd",
            IndexerOption = IndexerOption.OnlyUseIndexer, // Indexed files only!
            FolderDepth = FolderDepth.Deep                // Search subdirectories too
         };
         StorageFileQueryResult searchResults = localFolder.CreateFileQueryWithOptions(qo);

         // Perform the query and get the results
         IReadOnlyList<StorageFile> result = await searchResults.GetFilesAsync();
         // 'result' contains a single StorageFile object referring to File2.txt

         var files = result.ToArray();
         await ApplicationData.Current.ClearAsync(ApplicationDataLocality.Local);  // Erase the dir & files
      }

      private async void Gallery(object sender, RoutedEventArgs e) {
         Debugger.Break();

         // 1.Create QueryOptions to filter/sort results
         QueryOptions qo = new QueryOptions(CommonFolderQuery.GroupByYear) { FolderDepth = FolderDepth.Deep };

         // 2. From virtual folder callCreate[File|Folder|Item]QueryWithOptions
         StorageFolderQueryResult folders = KnownFolders.PicturesLibrary.CreateFolderQueryWithOptions(qo);

         // Process results (build string tree)
         var sb = new StringBuilder();
         foreach (StorageFolder folder in await folders.GetFoldersAsync()) {
            sb.AppendLine(folder.DisplayName);
            foreach (StorageFile file in await folder.GetFilesAsync()) {
               sb.AppendLine("   " + file.Name);
            }
         }
         var result = sb.ToString();
         Debugger.Break();

         m_gv.Visibility = Visibility.Visible;
         m_imgThumbnail.Visibility = Visibility.Collapsed;

         // 1.Create QueryOptions to filter/sort results
         qo = new QueryOptions(CommonFileQuery.OrderByDate, new[] { "*" });

         ThumbnailMode thumbnailMode = ThumbnailMode.PicturesView;
         UInt32 thumbnailSize = IdealThumnailSize.PicturesView;

         // OPTIONAL: improve performance of fetching properties and/or thumbnails
         String[] propertiesToRetrieve = new String[] { "System.Size" };
         qo.SetPropertyPrefetch(PropertyPrefetchOptions.ImageProperties, propertiesToRetrieve);
         qo.SetThumbnailPrefetch(ThumbnailMode.PicturesView, thumbnailSize, ThumbnailOptions.None);

         // 2. From virtual folder callCreate[File|Folder|Item]QueryWithOptions
         StorageFileQueryResult files = KnownFolders.PicturesLibrary.CreateFileQueryWithOptions(qo);

         // 3. Get properties/thumbnails for results in bulk
         var fif = new FileInformationFactory(files, thumbnailMode, thumbnailSize, ThumbnailOptions.None, false);
         // Items have info, properties, thumbnail; Properties/ThumbnailUpdated events

         // Process results (data bind to GridView)
         m_gv.ItemsSource = fif.GetVirtualizedFilesVector();
         //m_gv.ItemsSource = await ObservableStorageFileList.CreateAsync(files);
      }

      private static class IdealThumnailSize {
         public const UInt32 None = 0;
         public const UInt32 PicturesView = 190;
         public const UInt32 VideosView = 190;
         public const UInt32 MusicView = 256;
         public const UInt32 DocumentsView = 40;
         public const UInt32 ListView = 40;
         public const UInt32 SingleItem16 = 16;
         public const UInt32 SingleItem32 = 32;
         public const UInt32 SingleItem48 = 48;
         public const UInt32 SingleItem96 = 96;
         public const UInt32 SingleItem256 = 256;
         public const UInt32 SingleItem1024 = 1024;
      }
   }

   public abstract class ConverterBase : IValueConverter {
      public virtual Object Convert(Object value, Type targetType, Object parameter, String culture) { return null; }
      public virtual Object ConvertBack(Object value, Type targetType, Object parameter, String culture) { return null; }
   }

   public sealed class ThumbConverter : ConverterBase {
      public override Object Convert(Object value, Type targetType, Object parameter, String culture) {
         if (value == null) return DependencyProperty.UnsetValue;
         var bitmap = new BitmapImage();
         bitmap.SetSourceAsync((IRandomAccessStream)value).Forget();
         return bitmap;
      }
   }

   // This class is an ObservableList that implements ISupportIncrementalLoading
   public sealed class ObservableStorageFileList : Wintellect.WinRT.Xaml.ObservableList, ISupportIncrementalLoading {
      public static async Task<ObservableStorageFileList> CreateAsync(StorageFileQueryResult storageQueryResult) {
         var list = new ObservableStorageFileList(storageQueryResult);
         list.m_maxCount = await list.m_storageQueryResult.GetItemCountAsync();
         return list;
      }
      private readonly StorageFileQueryResult m_storageQueryResult;
      private UInt32 m_maxCount;

      private ObservableStorageFileList(StorageFileQueryResult storageQueryResult) {
         m_storageQueryResult = storageQueryResult;
      }

      #region ISupportIncrementalLoading
      public Boolean HasMoreItems { get { return Count < m_maxCount; } }

      public IAsyncOperation<LoadMoreItemsResult> LoadMoreItemsAsync(UInt32 count) {
         return AsyncInfo.Run(cancellationToken => LoadMoreItemsAsync(cancellationToken, count));
      }
      #endregion

      #region Private methods
      private async Task<LoadMoreItemsResult> LoadMoreItemsAsync(CancellationToken c, UInt32 numItemsToGet) {
         UInt32 startIndex = (UInt32)Count;
         if (startIndex + numItemsToGet > m_maxCount) numItemsToGet = m_maxCount - (UInt32) startIndex;

         // Add dummy items to the collection immediately to user can keep scrolling
         for (Int32 n = 0; n < numItemsToGet; n++) { Insert((Int32) startIndex + n, new StorageProperties()); }

         // Request all thumbnail images simultaneously
         var tasks = new List<Task<StorageItemThumbnail>>((Int32)numItemsToGet);
         IReadOnlyList<StorageFile> files = await m_storageQueryResult.GetFilesAsync(startIndex, numItemsToGet);
         foreach (var item in files)
            tasks.Add(item.GetScaledImageAsThumbnailAsync(ThumbnailMode.PicturesView).AsTask());

         // Continue execution after all thumbnail images have been obtained
         StorageItemThumbnail[] thumbnails = await Task.WhenAll(tasks);

         // Add StorageProperty objects (with file name & thumbnail) to the collection
         for (Int32 n = 0; n < numItemsToGet; n++) {
            StorageProperties sp = (StorageProperties) this[(Int32) startIndex + n];
            sp.Name = (startIndex + n) + " - " +  files[n].Name;
            sp.Thumbnail = thumbnails[n];
            OnVectorChanged((Int32) (startIndex + n), Windows.Foundation.Collections.CollectionChange.ItemChanged);
         }

         // Return the number of items added to the collection
         return new LoadMoreItemsResult { Count = (UInt32)numItemsToGet };
      }
      #endregion

      public sealed class StorageProperties {
         public StorageProperties() { Name = String.Empty; }
         public String Name { get; set; }
         public StorageItemThumbnail Thumbnail { get; set; }
      }
   }
}