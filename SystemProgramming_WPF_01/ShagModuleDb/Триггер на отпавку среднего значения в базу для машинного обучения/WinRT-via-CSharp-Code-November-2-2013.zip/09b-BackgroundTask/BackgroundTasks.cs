﻿/******************************************************************************
Module:  BackgroundTasks.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

// NOTE: Project type must produce a WinMD file (not a DLL)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Devices.Geolocation;
using Windows.Devices.Geolocation.Geofencing;
using Windows.Foundation;
using Windows.Networking.PushNotifications;
using Windows.Storage;
using Windows.UI.Notifications;
using Windows.Web.Http;
using Wintellect.WinRT.Notifications;

namespace Wintellect.BackgroundTasks {
   // NOTE: public sealed is mandatory since this is a WinRT component!
   public sealed class SystemTriggerTask : IBackgroundTask {
      // For the app to know if Run throws an unhandled exception via CheckResult,
      // do NOT make Run async, do not use deferrals, & execute async operations synchronously.
      public void Run(IBackgroundTaskInstance taskInstance) {
         taskInstance.Canceled += (IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason) => {
            // TODO: Execute code to cleanup task if it is canceled before running to completion...
            // NOTE: If this code takes more than 5 seconds to execute, the process is killed
         };

         String toastText = taskInstance.Task.Name;
         ToastTemplate toast = new ToastTemplate(ToastTemplateType.ToastText02) { Text = { toastText, "Starting" } };
         ToastNotificationManager.CreateToastNotifier().Show(new ToastNotification(toast));

         FileIO.AppendLinesAsync(ApplicationData.Current.LocalFolder.CreateFileAsync("Log", CreationCollisionOption.OpenIfExists).AsTask().GetAwaiter().GetResult(), 
            new  [] { String.Format("{0} - {1}", DateTimeOffset.Now, toastText) }).AsTask().GetAwaiter().GetResult();

         for (UInt32 x = 0; x < 100; x += 50) {
            taskInstance.Progress = x;
            Task.Delay(500).GetAwaiter().GetResult(); // Execute async tasks synchronously
         }
      }

      public static void Canceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason) {
         // You have 5 seconds to execute code in here before process is killed
         switch (reason) {
            case BackgroundTaskCancellationReason.Abort:             // App called BackgroundTaskRegistration.Unregister(true)
            case BackgroundTaskCancellationReason.LoggingOff:        // User logged off the system
            case BackgroundTaskCancellationReason.ServicingUpdate:   // Package was updated
            case BackgroundTaskCancellationReason.Terminating:       // PLM is killing process
            case BackgroundTaskCancellationReason.IdleTask:          // Task was not doing any work
            case BackgroundTaskCancellationReason.Uninstall:         // Package uninstalled
            case BackgroundTaskCancellationReason.ConditionLoss:     // 1 or more conditions no longer met
            case BackgroundTaskCancellationReason.SystemPolicy:      // System policy
            case BackgroundTaskCancellationReason.QuietHoursEntered: // Quiet hours started
               ToastTemplate toast = new ToastTemplate(ToastTemplateType.ToastText02) { Text = { sender.Task.Name, "Canceled due to " + reason } };
               ToastNotificationManager.CreateToastNotifier().Show(new ToastNotification(toast));
               Debug.WriteLine("{0} task  canceled due to {1}", sender.Task.Name, reason);
               break;
         }
      }
   }
}

namespace Wintellect.BackgroundTasks {
   public sealed class PushNotificationTask : IBackgroundTask {
      public void Run(IBackgroundTaskInstance taskInstance) {
         String payload = ((RawNotification)taskInstance.TriggerDetails).Content;
         ApplicationData.Current.LocalSettings.Values["PushPayload"] = payload;
         Debug.WriteLine("Got Payload: " + payload);
         ToastNotificationManager.CreateToastNotifier().Show(new ToastNotification(
            new ToastTemplate(ToastTemplateType.ToastText02) { Launch = "GotPayload", Text = { "Got Payload", payload } }));
      }
   }
}

namespace Wintellect.BackgroundTasks {
   public sealed class ChannelUpdateMaintenanceTask : IBackgroundTask {
      // For the app to know if Run throws an unhandled exception via CheckResult,
      // do NOT make Run async, do not use deferrals, & execute async opertions synchronously.
      public void Run(IBackgroundTaskInstance taskInstance) {
         CreateChannelAsync().AsTask().GetAwaiter().GetResult();
      }

      public static IAsyncOperation<PushNotificationChannel> CreateChannelAsync() {
         return AsyncInfo.Run<PushNotificationChannel>(CreateChannelInternalAsync);
      }

      private async static Task<PushNotificationChannel> CreateChannelInternalAsync(CancellationToken ct = default(CancellationToken)) {
         // Request a channel uri from WNS for a specific tile (Note: Channels expire after ~1 month).
         // NOTE: Your package must have Internet capability to request a channel
         PushNotificationChannel channel = await PushNotificationChannelManager.CreatePushNotificationChannelForApplicationAsync();

         // Send channel Uri to App server (for demo, we put it in AppData)
         ApplicationData.Current.LocalSettings.Values["ChannelUri"] = channel.Uri;
         return channel;
      }

      public static String GetChannelUri() {
         return (String)ApplicationData.Current.LocalSettings.Values["ChannelUri"];
      }
   }
}

namespace Wintellect.BackgroundTasks {
   public sealed class GeofenceLocationTask : IBackgroundTask {
      public void Run(IBackgroundTaskInstance taskInstance) {
         IReadOnlyList<GeofenceStateChangeReport> reports = GeofenceMonitor.Current.ReadReports();
         foreach (GeofenceStateChangeReport report in reports) {
            // This loop processes a report for each Geofence object that changed
            // Each report includes the Geofence object affected, its position,
            // the NewState of the Geofence (Entered or Exited), and the reason why
            // the report was generated (Used or Expired):
            Geofence geofence = report.Geofence;                  // The Geofence object affected
            Geoposition pos = report.Geoposition;                 // The Geofence object's position
            GeofenceState state = report.NewState;                // Entered or Exited
            GeofenceRemovalReason reason = report.RemovalReason;  // Used or Expired
            // TODO: Process the Geofence object affected here...
         }
      }
   }
}


namespace Wintellect.BackgroundTasks {
   public sealed class NetworkIOTask : IBackgroundTask {
      public void Run(IBackgroundTaskInstance taskInstance) {
         var cts = new CancellationTokenSource();
         taskInstance.Canceled += (IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason) => {
            // TODO: Execute code to cleanup task if it is canceled before running to completion...
            // NOTE: If this code takes more than 5 seconds to execute, the process is killed
            cts.Cancel();
         };
         //BackgroundTaskDeferral d = taskInstance.GetDeferral();
         cts.Cancel();
         try {
            HttpResponseMessage response = new HttpClient().GetAsync(new Uri("http://Wintellect.com/")).AsTask(cts.Token).GetAwaiter().GetResult();
            String result = response.Content.ReadAsStringAsync().AsTask(cts.Token).GetAwaiter().GetResult();
         }
         catch (TaskCanceledException ex) {
            var m = ex.Message;
         }
         finally {
            //d.Complete();
         }
      }
   }
}