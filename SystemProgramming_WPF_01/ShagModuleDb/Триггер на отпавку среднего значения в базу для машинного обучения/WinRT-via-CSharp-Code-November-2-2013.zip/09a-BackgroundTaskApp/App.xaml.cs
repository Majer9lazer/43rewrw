﻿/*
System: Wintellect.BackgroundTasks.ChannelUpdateMaintenanceTask
Push: Wintellect.BackgroundTasks.PushNotificationTask
System: Wintellect.BackgroundTasks.SystemTriggerTask
*/
/******************************************************************************
Module:  App.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace BackgroundTaskApp {
   sealed partial class App : Application {
      public App() {
         this.InitializeComponent();
      }

      protected override async void OnLaunched(LaunchActivatedEventArgs args) {
         if (args.Arguments == "GotPayload") {
            await new MessageDialog(
               (String) ApplicationData.Current.LocalSettings.Values["PushPayload"],
               "App activated due to payload toast").ShowAsync();
            Debugger.Break();
         }

         Frame rootFrame = Window.Current.Content as Frame;

         // Don't repeat app initialization when Window already has content, just activate window
         if (rootFrame == null) {
            // Create a Frame to act as the navigation context and navigate to the first page
            rootFrame = new Frame();

            if (args.PreviousExecutionState == ApplicationExecutionState.Terminated) {
               //TODO: Load state from previously suspended application
            }

            // Place the frame in the current Window
            Window.Current.Content = rootFrame;
         }

         if (rootFrame.Content == null) {
            // When navigation stack isn't restored, navigate to 1st page
            if (!rootFrame.Navigate(typeof(BackgroundTaskPage), args.Arguments)) {
               throw new Exception("Failed to create initial page");
            }
         }
         // Ensure current window is active
         Window.Current.Activate();
      }
   }
}