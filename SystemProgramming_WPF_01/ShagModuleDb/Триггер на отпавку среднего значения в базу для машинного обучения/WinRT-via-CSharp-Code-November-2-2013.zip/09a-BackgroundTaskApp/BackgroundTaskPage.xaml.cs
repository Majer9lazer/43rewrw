﻿/******************************************************************************
Module:  BackgroundTaskPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Devices.Geolocation;
using Windows.Devices.Geolocation.Geofencing;
using Windows.Storage;
using Windows.UI.Notifications;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;
using Wintellect.BackgroundTasks;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.BackgroundTasks;
using Wintellect.WinRT.DemoSpecific;
using Wintellect.WinRT.Notifications;
using Wintellect.WinRT.PushNotifications;

namespace BackgroundTaskApp {
   public sealed partial class BackgroundTaskPage : Page {
      public BackgroundTaskPage() {
         this.InitializeComponent();
         // Update badge on lock screen
         BadgeUpdateManager.CreateBadgeUpdaterForApplication().Clear();
         m_txtBackgroundAccessStatus.Text = BackgroundExecutionManager.GetAccessStatus().ToString();

         // Make sure we have a channel for push (obtained asynchronously)
         Wintellect.BackgroundTasks.ChannelUpdateMaintenanceTask.CreateChannelAsync().Forget();
      }

      protected override void OnNavigatedTo(NavigationEventArgs e) {
         PrepareBackgroundTasks();
      }

      private void Log(String format, params Object[] args) {
         this.RunOnGui(() => {
            m_lvOutput.Items.Insert(0, String.Format(format, args));

            // Update badge on lock screen
            BadgeUpdateManager.CreateBadgeUpdaterForApplication().Update(new BadgeNotification(
               new BadgeTemplate(m_lvOutput.Items.Count)));
         });
      }

      private void PrepareBackgroundTasks() {
         Debugger.Break();
         //BackgroundTaskRegistration.AllTasks.UnregisterAll();
         List<IBackgroundTaskRegistration> registeredTasks =
            BackgroundTaskRegistration.AllTasks.Select(kvp => kvp.Value).ToList();

         foreach (SystemTriggerType stt in Enum.GetValues(typeof(SystemTriggerType))) {
            if (stt == SystemTriggerType.Invalid) continue;
            String taskName = typeof(SystemTrigger).Name + "-" + stt.ToString();
            if (registeredTasks.Exists(bt => bt.Name == taskName)) continue;  // Already registered

            BackgroundTaskBuilder btb = new BackgroundTaskBuilder {
               Name = taskName,
               TaskEntryPoint = typeof(Wintellect.BackgroundTasks.SystemTriggerTask).FullName,
               CancelOnConditionLoss = true
            };
            btb.SetTrigger(new SystemTrigger(stt, false));

            // Add 0 or more conditions that must be true before triggering
            // User(Not)Present, Internet(Not)Available, SessionConnected/SessionDisconnected
            // btb.AddCondition(new SystemCondition(SystemConditionType.UserPresent));
            registeredTasks.Add(btb.Register());
         }

         registeredTasks.Register("Maintenance", typeof(SystemTriggerTask), new MaintenanceTrigger(15, false));
         registeredTasks.Register("Push notification", typeof(PushNotificationTask), new PushNotificationTrigger());
         //registeredTasks.Register("Geofence location update", typeof(GeofenceLocationTask), new LocationTrigger(LocationTriggerType.Geofence));
         registeredTasks.Register("Channel update", typeof(ChannelUpdateMaintenanceTask), new MaintenanceTrigger((UInt32)TimeSpan.FromDays(10).TotalMinutes, false), 
            true, new SystemCondition(SystemConditionType.InternetAvailable));

         // Register progress/completed handlers for all tasks
         foreach (IBackgroundTaskRegistration regTask in registeredTasks) {
            regTask.Progress += BTProgress;
            regTask.Completed += BTCompleted;
         }
      }

      void BTProgress(BackgroundTaskRegistration sender, BackgroundTaskProgressEventArgs args) {
         // Called by non-UI thread when app running/resumed; not called if terminated         
         Log("{0}% {1}", args.Progress, sender.Name);
      }

      void BTCompleted(BackgroundTaskRegistration sender, BackgroundTaskCompletedEventArgs args) {
         // Called by non-UI thread when app running/resumed; not called if terminated
         try {
            args.CheckResult();
            Log("{1}-Complete: {0}", sender.Name, DateTimeOffset.Now.ToString("t"));

            if (sender.Name == typeof(PushNotificationTrigger).Name) {
               // App can access data from background task via AppData
               String payload = (String)ApplicationData.Current.LocalSettings.Values["PushPayload"];
               Log("{0}: {1}", sender.Name, payload);
            }

            if (sender.Name.EndsWith(SystemTriggerType.LockScreenApplicationAdded.ToString()) ||
                sender.Name.EndsWith(SystemTriggerType.LockScreenApplicationRemoved.ToString())) {
               this.RunOnGui(() => m_txtBackgroundAccessStatus.Text = BackgroundExecutionManager.GetAccessStatus().ToString());
            }
         }
         catch (Exception ex) {
            Log("{0}: {1}", ex.GetType().ToString(), sender.Name);
         }
      }

      private async void RequestLockScreenAccess(object sender, RoutedEventArgs e) {
         try {
            // http://msdn.microsoft.com/en-us/library/windows/apps/hh700416.aspx
            // RequestAccessAsync & RemoveAccess require ControlChannelTrigger, TimeTrigger, or PushNotificationTrigger:            
            // NOTE: The line below throws when stepping in the debugger!!!!!!
            BackgroundAccessStatus bas = await BackgroundExecutionManager.RequestAccessAsync();
            m_txtBackgroundAccessStatus.Text = bas.ToString();
            switch (bas) {
               case BackgroundAccessStatus.Unspecified:
                  // The user never specified for our app whether they want it on the lock screen or not
                  break;
               case BackgroundAccessStatus.AllowedMayUseActiveRealTimeConnectivity:
                  // The user accepted our app on lock screen & we can use PushNotificationTrigger
                  break;
               case BackgroundAccessStatus.AllowedWithAlwaysOnRealTimeConnectivity:
                  // The user accepted our app on lock screen & we can use ControlChannelTrigger
                  break;
               case BackgroundAccessStatus.Denied:
                  // The user explicitly denied allowing our app on the lock screen
                  break;
            }
         }
         catch (Exception) {
         }
      }

      private void RemoveLockScreenAccess(object sender, RoutedEventArgs e) {
         BackgroundExecutionManager.RemoveAccess();
         m_txtBackgroundAccessStatus.Text = BackgroundExecutionManager.GetAccessStatus().ToString();
      }

      private async void PushStringPayload(object sender, RoutedEventArgs e) {
         if (BackgroundExecutionManager.GetAccessStatus() != BackgroundAccessStatus.AllowedMayUseActiveRealTimeConnectivity) {
            new MessageDialog("Can't push string notification unless app is on lock screen").ShowAsync().Forget();
            return;
         }
         Debugger.Break();
         // Wait 5 seconds to push so we can lock the machine to see toast on Lock Screen
         await Task.Delay(TimeSpan.FromSeconds(5));
         var wns = new AppServerWns(WinRTSecrets.BackgroundTasksWnsSecurityId, WinRTSecrets.BackgroundTasksWnsSecret);
         wns.RequestHeaders.RequestForStatus = true;
         wns.RequestHeaders.WnsType = WnsType.Raw; // Note RAW here!
         HttpResponseMessage response = await wns.PushAsync("Sent string data " + DateTimeOffset.Now,
            Wintellect.BackgroundTasks.ChannelUpdateMaintenanceTask.GetChannelUri());
         WnsResponseHeaders wnsResponseHeaders = response.GetWnsResponseHeaders();
      }

      private void ClearBackgroundTasks(object sender, RoutedEventArgs e) {
         foreach (KeyValuePair<Guid, IBackgroundTaskRegistration> bt in BackgroundTaskRegistration.AllTasks) {
            bt.Value.Unregister(true);
         }
      }

      private async Task InitializeGeofenceMonitorAsync() {
         Debugger.Break();

         // Get a reference to the app's singleton GeofenceMonitor object
         GeofenceMonitor gm = GeofenceMonitor.Current;
         gm.Geofences.Clear();   // Erase all its Geofence objects

         // Get the PC's current location (requires Location capability) 
         Geoposition geoposition = await new Geolocator().GetGeopositionAsync();

         // Register a Geofence whose state changes whenever the PC goes within 1 meter of it
         Geofence gf = new Geofence("InitialPCLocation",                // Geofence Id
            new Geocircle(geoposition.Coordinate.Point.Position, 1),    // Point & radius
            MonitoredGeofenceStates.Entered | MonitoredGeofenceStates.Exited, // When the task should run
            false,                     // The task is not 1 time
            TimeSpan.FromSeconds(5),   // Dwell time
            DateTimeOffset.UtcNow,     // Start time
            TimeSpan.FromHours(1));    // Duration
         gm.Geofences.Add(gf);  // Add the Geofence object to the GeofenceMonitor's collection

         gm.GeofenceStateChanged += (GeofenceMonitor s, object args) => {
            GeofenceStateChangeReport[] reports = s.ReadReports().ToArray();
            var c = reports.Count();
         };
      }

      private async void Geolocation(object sender, RoutedEventArgs e) {
         await InitializeGeofenceMonitorAsync();
      }
   }
}