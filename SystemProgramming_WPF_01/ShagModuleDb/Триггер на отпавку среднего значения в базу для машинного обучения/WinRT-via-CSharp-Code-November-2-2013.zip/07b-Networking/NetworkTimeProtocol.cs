﻿/******************************************************************************
Module:  NetworkTimeProtocol.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

using System;

namespace Wintellect.NetworkTimeProtocol {
   public enum NtpLeapIndicator {
      NoWarning = 0,
      LastMinuteHas61Seconds = 1,
      LastMinuteHas59Seconds = 2,
      Alarm = 3
   }

   public enum NtpMode {
      Reserved = 0,
      SymmetricActive = 1,
      SymmetricPassive = 2,
      Client = 3,
      Server = 4,
      Broadcast = 5,
      NtpControlMessage = 6,
      Private = 7
   }

   public enum NtpStratum {
      Unspecified = 0,
      PrimaryReference = 1,
      SecondaryReference = 2, // or greater
   }

   public sealed class NetworkTimeProtocolInfo {
      public const String ServiceName = "ntp";
      private const Int32 DataLength = 48;
      private static readonly DateTimeOffset s_epoch = new DateTimeOffset(1900, 1, 1, 0, 0, 0, TimeSpan.Zero);

      public static Byte[] GetRequestData(DateTimeOffset transmitTimestamp) {
         Byte[] ntp = new Byte[DataLength];
         ntp[0] = 0x1b; // VN=4, Mode=3

         // Set the TransmitTimestampSeconds by reversing its bytes
         var seconds = BitConverter.GetBytes((UInt32)(transmitTimestamp - s_epoch).TotalSeconds);
         for (Int32 n = 0; n < 4; n++) ntp[7 * 4 + n] = seconds[3 - n];
         return ntp;
      }

      private static UInt32 GetUInt32(Byte[] ntp, ref Int32 offset) {
         UInt32 n = 0;
         for (Int32 i = 0; i < 4; i++) n = (n << 8) | ntp[offset++];
         return n;
      }

      public NetworkTimeProtocolInfo(Byte[] ntp) {
         Int32 offset = 0;
         Byte b = ntp[offset++];
         Mode = (NtpMode)(b & 0x7);                  // Bits 0-2
         VersionNumber = (Byte)((b & 0x38) >> 3); // Bits 3-5
         LeapIndicator = (NtpLeapIndicator)(b >> 6); // Bits 6-7

         b = ntp[offset++];
         if (b == 0) Stratum = NtpStratum.Unspecified;
         else if (b == 1) Stratum = NtpStratum.PrimaryReference;
         else Stratum = NtpStratum.SecondaryReference;

         PollIntervalInSeconds = (UInt32)Math.Round(Math.Pow(2, ntp[offset++]));
         PrecisionInSeconds = (Int32)Math.Pow(2, ntp[offset++]);
         RootDelayInSeconds = GetUInt32(ntp, ref offset) / 0x10000F;
         RootDispersionInSeconds = GetUInt32(ntp, ref offset) / 0x10000F;

         ReferenceClockId = String.Empty;
         Char[] chars = new Char[] { 
            (Char) ntp[offset++], (Char) ntp[offset++], 
            (Char) ntp[offset++], (Char) ntp[offset++]
         };
         switch (Stratum) {
            case NtpStratum.Unspecified:
            case NtpStratum.PrimaryReference:
               ReferenceClockId = new String(chars);
               break;
            case NtpStratum.SecondaryReference:
               ReferenceClockId = String.Join(".", chars);
               break;
         }

         ReferenceTimestamp = s_epoch.AddSeconds(GetUInt32(ntp, ref offset));
         GetUInt32(ntp, ref offset);   // fraction
         OriginateTimestamp = s_epoch.AddSeconds(GetUInt32(ntp, ref offset));
         GetUInt32(ntp, ref offset);   // fraction
         ReceiveTimestamp = s_epoch.AddSeconds(GetUInt32(ntp, ref offset));
         GetUInt32(ntp, ref offset);   // fraction
         TransmitTimestamp = s_epoch.AddSeconds(GetUInt32(ntp, ref offset));
         GetUInt32(ntp, ref offset);   // fraction
      }

      public NtpLeapIndicator LeapIndicator { get; private set; }
      public Byte VersionNumber { get; private set; }
      public NtpMode Mode { get; private set; }
      public NtpStratum Stratum { get; private set; }
      public UInt32 PollIntervalInSeconds { get; private set; }
      public Double PrecisionInSeconds { get; private set; }
      public Double RootDelayInSeconds { get; private set; }
      public Double RootDispersionInSeconds { get; private set; }
      public String ReferenceClockId { get; private set; }
      public DateTimeOffset ReferenceTimestamp { get; private set; }
      public DateTimeOffset OriginateTimestamp { get; private set; }
      public DateTimeOffset ReceiveTimestamp { get; private set; }
      public DateTimeOffset TransmitTimestamp { get; private set; }
   }
   // NTP header (RFC 2030):
   //                       1                   2                   3
   //   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |LI | VN  |Mode |    Stratum    |     Poll      |   Precision   |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                          Root Delay                           |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                       Root Dispersion                         |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                     Reference Identifier                      |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                   Reference Timestamp (64)                    |
   //  |                                                               |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                   Originate Timestamp (64)                    |
   //  |                                                               |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                    Receive Timestamp (64)                     |
   //  |                                                               |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   //  |                    Transmit Timestamp (64)                    |
   //  |                                                               |
   //  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
}

#if false
   [StructLayout(LayoutKind.Sequential, Pack = 1)]
   public struct NetworkTimeProtocolRaw {
      public Byte m_LIVNMode;
      public Byte m_Stratum;
      public Byte m_Poll;
      public Byte m_Precision;
      public UInt32 m_RootDelay;
      public UInt32 m_RootDispersion;
      public Byte m_ReferenceIdentifier0, m_ReferenceIdentifier1, m_ReferenceIdentifier2, m_ReferenceIdentifier3;
      public UInt32 m_ReferenceTimestampSeconds;
      public UInt32 m_ReferenceTimestampFraction;
      public UInt32 m_OriginateTimestampSeconds;
      public UInt32 m_OriginateTimestampFraction;
      public UInt32 m_ReceiveTimestampSeconds;
      public UInt32 m_ReceiveTimestampFraction;
      public UInt32 m_TransmitTimestampSeconds;
      public UInt32 m_TransmitTimestampFraction;

      public NetworkTimeProtocolRaw(Byte[] raw) {
         this = new NetworkTimeProtocolRaw();
         unsafe {
            fixed (Byte* p = &m_LIVNMode) {
               for (Int32 b = 0; b < 48; b++) p[b] = raw[b];
            }
         }
         ReverseBytes(ref m_RootDelay);
         ReverseBytes(ref m_RootDispersion);
         ReverseBytes(ref m_ReferenceTimestampSeconds);
         ReverseBytes(ref m_ReferenceTimestampFraction);
         ReverseBytes(ref m_OriginateTimestampSeconds);
         ReverseBytes(ref m_OriginateTimestampFraction);
         ReverseBytes(ref m_ReceiveTimestampSeconds);
         ReverseBytes(ref m_ReceiveTimestampFraction);
         ReverseBytes(ref m_TransmitTimestampSeconds);
         ReverseBytes(ref m_TransmitTimestampFraction);
      }

      public NetworkTimeProtocolRaw(DateTimeOffset transmitTimestamp) {
         this = new NetworkTimeProtocolRaw();
         m_LIVNMode = 0x1B;   // VN=4, Mode=3
         DateTimeOffset epoch = new DateTimeOffset(1900, 1, 1, 0, 0, 0, TimeSpan.Zero);    // January 1, 1900 12:00 AM
         m_TransmitTimestampSeconds = (UInt32)(transmitTimestamp - epoch).TotalSeconds;
         ReverseBytes(ref m_TransmitTimestampSeconds);
      }

      public Byte[] ToBytes() {
         var raw = new Byte[48];
         unsafe {
            fixed (Byte* p = &m_LIVNMode) {
               for (Int32 b = 0; b < raw.Length; b++) raw[b] = p[b];
            }
         }
         return raw;
      }

      private static void ReverseBytes(ref UInt32 data) {
         var bytes = BitConverter.GetBytes(data);
         Array.Reverse(bytes);
         data = BitConverter.ToUInt32(bytes, 0);
      }
   }
#endif