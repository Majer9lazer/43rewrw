﻿using System;
using System.Net;
using System.Net.Sockets;
using Wintellect.NetworkTimeProtocol;

public static class program {
   static void Main() {
      try {
         IPHostEntry hostadd = Dns.GetHostEntry("time.nist.gov");
         IPEndPoint EPhost = new IPEndPoint(hostadd.AddressList[0], 123);
         UdpClient socket = new UdpClient();
         socket.Connect(EPhost);
         var ntp = NetworkTimeProtocolInfo.GetRequestData(DateTimeOffset.Now);
         socket.Send(ntp, ntp.Length);
         ntp = socket.Receive(ref EPhost);
         var info = new NetworkTimeProtocolInfo(ntp);
      }
      catch (SocketException e) {
         throw new Exception(e.Message);
      }
   }
}