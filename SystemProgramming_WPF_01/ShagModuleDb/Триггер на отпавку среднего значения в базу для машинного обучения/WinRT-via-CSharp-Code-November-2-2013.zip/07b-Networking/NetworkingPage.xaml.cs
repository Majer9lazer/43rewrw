﻿/******************************************************************************
Module:  NetworkingPage.xaml.cs
Notices: Copyright (c) by Jeffrey Richter and Wintellect
******************************************************************************/

// NOTE: InternetClientServer NOT required because this app talks to itself
using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Networking;
using Windows.Networking.Connectivity;
using Windows.Networking.Proximity;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;
using Windows.System.UserProfile;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;
using Windows.Web.Http.Filters;
using Wintellect;
using Wintellect.NetworkTimeProtocol;
using Wintellect.WinRT.AppAids;
using Wintellect.WinRT.Networking;

namespace Networking {
   public sealed partial class NetworkingPage : Page {
      private Boolean m_userOptIn = false;  // Changed via some UI
      private readonly SemaphoreSlim m_step = new SemaphoreSlim(0);

      public NetworkingPage() {
         this.InitializeComponent();
         ConnectionProfile cp = NetworkInformation.GetInternetConnectionProfile();
         UInt64 mts = cp.GetMaxTransferSizeInMegabytes(m_userOptIn, NetworkConnectivityLevel.InternetAccess);

         NetworkStatusChanged(null);   // Force an initial update
         NetworkInformation.NetworkStatusChanged += NetworkStatusChanged;  // NOTE: Called by non-GUI thread!
      }

      protected override void OnNavigatedTo(NavigationEventArgs e) { }

      #region Connection Profile
      private void NetworkStatusChanged(Object sender) {
         // NOTE: Called by non-GUI thread!
         this.RunOnGui(() => {
            ConnectionProfile cp = NetworkInformation.GetInternetConnectionProfile();
            m_txtAppNetworkBehavior.Text = String.Format("Max transfer size={0:N0} MB", cp.GetMaxTransferSizeInMegabytes(m_userOptIn, NetworkConnectivityLevel.InternetAccess));
            m_txtConnectionStatus.Text = cp.GetConnectionProfileString();
         });
      }
      #endregion

      #region HttpClient
      private async void HttpClientDemoAsync(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // Simple:
         using (HttpClient client = new HttpClient()) {
            String html = await client.GetStringAsync(new Uri("http://Wintellect.com/"));
         }

         // More involved:
         using (HttpClient client = new HttpClient()) {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, new Uri("https://httpbin.org/post")) { Content = new HttpStringContent("Some test data", UnicodeEncoding.Utf8, "text/plain") };
            HttpResponseMessage response = await client.SendRequestAsync(request);
            String json = await response.Content.ReadAsStringAsync();
         }

         // Cache:
         using (HttpBaseProtocolFilter filter = new HttpBaseProtocolFilter())
         using (HttpClient client = new HttpClient(filter)) {
            filter.CacheControl.ReadBehavior = HttpCacheReadBehavior.MostRecent; // Try to get most recent data from server (or cache)
            filter.CacheControl.WriteBehavior = HttpCacheWriteBehavior.NoCache;  // If we get it from server, don't store it in cache
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, new Uri("http://Wintellect.com/"));
            HttpResponseMessage response = await client.SendRequestAsync(request);
            switch (response.Source) {
               case HttpResponseMessageSource.Cache:     // Data came from cache
                  break;
               case HttpResponseMessageSource.Network:   // Data came from server
                  break;
            }
         }

         // Cookies:
         using (HttpBaseProtocolFilter filter = new HttpBaseProtocolFilter())
         using (HttpClient client = new HttpClient(filter)) {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, new Uri("http://Bing.com/"));
            HttpResponseMessage response = await client.SendRequestAsync(request);

            // See the returned cookies and delete them
            foreach (HttpCookie cookie in filter.CookieManager.GetCookies(request.RequestUri)) {
               String cookieInfo = String.Format("Domain={0}, Expires={1}, HttpOnly={2}, Name={3}, Path={4}, Secure={5}, Value={6}",
                  cookie.Domain, cookie.Expires, cookie.HttpOnly, cookie.Name, cookie.Path, cookie.Secure, cookie.Value);
               // HttpCookieManager also supports: SetCookie and DeleteCookie
            }
         }

         // Custom Filters:
         using (RequestDurationFilter filter = new RequestDurationFilter(new HttpBaseProtocolFilter()))
         using (HttpClient client = new HttpClient(filter)) {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, new Uri("http://Wintellect.com/"));
            HttpResponseMessage response = await client.SendRequestAsync(request);
            String s = String.Format("Request took {0}ms", filter.RequestDuration.TotalMilliseconds);
         }
      }

      internal sealed class RequestDurationFilter : IHttpFilter {
         private readonly IHttpFilter m_nextFilter;
         public TimeSpan RequestDuration { get; private set; }

         public RequestDurationFilter(IHttpFilter nextFilter) {
            if (nextFilter == null) throw new ArgumentException("nextFilter");
            m_nextFilter = nextFilter;
         }
         public void Dispose() { m_nextFilter.Dispose(); }

         public IAsyncOperationWithProgress<HttpResponseMessage, HttpProgress> SendRequestAsync(HttpRequestMessage request) {
            return AsyncInfo.Run<HttpResponseMessage, HttpProgress>(async (cancellationToken, progress) => {
               RequestDuration = TimeSpan.Zero;
               Stopwatch time = Stopwatch.StartNew(); // Get the current time

               HttpResponseMessage response =
                  await m_nextFilter.SendRequestAsync(request).AsTask(cancellationToken, progress);
               RequestDuration = time.Elapsed;        // Set the request's duration
               cancellationToken.ThrowIfCancellationRequested();
               return response;
            });
         }
      }
      #endregion

      #region HostName
      private void HostNameDemo(object sender, RoutedEventArgs e) {
         Debugger.Break();
         // The top-level domain for the Russian Federation is "xn--p1ai" (in ASCII) and "рф" (in Cyrillic)
         // For more information, see http://en.wikipedia.org/wiki/.%D1%80%D1%84)
         String kremlinAscii = "президент.xn--p1ai";
         HostName kremlin = new HostName(kremlinAscii);
         String display = kremlin.DisplayName;	    // "президент.рф"
         String canonical = kremlin.CanonicalName;  // "президент.рф"

         // Compares canonical names:
         Boolean same = kremlin.IsEqual(new HostName("президент.рф")); // true
         Int32 order = HostName.Compare(kremlinAscii, "президент.рф"); // 0

         HostName hostname = new HostName("0::1");
         same = hostname.IsEqual(new HostName("0:0::1"));            // true

         hostname = new HostName("WINTELLECT.COM");
         same = hostname.IsEqual(new HostName("Wintellect.com"));    // true
      }
      #endregion

      #region StreamSocketListener & StreamSocket
      private StreamSocketListener m_tcpService;
      private const String c_tcpServiceName = "8080";

      private async Task StartTcpServiceAsync() {
         if (m_tcpService != null) return;
         m_tcpService = new StreamSocketListener();
         m_tcpService.ConnectionReceived += OnClientConnectionReceivedAsync; // Register handler before calling Bind*Async
         await m_tcpService.BindServiceNameAsync(c_tcpServiceName);     // Listen on desired port 
      }

      private async void OnClientConnectionReceivedAsync(StreamSocketListener listener, 
         StreamSocketListenerConnectionReceivedEventArgs e) {

         Debugger.Break();
         using (StreamSocket client = e.Socket)
         using (DataReader dr = new DataReader(e.Socket.InputStream))
         using (DataWriter dw = new DataWriter(e.Socket.OutputStream)) {
            // Read request header from client:
            await dr.LoadAsync(sizeof(Int32));
            UInt32 messageLength = dr.ReadUInt32();

            // Read request data from client:
            await dr.LoadAsync(messageLength);
            Byte[] bytes = new Byte[messageLength];
            dr.ReadBytes(bytes);

            Int32 sum = bytes.Sum(number => number);  // Calculate response

            // Send response to client:
            dw.WriteInt32(sum);
            await dw.StoreAsync();  // Required to send the response back to the client
         }
      }

      private async void TcpClientAsync(object sender, RoutedEventArgs e) {
         Debugger.Break();
         await StartTcpServiceAsync();

         using (StreamSocket socket = new StreamSocket())
         using (DataWriter dw = new DataWriter(socket.OutputStream))
         using (DataReader dr = new DataReader(socket.InputStream)) {
            // Connect to the remote server:
            await socket.ConnectAsync(new HostName("localhost"), c_tcpServiceName);

            // Send message header (UInt32) and message bytes to server:
            Byte[] messageData = new Byte[] { 1, 2 };
            dw.WriteUInt32((UInt32)messageData.Length);
            dw.WriteBytes(messageData);
            await dw.StoreAsync();

            // Read UInt32 response from server:
            await dr.LoadAsync(sizeof(Int32));
            Int32 sum = dr.ReadInt32();
         }
      }
      #endregion

      #region WebSocket
      private async void WebSocketClientAsync(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         // See http://websocket.org/echo.html
         using (StreamWebSocket socket = new StreamWebSocket()) {
            // Connect to the remote service
            await socket.ConnectAsync(new Uri("wss://echo.websocket.org/")); // use "wss" for secure WebSocket (TLS)

            // Write a UInt32 (string length) & a UTF-8 string to the service:
            using (DataWriter dw = new DataWriter(socket.OutputStream)) {
               String s = "Jeffrey";
               dw.WriteUInt32(dw.MeasureString(s));
               dw.WriteString(s);
               await dw.StoreAsync();
            }

            // The WebSocket Echo service just returns back whatever you send it.
            // Read a UInt32 (string length) & a UTF-8 string response from the service:
            using (DataReader dr = new DataReader(socket.InputStream) { InputStreamOptions = InputStreamOptions.Partial }) {
               while (dr.UnconsumedBufferLength < sizeof(UInt32)) {
                  UInt32 bytesRead = await dr.LoadAsync(1024);
               }
               UInt32 stringLen = dr.ReadUInt32();
               while (dr.UnconsumedBufferLength < stringLen) {
                  UInt32 bytesRead = await dr.LoadAsync(1024);
               }
               var s = dr.ReadString(stringLen);
            }
         }

         using (MessageWebSocket socket = new MessageWebSocket()) {
            socket.MessageReceived += OnWebSocketMessageReceived;
            await socket.ConnectAsync(new Uri("wss://echo.websocket.org/"));

            using (DataWriter dw = new DataWriter(socket.OutputStream)) {
               dw.WriteString("Jeffrey");
               await dw.StoreAsync();  // Send a "message" to the service
            }
            await m_step.WaitAsync();
         }
      }

      private void OnWebSocketMessageReceived(MessageWebSocket sender, MessageWebSocketMessageReceivedEventArgs args) {
         Debugger.Break();
         // The service responded with a "message"; read all of it as a string
         using (DataReader dr = args.GetDataReader()) {
            String s = dr.ReadString(dr.UnconsumedBufferLength);
         }
         m_step.Release();
      }
      #endregion

      #region Datagram Client & Server
      private DatagramSocket m_datagramService;
      private const String c_datagramServiceName = "12345";

      private async Task StartDatagramServiceAsync() {
         if (m_datagramService != null) return;
         m_datagramService = new DatagramSocket();
         m_datagramService.MessageReceived += OnDatagramServiceMessageReceivedAsync;
         await m_datagramService.BindServiceNameAsync(c_datagramServiceName); // Listen on desired port 
      }

      private async void OnDatagramServiceMessageReceivedAsync(DatagramSocket sender, DatagramSocketMessageReceivedEventArgs e) {
         Debugger.Break();
         // Read request from client:
         Byte[] bytes;
         using (DataReader dr = e.GetDataReader()) {
            bytes = new Byte[dr.UnconsumedBufferLength];
            dr.ReadBytes(bytes);
         }

         // Process client's request:
         Int32 sum = bytes.Sum(number => number);

         // Send response to client:
         IOutputStream outputStream = await sender.GetOutputStreamAsync(e.RemoteAddress, e.RemotePort);
         using (DataWriter dw = new DataWriter(outputStream)) {
            dw.WriteInt32(sum);
            await dw.StoreAsync();
         }
      }

      private async void DatagramClientAsync(object sender, RoutedEventArgs e) {
         Debugger.Break();
         await StartDatagramServiceAsync();

         HostName host = new HostName("localhost");

         // This pattern makes multiple requests to a single server:
         using (DatagramSocket socket = new DatagramSocket()) {
            socket.MessageReceived += OnDatagramClientMessageReceived;  // Register handler before calling ConnectAsync

            // ConnectAsync implicitly binds to a port so the server can respond
            await socket.ConnectAsync(host, c_datagramServiceName);

            // Send the 1st request:
            UInt32 bytesWritten = await socket.OutputStream.WriteAsync(new Byte[] { 1, 2 }.AsBuffer());
            await m_step.WaitAsync();

            // Send the 2nd request:
            bytesWritten = await socket.OutputStream.WriteAsync(new Byte[] { 2, 3 }.AsBuffer());
            await m_step.WaitAsync();
         }

         // This pattern makes multiple requests to different servers:
         using (DatagramSocket socket = new DatagramSocket()) {
            socket.MessageReceived += OnDatagramClientMessageReceived;  // Register handler before calling GetOutputStreamAsync

            // Send the 1st request:
            IOutputStream output = await socket.GetOutputStreamAsync(host, c_datagramServiceName);
            UInt32 bytesWritten = await output.WriteAsync(new Byte[] { 1, 2 }.AsBuffer());
            await m_step.WaitAsync();

            // Send the 2nd request:
            output = await socket.GetOutputStreamAsync(host, c_datagramServiceName);
            bytesWritten = await output.WriteAsync(new Byte[] { 2, 3 }.AsBuffer());
            await m_step.WaitAsync();
         }
      }

      private void OnDatagramClientMessageReceived(DatagramSocket sender, DatagramSocketMessageReceivedEventArgs e) {
         // NOTE: Called by non-GUI thread!
         Debugger.Break();
         using (DataReader dr = e.GetDataReader()) {
            Int32 sum = dr.ReadInt32();
         }
         m_step.Release();
      }

      private async void NtpDemoAsync() {
         using (DatagramSocket socket = new DatagramSocket()) {
            socket.MessageReceived += (s, e) => {
               Debugger.Break();
               Byte[] ntp = new Byte[48];
               e.GetDataReader().ReadBytes(ntp);
               NetworkTimeProtocolInfo info = new NetworkTimeProtocolInfo(ntp);
               DateTimeOffset utc = info.ReferenceTimestamp;
               m_step.Release();
            };
            Byte[] msg = NetworkTimeProtocolInfo.GetRequestData(DateTimeOffset.Now);
            // For service name, see %WinDir%\System32\drivers\etc\Services
            IOutputStream output = await socket.GetOutputStreamAsync(new HostName("time.windows.com"), NetworkTimeProtocolInfo.ServiceName);
            UInt32 bytesWritten = await output.WriteAsync(msg.AsBuffer());
            await m_step.WaitAsync();
         }
      }
      #endregion

      #region Datagram Multicast
      // http://channel9.msdn.com/posts/Multicast-LAN-Discovery
      private static readonly HostName s_multicastHostName = new HostName("224.168.100.2");  // 224.0.0.0 - 239.255.255.255
      private const String c_multicastServiceName = "11000";
      private DatagramSocket m_multicastListener;

      private async void MulticastListenAsync(object sender, RoutedEventArgs e) {
         if (m_btnMulticastListen.IsChecked.Value) {
            m_multicastListener = new DatagramSocket();
            // Register handler before calling BindXxxAsync
            m_multicastListener.MessageReceived += OnMulticastListenerMessageReceived;
            await m_multicastListener.BindServiceNameAsync(c_multicastServiceName);
            m_multicastListener.JoinMulticastGroup(s_multicastHostName);
         } else {
            m_multicastListener.Dispose();
         }
      }

      private void OnMulticastListenerMessageReceived(DatagramSocket sender, DatagramSocketMessageReceivedEventArgs args) {
         using (DataReader reader = args.GetDataReader()) {
            String s = reader.ReadString(reader.UnconsumedBufferLength);
            this.RunOnGui(() => {
               m_txtMulticastOutput.Text = DateTime.Now.ToString() + ", From: " + args.RemoteAddress.DisplayName + ", " + s;
            });
         }
      }

      private async void MulticastSendAsync(object sender, RoutedEventArgs e) {
         Byte[] data = "A multicast datagram".Encode();
         DatagramSocket multicastSender = new DatagramSocket();
         while (m_btnMulticastSend.IsChecked.Value) {
            IOutputStream os = await multicastSender.GetOutputStreamAsync(s_multicastHostName, c_multicastServiceName);
            using (DataWriter writer = new DataWriter(os)) {
               writer.WriteBytes(data);
               await writer.StoreAsync();
               await Task.Delay(1000);
            }
         }
      }

#if false
      private async void FindOtherPlayersAsync() {   // Sender
         // Prepare socket that plays respond back to
         DatagramSocket socket = new DatagramSocket();
         socket.MessageReceived += MulticastReaderReceiveIPv4;
         await socket.BindServiceNameAsync("0");   // Use any free port
         String ourServicePort = socket.Information.LocalPort; // We'll send our port in a packet to the players

         // Now, look for players:
         //multicastReaderForReceiverIPv4 = new CommandReader("(mcastReceiver)", socket, client.doCommand.bind(client));
         DatagramSocket multicastSenderIPv4 = new DatagramSocket();
         multicastSenderIPv4.MessageReceived += MulticastReaderReceiveIPv4;
         await socket.ConnectAsync(s_multicastHostName, c_multicastServiceName);
         // Tell players where they can respond to us (ourServicePort):
         using (DataWriter dw = new DataWriter(socket.OutputStream)) {
            dw.WriteInt32(1234);
            await dw.StoreAsync();
         }
      }
#endif
      #endregion

      #region Proximity
      private void AppendMsg(String format, params Object[] args) {
         this.RunOnGui(() => {
            var msg = String.Format(format, args);
            //if (overwrite) MessageBlock.Text = msg; else MessageBlock.Text += msg;
         });
      }

      private async void OnAdvertisePeerAsync(Object sender, RoutedEventArgs args) {
         if (!m_tglShowPeer.IsOn) {
            PeerFinder.Stop();
            PeerFinder.TriggeredConnectionStateChanged -= OnTriggeredConnectionStateChanged;
            PeerFinder.ConnectionRequested -= OnConnectionRequested;
#if false
            // How to have a Windows Store app find a Windows Phone app
            PeerFinder.AlternateIdentities.Add("WindowsPhone", "{1c6379c1-9d5e-4254-8f4c-be7ea24057d1}");   // Adds a Windows Phone 8 app id as an alternate identity in your Windows 8 app. 
            
            // How to have a Windows Phone app find a Windows Store
            var id = Package.Current.Id.FamilyName + "!" + "App";  // "App" is from Id attribute of the Application element in the package manifest 
            //PeerFinder.Add("Windows", id);
#endif
            return;
         }

         AppendMsg("Supported types: " + PeerFinder.SupportedDiscoveryTypes);
         if (PeerFinder.SupportedDiscoveryTypes == PeerDiscoveryTypes.None) {
            m_tglShowPeer.IsEnabled = false;
            await new MessageDialog("This machine cannot connect to peers.").ShowAsync();
            return;
         }

         //PeerFinder.DisplayName = await UserInformation.GetDisplayNameAsync();   // Defaults to machine name
         if (PeerFinder.SupportedDiscoveryTypes.HasFlag(PeerDiscoveryTypes.Triggered)) {
            PeerFinder.TriggeredConnectionStateChanged += OnTriggeredConnectionStateChanged;
            AppendMsg("You can tap to connect a peer device that is also advertising for a connection.\n");
         }
         PeerFinder.ConnectionRequested += OnConnectionRequested;
         PeerFinder.Start();
         AppendMsg("Advertising: " + PeerFinder.DisplayName);
         // NOTE: If launch activated via tap, LaunchActivatedEventArgs.Arguments == "Windows.Networking.Proximity.PeerFinder:StreamSocket"
      }

      private void OnTriggeredConnectionStateChanged(object sender, TriggeredConnectionStateChangedEventArgs e) {
         // NOTE: Called on non-GUI thread!
         switch (e.State) {
            case TriggeredConnectState.PeerFound:
               // Indicate to users the tap is complete & they can pull there devices away.
               AppendMsg("Peer found. You may now pull your devices out of proximity.\n");
               break;
            case TriggeredConnectState.Failed:
               // Socket connect failed
               break;
            case TriggeredConnectState.Completed:
               // Grab the socket that just connected.
               // Start reading on the socket e.Socket
               StreamSocket socket = e.Socket;
               if (HostName.Compare(socket.Information.LocalAddress.CanonicalName, socket.Information.RemoteHostName.CanonicalName) < 0) {
                  // Lower name is client; higher name is server
                  // onStreamSocketConnected();
               } else {
                  // onStreamSocketAccepted();
               }
               AppendMsg("Connected. You may now send a message.\n");
               //SendMessage(e.Socket);
               break;
         }
      }

      private async void OnFindPeersAsync(object sender, RoutedEventArgs e) {
         if (PeerFinder.SupportedDiscoveryTypes == PeerDiscoveryTypes.None) {
            AppendMsg("No supported discovery types.");
            return;
         }

         try {
            PeerInformation[] peers = (await PeerFinder.FindAllPeersAsync()).ToArray();
            if (peers.Length > 0) {
               // Connect to first peer found - example only.
               // In your app, provide the user with a list of available peers.
               ConnectToPeerAsync(peers[0]);
            }
         }
         catch (Exception err) {
            AppendMsg("Error finding peers: " + err.Message);
         }
      }

      // Handle external connection requests.
      private PeerInformation m_peer;

      private void OnConnectionRequested(object sender, ConnectionRequestedEventArgs e) {
         AppendMsg("Connection requested by " + m_peer.DisplayName + ". " + "Click 'Accept Connection' to connect.");
         m_peer = e.PeerInformation;
      }

      private void AcceptConnectionButton_Click(object sender, RoutedEventArgs e) {
         if (m_peer == null) {
            AppendMsg("No peer connection has been requested.");
            return;
         }

         ConnectToPeerAsync(m_peer);
      }

      private async void ConnectToPeerAsync(PeerInformation peer) {
         AppendMsg("Connecting to peer: " + peer.DisplayName);
         try {
            StreamSocket socket = await PeerFinder.ConnectAsync(peer);

            AppendMsg("Connection successful. You may now send messages.\n");
            //SendMessage(socket);
         }
         catch (Exception err) {
            AppendMsg("Connection failed: " + err.Message);
         }
      }



      private ProximityDevice m_proximityDevice;
      private void InitProximityDevice() {
         if (m_proximityDevice != null) return;
         m_proximityDevice = ProximityDevice.GetDefault();
         m_proximityDevice.DeviceArrived += sender => { };
         m_proximityDevice.DeviceDeparted += sender => { };
      }

      private async void ProximityAsync(Object sender, RoutedEventArgs e) {
         Debugger.Break();
         String supportedTypes = PeerFinder.SupportedDiscoveryTypes.ToString();
         if (PeerFinder.SupportedDiscoveryTypes == PeerDiscoveryTypes.None) {
            await new MessageDialog("This machine cannot connect to peers.").ShowAsync();
            return;
         }

         PeerFinder.DisplayName = await UserInformation.GetDisplayNameAsync();   // Default to machine name
         PeerFinder.AllowBluetooth = PeerFinder.AllowWiFiDirect = true;
         PeerFinder.AllowInfrastructure = false;// true;

         PeerFinder.ConnectionRequested += OnConnectionRequested;
         PeerFinder.TriggeredConnectionStateChanged += OnTriggeredConnectionStateChanged;

         PeerFinder.Start();
         PeerFinder.Start("msg");
         var peers = (await PeerFinder.FindAllPeersAsync()).ToArray();
         PeerFinder.Stop();
      }
      #endregion
   }
}

#if HostNameIsEqualExamples
"abcd", "ABCD"
"ABcd", "abCD"
"0::1", "0:0::1"
"1.2.3.4", "::ffff:1.2.3.4"
"dth\x00C4ler", "DTH\x00E4LER"
"xn--p1ai", "\x0440\x0444"
"\x0420\x0424", "\x0440\x0444"
"A\x030A", "\xC5"
#endif
